# DPFPXFMT.py
# /**  PREPARE FPX DDS ENROLMENT RECORD UPDATING - WEEKLY  **/
# /* DP7909 - EXPAND THE LENGTH OF APY-PER-TRX-LIM          */

import polars as pl
import duckdb
from datetime import datetime, timedelta
import common.parquet_splitter as parquet_splitter
import common.data_cleaner as data_cleaner
import common.fixed_width_reader as fixed_width_reader
import os
from common.batch_date import get_batch_data
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Obtain date for file paths
date_info = get_batch_data()
file_date = date_info["file_date"]
folder_day = date_info["folder_day"]
folder_month = date_info["folder_month"]
folder_year = date_info["folder_year"]

# Define file paths - matching SAS convention
INPUTF1 = f"/host/dp/input/fpx/INPUTF1_{folder_year}{folder_month}{folder_day}.dat"
INPUTF2 = f"/host/dp/input/fpx/INPUTF2_{folder_year}{folder_month}{folder_day}.dat"
OUTPUTF1 = f"/host/dp/output/DPFPXFMT_OUTPUT_{folder_year}{folder_month}{folder_day}.dat"
OUTPUT_RPT = f"/host/dp/output/DPFPXFMT_REPORT_{folder_year}{folder_month}{folder_day}.txt"

def main():
    """SAS DPFPXFMT program converted to Python with same variable names"""
    
    try:
        logger.info("Starting DPFPXFMT - PREPARE FPX DDS ENROLMENT RECORD UPDATING - WEEKLY")
        logger.info("DP7909 - EXPAND THE LENGTH OF APY-PER-TRX-LIM")
        
        # Step 1: Read INPUTF1 into DATA001
        logger.info("Reading INPUTF1 into DATA001...")
        DATA001 = read_DATA001()
        
        # Step 2: Read INPUTF2 into DATA002
        logger.info("Reading INPUTF2 into DATA002...")
        DATA002 = read_DATA002()
        
        # Step 3: Sort DATA002 by MATCHKEY (same as SAS PROC SORT)
        logger.info("Sorting DATA002 by MATCHKEY...")
        DATA002 = DATA002.sort("MATCHKEY")
        
        # Step 4: Create DATA003 from DATA002 (aggregating TRXLIMX)
        logger.info("Creating DATA003 from DATA002 (aggregating TRXLIMX)...")
        DATA003 = create_DATA003(DATA002)
        
        # Step 5: Sort DATA001 and DATA003 by MATCHKEY
        logger.info("Sorting DATA001 and DATA003 by MATCHKEY...")
        DATA001 = DATA001.sort("MATCHKEY")
        DATA003 = DATA003.sort("MATCHKEY")
        
        # Step 6: Merge to see whether got existing record (DATANEW and DATA004)
        logger.info("Merging DATA001 and DATA003 to create DATANEW and DATA004...")
        DATANEW, DATA004 = merge_DATA001_DATA003(DATA001, DATA003)
        
        # Step 7: Sort DATA004 by MATCHKEY
        logger.info("Sorting DATA004 by MATCHKEY...")
        DATA004 = DATA004.sort("MATCHKEY")
        
        # Step 8: Create DATAUPD from DATA004
        logger.info("Creating DATAUPD from DATA004...")
        DATAUPD = create_DATAUPD(DATA004)
        
        # Step 9: Sort DATANEW and DATAUPD by MATCHKEY
        logger.info("Sorting DATANEW and DATAUPD by MATCHKEY...")
        DATANEW = DATANEW.sort("MATCHKEY")
        DATAUPD = DATAUPD.sort("MATCHKEY")
        
        # Step 10: Write output file for DB2 update (OUTPUTF1)
        logger.info(f"Writing output file to {OUTPUTF1}...")
        write_OUTPUTF1(DATANEW, DATAUPD)
        
        # Step 11: Generate report
        logger.info(f"Generating report to {OUTPUT_RPT}...")
        generate_report(DATANEW, DATAUPD)
        
        # Step 12: Print GOODDR summary (matching SAS PROC PRINT)
        print_GOODDR_summary(DATA001)
        
        logger.info("DPFPXFMT processing completed successfully.")
        
    except Exception as e:
        logger.error(f"Error in DPFPXFMT processing: {str(e)}", exc_info=True)
        raise

def read_DATA001():
    """SAS DATA DATA001; INFILE INPUTF1; ... RUN;"""
    logger.info(f"Reading DATA001 from {INPUTF1}")
    
    # Column specifications matching SAS INPUT statement with DP7909 changes
    col_specs = [
        ("RECTYPE", 5),           # @001 RECTYPE      $5.
        ("BANKNO", 2, "int"),     # @006 BANKNO      PD2.
        ("DRACCTNO", 6, "int"),   # @008 DRACCTNO    PD6.
        ("MISCKEY1", 20),         # @014 MISCKEY1    $20.
        ("MISCKEY2", 20),         # @034 MISCKEY2    $20.
        ("MISCKEY3", 20),         # @054 MISCKEY3    $20.
        # DP7909: Changed from PD5 to PD9.2
        ("TRXLIM1", 9, "float"),  # @074 TRXLIM1     PD9.2      /* DP7909 START */
        ("FAILCNT", 1, "int"),    # @083 FAILCNT     PD1.
        ("OPENDATE", 10),         # @084 OPENDATE    $10.
        ("CANDATE", 10),          # @094 CANDATE     $10.
        ("ACTVDATE", 10),         # @104 ACTVDATE    $10.
        ("LSTMNTDT", 10),         # @114 LSTMNTDT    $10.
        ("BNKOFFCD", 3, "int"),   # @124 BNKOFFCD    PD3.
        ("OFFID1", 8),            # @127 OFFID1       $8.
        ("OFFID2", 8),            # @135 OFFID2       $8.
        ("ACCTSTAT", 1),          # @143 ACCTSTAT     $1.
        ("PYACCTNO", 6, "int"),   # @144 PYACCTNO    PD6.
        ("FREQPAY", 1),           # @150 FREQPAY      $1.
        ("LSTTRXDT", 10),         # @151 LSTTRXDT    $10.
        ("AUTOCLS", 1, "int"),    # @161 AUTOCLS     PD1.
        ("FAILLIM", 2, "int"),    # @162 FAILLIM     PD2.
        ("FEECHRG", 3, "float"),  # @164 FEECHRG     PD3.2
        ("MTDDBCNT", 3, "int"),   # @167 MTDDBCNT    PD3.
        ("YTDDBCNT", 3, "int"),   # @170 YTDDBCNT    PD3.
        ("MTDDBAMT", 6, "float"), # @173 MTDDBAMT    PD6.2
        ("YTDDBAMT", 6, "float"), # @179 YTDDBAMT    PD6.2
        ("ACCUMCNT", 3, "int"),   # @185 ACCUMCNT    PD3.
        ("ACCUMAMT", 6, "float")  # @188 ACCUMAMT    PD6.2;    /* DP7909 END */
    ]
    
    # Read the fixed-width file
    DATA001 = fixed_width_reader.read_fixed_width(INPUTF1, col_specs)
    
    # Create MATCHKEY exactly as in SAS: PUT(RECTYPE,$5.)||PUT(DRACCTNO,10.)||PUT(MISCKEY1,$20.)
    DATA001 = DATA001.with_columns([
        (pl.col("RECTYPE").str.slice(0, 5) + 
         pl.col("DRACCTNO").cast(pl.Utf8).str.zfill(10) + 
         pl.col("MISCKEY1").str.slice(0, 20)).alias("MATCHKEY")
    ])
    
    logger.info(f"DATA001 created with {len(DATA001)} records")
    return DATA001

def read_DATA002():
    """SAS DATA DATA002; INFILE INPUTF2; ... RUN;"""
    logger.info(f"Reading DATA002 from {INPUTF2}")
    
    # Column specifications matching SAS INPUT statement with DP7909 changes
    col_specs = [
        ("RECTYPE", 5),           # @001 RECTYPE      $5.
        ("BANKNO", 2, "int"),     # @006 BANKNO      PD2.
        ("DRACCTNO", 6, "int"),   # @008 DRACCTNO    PD6.
        # Note: MISCKEY1 is skipped (@014) and will be replaced by SELLID later
        ("MISCKEY2", 20, 33),     # @034 MISCKEY2    $20.
        ("MISCKEY3", 20, 53),     # @054 MISCKEY3    $20.
        # DP7909: Changed from PD5 to PD9.2
        ("TRXLIMX", 9, "float", 73),  # @074 TRXLIMX     PD9.2        /* DP7909 START*/
        ("FAILCNT", 1, "int", 82),    # @083 FAILCNT     PD1.
        ("OPENDATE", 10, 83),         # @084 OPENDATE    $10.
        ("CANDATE", 10, 93),          # @094 CANDATE     $10.
        ("ACTVDATE", 10, 103),        # @104 ACTVDATE    $10.
        ("LSTMNTDT", 10, 113),        # @114 LSTMNTDT    $10.
        ("BNKOFFCD", 3, "int", 123),  # @124 BNKOFFCD    PD3.
        ("OFFID1", 8, 126),           # @127 OFFID1       $8.
        ("OFFID2", 8, 134),           # @135 OFFID2       $8.
        ("ACCTSTAT", 1, 142),         # @143 ACCTSTAT     $1.
        ("PYACCTNO", 6, "int", 143),  # @144 PYACCTNO    PD6.
        ("FREQPAY", 1, 149),          # @150 FREQPAY      $1.
        ("LSTTRXDT", 10, 150),        # @151 LSTTRXDT    $10.
        ("AUTOCLS", 1, "int", 160),   # @161 AUTOCLS     PD1.
        ("FAILLIM", 2, "int", 161),   # @162 FAILLIM     PD2.
        ("FEECHRG", 3, "float", 163), # @164 FEECHRG     PD3.2
        ("MTDDBCNT", 3, "int", 166),  # @167 MTDDBCNT    PD3.
        ("YTDDBCNT", 3, "int", 169),  # @170 YTDDBCNT    PD3.
        ("MTDDBAMT", 6, "float", 172),# @173 MTDDBAMT    PD6.2
        ("YTDDBAMT", 6, "float", 178),# @179 YTDDBAMT    PD6.2
        ("ACCUMCNT", 3, "int", 184),  # @185 ACCUMCNT    PD3.
        ("ACCUMAMT", 6, "float", 187),# @188 ACCUMAMT    PD6.2
        ("SELLID", 10, 193),          # @194 SELLID      $10.
        ("SELLBANK", 10, 203),        # @204 SELLBANK    $10.
        ("NOOFFREQ", 2, "int", 213)   # @214 NOOFFREQ    PD2.;        /* DP7909 END */
    ]
    
    # Read the fixed-width file
    DATA002 = fixed_width_reader.read_fixed_width(INPUTF2, col_specs)
    
    # Set MISCKEY1 = SELLID exactly as in SAS: MISCKEY1 = SELLID;
    DATA002 = DATA002.with_columns([
        pl.col("SELLID").alias("MISCKEY1")
    ])
    
    # Create MATCHKEY exactly as in SAS: PUT(RECTYPE,$5.)||PUT(DRACCTNO,10.)||PUT(MISCKEY1,$20.)
    DATA002 = DATA002.with_columns([
        (pl.col("RECTYPE").str.slice(0, 5) + 
         pl.col("DRACCTNO").cast(pl.Utf8).str.zfill(10) + 
         pl.col("MISCKEY1").str.slice(0, 20)).alias("MATCHKEY")
    ])
    
    logger.info(f"DATA002 created with {len(DATA002)} records")
    return DATA002

def create_DATA003(DATA002):
    """SAS DATA DATA003(DROP=TRXLIMX); SET DATA002; BY MATCHKEY; ... RUN;"""
    logger.info("Creating DATA003 from DATA002 (aggregating TRXLIMX by MATCHKEY)")
    
    # Group by MATCHKEY to aggregate TRXLIMX (equivalent to SAS BY processing)
    agg_exprs = [
        pl.col("TRXLIMX").sum().alias("TRXLIM_SUM"),
        pl.first("RECTYPE").alias("RECTYPE"),
        pl.first("BANKNO").alias("BANKNO"),
        pl.first("DRACCTNO").alias("DRACCTNO"),
        pl.first("MISCKEY1").alias("MISCKEY1"),
        pl.first("MISCKEY2").alias("MISCKEY2"),
        pl.first("MISCKEY3").alias("MISCKEY3"),
        pl.first("FAILCNT").alias("FAILCNT"),
        pl.first("OPENDATE").alias("OPENDATE"),
        pl.first("CANDATE").alias("CANDATE"),
        pl.first("ACTVDATE").alias("ACTVDATE"),
        pl.first("LSTMNTDT").alias("LSTMNTDT"),
        pl.first("BNKOFFCD").alias("BNKOFFCD"),
        pl.first("OFFID1").alias("OFFID1"),
        pl.first("OFFID2").alias("OFFID2"),
        pl.first("ACCTSTAT").alias("ACCTSTAT"),
        pl.first("PYACCTNO").alias("PYACCTNO"),
        pl.first("FREQPAY").alias("FREQPAY"),
        pl.first("LSTTRXDT").alias("LSTTRXDT"),
        pl.first("AUTOCLS").alias("AUTOCLS"),
        pl.first("FAILLIM").alias("FAILLIM"),
        pl.first("FEECHRG").alias("FEECHRG"),
        pl.first("MTDDBCNT").alias("MTDDBCNT"),
        pl.first("YTDDBCNT").alias("YTDDBCNT"),
        pl.first("MTDDBAMT").alias("MTDDBAMT"),
        pl.first("YTDDBAMT").alias("YTDDBAMT"),
        pl.first("ACCUMCNT").alias("ACCUMCNT"),
        pl.first("ACCUMAMT").alias("ACCUMAMT"),
        pl.first("SELLID").alias("SELLID"),
        pl.first("SELLBANK").alias("SELLBANK"),
        pl.first("NOOFFREQ").alias("NOOFFREQ")
    ]
    
    # Group by MATCHKEY and aggregate
    grouped = DATA002.group_by("MATCHKEY").agg(agg_exprs)
    
    # Apply the same logic as SAS:
    # TRXLIM = 0; (at FIRST.MATCHKEY)
    # TRXLIM + TRXLIMX; (accumulate)
    # IF TRXLIM > 99999999 THEN TRXLIM = 99999999;
    # IF LAST.MATCHKEY THEN OUTPUT;
    
    # Since we've already summed TRXLIMX in the aggregation, now cap it
    grouped = grouped.with_columns([
        pl.when(pl.col("TRXLIM_SUM") > 99999999)
        .then(pl.lit(99999999))
        .otherwise(pl.col("TRXLIM_SUM"))
        .alias("TRXLIM")
    ])
    
    # Rename to match SAS variable name
    DATA003 = grouped.rename({"TRXLIM_SUM": "TRXLIMX_TEMP"})
    
    logger.info(f"DATA003 created with {len(DATA003)} unique MATCHKEYs")
    return DATA003

def merge_DATA001_DATA003(DATA001, DATA003):
    """SAS DATA DATANEW DATA004; MERGE DATA001(IN=A) DATA003(IN=B); BY MATCHKEY; ... RUN;"""
    logger.info("Merging DATA001 and DATA003 to create DATANEW and DATA004")
    
    # Perform merge with indicator
    merged = DATA001.join(
        DATA003, 
        on="MATCHKEY", 
        how="outer", 
        suffix="_DATA003",
        indicator=True
    )
    
    # Create DATANEW (records in B but not in A)
    DATANEW = merged.filter(
        (pl.col("_merge") == "right_only")  # B AND NOT A
    ).with_columns([
        pl.lit("I").alias("TRXTYPE"),  # TRXTYPE = 'I'
        pl.col("TRXLIM").alias("TOTLIMT")  # TOTLIMT = TRXLIM
    ])
    
    # Create DATA004 (records in both A and B)
    DATA004 = merged.filter(
        (pl.col("_merge") == "both")  # A AND B
    ).with_columns([
        pl.lit("U").alias("TRXTYPE")  # TRXTYPE = 'U'
    ])
    
    logger.info(f"DATANEW: {len(DATANEW)} records (new inserts)")
    logger.info(f"DATA004: {len(DATA004)} records (existing updates)")
    
    return DATANEW, DATA004

def create_DATAUPD(DATA004):
    """SAS DATA DATAUPD; SET DATA004; BY MATCHKEY; ... RUN;"""
    logger.info("Creating DATAUPD from DATA004")
    
    # Apply the same logic as SAS:
    # IF FIRST.MATCHKEY THEN TOTLIMT = TRXLIM1;
    # TOTLIMT + TRXLIM;
    # IF TOTLIMT > 99999999 THEN TOTLIMT = 99999999;
    # IF LAST.MATCHKEY THEN OUTPUT;
    
    # Since we're working with aggregated data, we need to handle by MATCHKEY
    # For each MATCHKEY group, start with TRXLIM1 and add TRXLIM
    
    # Initialize TOTLIMT with TRXLIM1 for each record
    DATA004 = DATA004.with_columns([
        pl.coalesce(pl.col("TRXLIM1"), pl.lit(0)).alias("TOTLIMT_INIT")
    ])
    
    # Add TRXLIM to TOTLIMT
    DATA004 = DATA004.with_columns([
        (pl.col("TOTLIMT_INIT") + pl.coalesce(pl.col("TRXLIM"), pl.lit(0))).alias("TOTLIMT_CALC")
    ])
    
    # Cap TOTLIMT at 99999999
    DATA004 = DATA004.with_columns([
        pl.when(pl.col("TOTLIMT_CALC") > 99999999)
        .then(pl.lit(99999999))
        .otherwise(pl.col("TOTLIMT_CALC"))
        .alias("TOTLIMT")
    ])
    
    # For each MATCHKEY, take the last record (equivalent to IF LAST.MATCHKEY THEN OUTPUT)
    DATAUPD = DATA004.group_by("MATCHKEY").agg([
        pl.last("RECTYPE").alias("RECTYPE"),
        pl.last("BANKNO").alias("BANKNO"),
        pl.last("DRACCTNO").alias("DRACCTNO"),
        pl.last("MISCKEY1").alias("MISCKEY1"),
        pl.last("MISCKEY2").alias("MISCKEY2"),
        pl.last("MISCKEY3").alias("MISCKEY3"),
        pl.last("TOTLIMT").alias("TOTLIMT"),
        pl.last("FAILCNT").alias("FAILCNT"),
        pl.last("OPENDATE").alias("OPENDATE"),
        pl.last("CANDATE").alias("CANDATE"),
        pl.last("ACTVDATE").alias("ACTVDATE"),
        pl.last("LSTMNTDT").alias("LSTMNTDT"),
        pl.last("BNKOFFCD").alias("BNKOFFCD"),
        pl.last("OFFID1").alias("OFFID1"),
        pl.last("OFFID2").alias("OFFID2"),
        pl.last("ACCTSTAT").alias("ACCTSTAT"),
        pl.last("PYACCTNO").alias("PYACCTNO"),
        pl.last("FREQPAY").alias("FREQPAY"),
        pl.last("LSTTRXDT").alias("LSTTRXDT"),
        pl.last("AUTOCLS").alias("AUTOCLS"),
        pl.last("FAILLIM").alias("FAILLIM"),
        pl.last("FEECHRG").alias("FEECHRG"),
        pl.last("MTDDBCNT").alias("MTDDBCNT"),
        pl.last("YTDDBCNT").alias("YTDDBCNT"),
        pl.last("MTDDBAMT").alias("MTDDBAMT"),
        pl.last("YTDDBAMT").alias("YTDDBAMT"),
        pl.last("ACCUMCNT").alias("ACCUMCNT"),
        pl.last("ACCUMAMT").alias("ACCUMAMT"),
        pl.last("SELLID").alias("SELLID"),
        pl.last("SELLBANK").alias("SELLBANK"),
        pl.last("NOOFFREQ").alias("NOOFFREQ"),
        pl.last("TRXTYPE").alias("TRXTYPE")
    ])
    
    logger.info(f"DATAUPD created with {len(DATAUPD)} records")
    return DATAUPD

def write_OUTPUTF1(DATANEW, DATAUPD):
    """SAS DATA _NULL_; FILE OUTPUTF1; SET DATANEW DATAUPD; BY MATCHKEY; PUT ... RUN;"""
    logger.info(f"Writing output file to {OUTPUTF1}")
    
    # Combine DATANEW and DATAUPD
    combined = pl.concat([DATANEW, DATAUPD])
    
    # Sort by MATCHKEY as in SAS
    combined = combined.sort("MATCHKEY")
    
    # Define output specifications matching SAS PUT statement with DP7909 changes
    output_specs = [
        ("RECTYPE", 5, "left"),           # @001 RECTYPE      $5.
        ("BANKNO", 2, "right", "int"),    # @006 BANKNO      PD2.
        ("DRACCTNO", 6, "right", "int"),  # @008 DRACCTNO    PD6.
        ("MISCKEY1", 20, "left"),         # @014 MISCKEY1    $20.
        ("MISCKEY2", 20, "left"),         # @034 MISCKEY2    $20.
        ("MISCKEY3", 20, "left"),         # @054 MISCKEY3    $20.
        # DP7909: Changed from PD5 to PD9.2
        ("TOTLIMT", 9, "right", "float", 2),  # @074 TOTLIMT     PD9.2      /* DP7909 START */
        ("FAILCNT", 1, "right", "int"),       # @083 FAILCNT     PD1.
        ("OPENDATE", 10, "left"),             # @084 OPENDATE    $10.
        ("CANDATE", 10, "left"),              # @094 CANDATE     $10.
        ("ACTVDATE", 10, "left"),             # @104 ACTVDATE    $10.
        ("LSTMNTDT", 10, "left"),             # @114 LSTMNTDT    $10.
        ("BNKOFFCD", 3, "right", "int"),      # @124 BNKOFFCD    PD3.
        ("OFFID1", 8, "left"),                # @127 OFFID1       $8.
        ("OFFID2", 8, "left"),                # @135 OFFID2       $8.
        ("ACCTSTAT", 1, "left"),              # @143 ACCTSTAT     $1.
        ("PYACCTNO", 6, "right", "int"),      # @144 PYACCTNO    PD6.
        ("FREQPAY", 1, "left"),               # @150 FREQPAY      $1.
        ("LSTTRXDT", 10, "left"),             # @151 LSTTRXDT    $10.
        ("AUTOCLS", 1, "right", "int"),       # @161 AUTOCLS     PD1.
        ("FAILLIM", 2, "right", "int"),       # @162 FAILLIM     PD2.
        ("FEECHRG", 3, "right", "float", 2),  # @164 FEECHRG     PD3.2
        ("MTDDBCNT", 3, "right", "int"),      # @167 MTDDBCNT    PD3.
        ("YTDDBCNT", 3, "right", "int"),      # @170 YTDDBCNT    PD3.
        ("MTDDBAMT", 6, "right", "float", 2), # @173 MTDDBAMT    PD6.2
        ("YTDDBAMT", 6, "right", "float", 2), # @179 YTDDBAMT    PD6.2
        ("ACCUMCNT", 3, "right", "int"),      # @185 ACCUMCNT    PD3.
        ("ACCUMAMT", 6, "right", "float", 2), # @188 ACCUMAMT    PD6.2
        ("SELLID", 10, "left"),               # @194 SELLID      $10.
        ("SELLBANK", 10, "left"),             # @204 SELLBANK    $10.
        ("NOOFFREQ", 2, "right", "int"),      # @214 NOOFFREQ    PD2.
        ("TRXTYPE", 1, "left")                # @216 TRXTYPE      $1.;       /* DP7909 END */
    ]
    
    # Write fixed-width output
    fixed_width_reader.write_fixed_width(combined, OUTPUTF1, output_specs)
    
    logger.info(f"Output file created: {OUTPUTF1} with {len(combined)} records")

def generate_report(DATANEW, DATAUPD):
    """Generate report file similar to SAS output"""
    logger.info(f"Generating report to {OUTPUT_RPT}")
    
    with open(OUTPUT_RPT, 'w') as f:
        f.write("DPFPXFMT - FPX DDS ENROLMENT RECORD UPDATING - WEEKLY REPORT\n")
        f.write("=" * 80 + "\n\n")
        f.write(f"Processing Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"DP7909 Implemented: YES (TRXLIM expanded from PD5 to PD9.2)\n\n")
        
        f.write("PROCESSING SUMMARY:\n")
        f.write("-" * 40 + "\n")
        f.write(f"Total New Records (I): {len(DATANEW)}\n")
        f.write(f"Total Update Records (U): {len(DATAUPD)}\n")
        f.write(f"Total Output Records: {len(DATANEW) + len(DATAUPD)}\n\n")
        
        if len(DATANEW) > 0 and "TOTLIMT" in DATANEW.columns:
            f.write("NEW RECORDS (TRXTYPE = 'I'):\n")
            f.write(f"  Total TOTLIMT: {DATANEW['TOTLIMT'].sum():,.2f}\n")
            f.write(f"  Average TOTLIMT: {DATANEW['TOTLIMT'].mean():,.2f}\n")
            f.write(f"  Maximum TOTLIMT: {DATANEW['TOTLIMT'].max():,.2f}\n")
            f.write(f"  Minimum TOTLIMT: {DATANEW['TOTLIMT'].min():,.2f}\n\n")
        
        if len(DATAUPD) > 0 and "TOTLIMT" in DATAUPD.columns:
            f.write("UPDATE RECORDS (TRXTYPE = 'U'):\n")
            f.write(f"  Total TOTLIMT: {DATAUPD['TOTLIMT'].sum():,.2f}\n")
            f.write(f"  Average TOTLIMT: {DATAUPD['TOTLIMT'].mean():,.2f}\n")
            f.write(f"  Maximum TOTLIMT: {DATAUPD['TOTLIMT'].max():,.2f}\n")
            f.write(f"  Minimum TOTLIMT: {DATAUPD['TOTLIMT'].min():,.2f}\n\n")
        
        # Count records by BANKNO if available
        if len(DATANEW) > 0 and "BANKNO" in DATANEW.columns:
            f.write("NEW RECORDS BY BANKNO:\n")
            bank_counts = DATANEW.group_by("BANKNO").agg(pl.count().alias("count"))
            for row in bank_counts.iter_rows(named=True):
                f.write(f"  BANKNO {row['BANKNO']}: {row['count']} records\n")
        
        f.write("\n" + "=" * 80 + "\n")
        f.write("END OF REPORT\n")

def print_GOODDR_summary(DATA001):
    """Mimic SAS PROC PRINT for debugging - using DATA001 as GOODDR equivalent"""
    logger.info("PROC PRINT equivalent - First 10 records of DATA001:")
    
    if len(DATA001) > 0:
        # Display first 10 records
        print_records = DATA001.head(10)
        
        for i, row in enumerate(print_records.iter_rows(named=True)):
            logger.info(f"Record {i+1}: RECTYPE={row.get('RECTYPE')}, "
                       f"BANKNO={row.get('BANKNO')}, "
                       f"DRACCTNO={row.get('DRACCTNO')}, "
                       f"TRXLIM1={row.get('TRXLIM1', 0):.2f}")
    
    logger.info(f"Total DATA001 records: {len(DATA001)}")

if __name__ == "__main__":
    main()