# DPFPXINT.py
# /* FORMAT INTRADAY FILE FOR FPX POSTING */

import polars as pl
import duckdb
from datetime import datetime
import common.parquet_splitter as parquet_splitter
import common.data_cleaner as data_cleaner
import common.fixed_width_reader as fixed_width_reader
import os
from common.batch_date import get_batch_data
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Obtain date for file paths
date_info = get_batch_data()
file_date = date_info["file_date"]
folder_day = date_info["folder_day"]
folder_month = date_info["folder_month"]
folder_year = date_info["folder_year"]

# Define file paths - matching SAS convention
INFILE01 = f"/host/dp/input/fpx/INFILE01_{folder_year}{folder_month}{folder_day}.dat"
INTRADAY = f"/host/dp/output/DPFPXINT_OUTPUT_{folder_year}{folder_month}{folder_day}.dat"
OUTPUT_RPT = f"/host/dp/output/DPFPXINT_REPORT_{folder_year}{folder_month}{folder_day}.txt"

def main():
    """SAS DPFPXINT program converted to Python with same variable names"""
    
    try:
        logger.info("Starting DPFPXINT - FORMAT INTRADAY FILE FOR FPX POSTING")
        
        # Step 1: Read INFILE01 into AAA
        logger.info(f"Reading INFILE01 into AAA...")
        AAA = read_AAA()
        
        # Step 2: Process AAA to create output records
        logger.info("Processing AAA to create output records...")
        AAA_processed = process_AAA(AAA)
        
        # Step 3: Write to INTRADAY file
        logger.info(f"Writing to INTRADAY file {INTRADAY}...")
        write_INTRADAY(AAA_processed)
        
        # Step 4: Generate report
        logger.info(f"Generating report to {OUTPUT_RPT}...")
        generate_report(AAA_processed)
        
        logger.info("DPFPXINT processing completed successfully.")
        
    except Exception as e:
        logger.error(f"Error in DPFPXINT processing: {str(e)}", exc_info=True)
        raise

def read_AAA():
    """SAS DATA AAA; INFILE INFILE01 MISSOVER; INPUT ... RUN;"""
    logger.info(f"Reading AAA from {INFILE01}")
    
    # Read using the existing fixed_width_reader - same as shown in image
    schema = [
        (0, 1, "RECTYPE"),      # @001 RECTYPE     $1.
        (1, 2, "DBANKNO"),     # @002 DBANKNO    PD2.
        (3, 6, "DACCTNO"),     # @004 DACCTNO    PD6.
        (9, 20, "DSERIALN"),   # @010 DSERIALN   $20.
        (25, 6, "DREFNO"),     # @026 DREFNO     PD6.
        (35, 10, "DISSDATE"),  # @036 DISSDATE   $10.
        (45, 3, "DISSBRAN"),   # @046 DISSBRAN   PD3.
        (48, 7, "DAMOUNT"),    # @049 DAMOUNT    PD7.2
        (55, 2, "DTYPE"),      # @056 DTYPE       $2.
        (57, 2, "DSTATUS"),    # @058 DSTATUS     $2.
        (59, 40, "DAPPNAME"),  # @060 DAPPNAME   $40.
        (99, 20, "DAPPID"),    # @100 DAPPID     $20.
        (119, 40, "DBENENAM"), # @120 DBENENAM   $40.
        (159, 3, "DBENEBNO"),  # @160 DBENEBNO    $3.
        (162, 17, "DBENEACC"), # @163 DBENEACC   $17.
        (162, 1, "ACC01DGT"),  # @163 ACC01DGT    $1.
        (162, 10, "ACC10DGT"), # @163 ACC10DGT    10.
        (159, 1, "ACC02DGT"),  # @160 ACC02DGT    $1.
        (160, 1, "ACC03DGT"),  # @161 ACC03DGT    $1.
        (161, 1, "ACC04DGT"),  # @162 ACC04DGT    $1.
        (162, 1, "ACC05DGT"),  # @163 ACC05DGT    $1.
        (163, 1, "ACC06DGT"),  # @164 ACC06DGT    $1.
        (164, 1, "ACC07DGT"),  # @165 ACC07DGT    $1.
        (165, 1, "ACC08DGT"),  # @166 ACC08DGT    $1.
        (166, 2, "ACCCKDGT"),  # @167 ACCCKDGT    $2.
        (168, 7, "ACC11DGT"),  # @169 ACC11DGT    $7.
        (179, 8, "DUSERID"),   # @180 DUSERID     $8.
        (187, 10, "DLTRXDTE"), # @188 DLTRXDTE   $10.
        (197, 10, "DSTMTDTE"), # @198 DSTMTDTE   $10.
        (207, 26, "DTIMESTP"), # @208 DTIMESTP   $26.
        (233, 10, "DPAYMODE"), # @234 DPAYMODE   $10.
        (243, 10, "DREFMODE"), # @244 DREFMODE   $10.           /* DP1288 */
        (248, 3, "DOFIBANK"),  # @249 DOFIBANK   $3.            /* DP1288 */
        (251, 2, "RESCODE"),   # @252 RESCODE    $2.            /* DP1288 */
        (253, 10, "DBUSSDTE"), # @254 DBUSSDTE   $10.           /* DP1288 */
        (263, 2, "ACCRULE"),   # @264 ACCRULE    2.             /* DP1248 */
        (265, 28, "OTDFNO"),   # @266 OTDFNO     $28.
        (293, 10, "OFIID"),    # @294 OFIID      $10.
        (303, 1, "BFILLER"),   # @304 BFILLER    $1.
        (304, 28, "DTDFNO"),   # @305 DTDFNO     $28.
        (332, 1, "DTDFIND"),   # @333 DTDFIND     $1.
        (333, 4, "DTDFSOUR"),  # @334 DTDFSOUR    $4.
        (337, 2, "DTDFTXCD"),  # @338 DTDFTXCD     2.
        (339, 3, "DTDFRECD"),  # @340 DTDFRECD    $3.
        (342, 1, "DTDFAIND"),  # @343 DTDFAIND     1.
        (343, 2, "DTDFATYP"),  # @344 DTDFATYP     2.
        (345, 80, "DTDFAINF"), # @346 DTDFAINF   $80.
        (345, 30, "DTDFADD1"), # @346 DTDFADD1   $CHAR30.       /* DP1288 */
        (375, 10, "DTDFBLCD"), # @376 DTDFBLCD   $CHAR10.       /* DP1288 */
        (385, 20, "DTDFADD2"), # @386 DTDFADD2   $CHAR20.       /* DP1288 */
        (405, 1, "DTDFDRTRY"), # @406 DTDFDRTRY  $CHAR1.        /* IBGDD DEBIT RETRY */
        (406, 1, "DTDFACTYP"), # @407 DTDFACTYP  $CHAR1.        /* IBGDD ACCT TYPE */
        (425, 29, "DTDFFILL"), # @426 DTDFFILL   $29.
        (454, 20, "PAYREF1"),  # @455 PAYREF1    $20.           /* 1ST 20 BYTE2 REF # FROM ADENDA 2 */
        (474, 20, "PAYREF2")   # @475 PAYREF2    $20.           /* 2ND 20 BYTE2 REF # FROM ADENDA 2 */
    ]
    
    # Using the exact same reading method as shown in image
    AAA = fixed_width_reader.read(INFILE01, schema)
    
    # Convert numeric columns (simulating SAS PD format)
    AAA = convert_numeric_columns(AAA)
    
    logger.info(f"AAA created with {len(AAA)} records")
    return AAA

def convert_numeric_columns(df):
    """Convert string columns to numeric types based on SAS PD format"""
    # PD2. - Packed Decimal 2 bytes
    df = df.with_columns([
        pl.col("DBANKNO").cast(pl.Int64).alias("DBANKNO"),
        pl.col("DACCTNO").cast(pl.Int64).alias("DACCTNO"),
        pl.col("DREFNO").cast(pl.Int64).alias("DREFNO"),
        pl.col("DISSBRAN").cast(pl.Int64).alias("DISSBRAN"),
        # PD7.2 - Packed Decimal 7 bytes with 2 decimal places
        pl.col("DAMOUNT").str.replace(r'[^0-9.-]', '').cast(pl.Float64).alias("DAMOUNT"),
        # 10. - 10 digit integer
        pl.col("ACC10DGT").cast(pl.Int64).alias("ACC10DGT"),
        # 2. - 2 digit integer
        pl.col("ACCRULE").cast(pl.Int64).alias("ACCRULE"),
        # Other numeric fields
        pl.col("DTDFTXCD").cast(pl.Int64).alias("DTDFTXCD"),
        pl.col("DTDFAIND").cast(pl.Int64).alias("DTDFAIND"),
        pl.col("DTDFATYP").cast(pl.Int64).alias("DTDFATYP")
    ])
    
    return df

def process_AAA(AAA):
    """SAS DATA AAA; ... (all the processing logic) RUN;"""
    logger.info("Processing AAA data...")
    
    # Add constant fields and perform calculations
    AAA_processed = AAA.with_columns([
        # SOURCECD = 315
        pl.lit(315).alias("SOURCECD"),
        # TRANCODE = 906
        pl.lit(906).alias("TRANCODE"),
        # CONVERT = SUBSTR(DBENEACC,1,10)
        pl.col("DBENEACC").str.slice(0, 10).alias("CONVERT"),
        # ACCTFST = SUBSTR(DBENEACC,1,1)
        pl.col("DBENEACC").str.slice(0, 1).alias("ACCTFST"),
        # BNKCODE logic
        pl.when(pl.col("ACCTFST") == "6")
        .then(pl.lit("033"))  # DP2094
        .otherwise(pl.lit("033"))  # DP1248
        .alias("BNKCODE"),
        # DTDFACTYP logic
        pl.when(pl.col("ACC05DGT") == "3")
        .then(pl.lit("2"))
        .otherwise(pl.lit("1"))
        .alias("DTDFACTYP_PROCESSED"),
        # ACCTNOS = PUT(ACC10DGT,S370FPDU6.)
        # Simplified: pad ACC10DGT to 6 digits
        pl.col("ACC10DGT").cast(pl.Utf8).str.zfill(6).alias("ACCTNOS"),
        # CONTROL = 3
        pl.lit(3).alias("CONTROL"),
        # OBANKNO = PUT(BNKCODE,S370FPDU2.)
        # Simplified: pad BNKCODE to 2 digits
        pl.lit("33").alias("OBANKNO"),  # Hardcoded as '033' becomes '33'
        # SERIALNO = 0
        pl.lit(0).alias("SERIALNO"),
        # TRAILCNT = 4
        pl.lit(4).alias("TRAILCNT"),
        # SPACE = ' '
        pl.lit(" ").alias("SPACE"),
        # Constant fields for output
        pl.lit("L").alias("RECORD_START"),
        pl.lit("D").alias("DEBIT_IND"),
        pl.lit("FPXOFIID").alias("FILLER_11_18"),
        pl.lit("L").alias("END_MARKER_44"),
        pl.lit("04").alias("TRAILCNT_STR"),
        pl.lit(" ").alias("SPACE_1"),
        pl.lit("DIRECT DEBIT ").alias("DIRECT_DEBIT_TEXT"),
        pl.lit(" ").alias("SPACE_2"),
        pl.lit(" ").alias("SPACE_3"),
        pl.lit(" ").alias("SPACE_4"),
        pl.lit(" ").alias("SPACE_5"),
        pl.lit(" ").alias("SPACE_6"),
        pl.lit(" ").alias("SPACE_7")
    ])
    
    # Handle DTDFADD1 - if empty, use DBENENAM
    AAA_processed = AAA_processed.with_columns([
        pl.when(pl.col("DTDFADD1").str.strip() == "")
        .then(pl.col("DBENENAM"))
        .otherwise(pl.col("DTDFADD1"))
        .alias("DTDFADD1_PROCESSED")
    ])
    
    logger.info(f"AAA processed with {len(AAA_processed)} records")
    return AAA_processed

def write_INTRADAY(AAA_processed):
    """SAS DATA _NULL_; FILE INTRADAY; PUT ... RUN;"""
    logger.info(f"Writing INTRADAY file to {INTRADAY}")
    
    # Define output schema matching SAS PUT statement
    output_schema = [
        # Position 1-1: 'L'
        (0, 1, "RECORD_START"),
        # Position 2-2: 'D'
        (1, 1, "DEBIT_IND"),
        # Position 3-4: OBANKNO (PD2.)
        (2, 2, "OBANKNO"),
        # Position 5-10: ACCTNOS (PD6.)
        (4, 6, "ACCTNOS"),
        # Position 11-18: 'FPXOFIID'
        (10, 8, "FILLER_11_18"),
        # Position 19-20: TRANCODE (PD2.)
        (18, 2, "TRANCODE"),
        # Position 21-22: SOURCECD (PD2.)
        (20, 2, "SOURCECD"),
        # Position 23-30: CONTROL (PD8.)
        (22, 8, "CONTROL"),
        # Position 31-37: DAMOUNT (PD7.2)
        (30, 7, "DAMOUNT"),
        # Position 38-43: SERIALNO (PD6.)
        (37, 6, "SERIALNO"),
        # Position 44-44: 'L'
        (43, 1, "END_MARKER_44"),
        # Position 45-46: '04' or TRAILCNT (PD2.)
        (44, 2, "TRAILCNT_STR"),
        # Position 47-74: DTDFNO ($28.) - DP6377 - LONGTRL 1
        (46, 28, "DTDFNO"),
        # Position 75-75: SPACE ($1.) - DP6377
        (74, 1, "SPACE_1"),
        # Position 76-96: 'DIRECT DEBIT ' - DP6377
        (75, 21, "DIRECT_DEBIT_TEXT"),
        # Position 97-146: DTDFADD1 ($CHAR50.) - LONGTRL 2 - APPLICANT NAME
        (96, 50, "DTDFADD1_PROCESSED"),
        # Position 147-147: SPACE ($1.)
        (146, 1, "SPACE_2"),
        # Position 148-150: DOFIBANK ($3.) - OFI BANK ABBREVIATION
        (147, 3, "DOFIBANK"),
        # Position 151-200: PAYREF1 ($50.) - LONGTRL 3 - PAY DESCRIPTION
        (150, 50, "PAYREF1"),
        # Position 201-210: DTDFBLCD ($10.) - LONGTRL 4 - BILLER CODE
        (200, 10, "DTDFBLCD"),
        # Position 211-230: PAYREF2 ($20.) - RECEPIENT REFERENCE NO
        (210, 20, "PAYREF2"),
        # Position 231-231: DTDFDRTRY ($CHAR1.) - DEBIT RETRY
        (230, 1, "DTDFDRTRY"),
        # Position 232-232: DTDFACTYP ($CHAR1.) - ACCOUNT TYPE
        (231, 1, "DTDFACTYP_PROCESSED"),
        # Position 233-250: SPACE ($18.)
        (232, 18, "SPACE_3"),
        # Position 251-253: RESCODE ($3.) - LONGTRL 5 - RESIDENT CODE
        (250, 3, "RESCODE"),
        # Position 254-300: SPACE ($47.)
        (253, 47, "SPACE_4"),
        # Position 301-350: SPACE ($50.)
        (300, 50, "SPACE_5"),
        # Position 351-400: SPACE ($50.)
        (350, 50, "SPACE_6"),
        # Position 401-450: SPACE ($50.)
        (400, 50, "SPACE_7"),
        # Position 451-500: SPACE ($50.)
        (450, 50, "SPACE"),
        # Position 501-547: SPACE ($47.) - Additional spaces to reach 547 bytes
        (500, 47, "SPACE")
    ]
    
    # Prepare data for writing
    output_data = AAA_processed.select([
        # Convert all to string for fixed-width output
        pl.col("RECORD_START").cast(pl.Utf8),
        pl.col("DEBIT_IND").cast(pl.Utf8),
        pl.col("OBANKNO").cast(pl.Utf8).str.zfill(2),
        pl.col("ACCTNOS").cast(pl.Utf8).str.zfill(6),
        pl.col("FILLER_11_18").cast(pl.Utf8),
        pl.col("TRANCODE").cast(pl.Utf8).str.zfill(2),
        pl.col("SOURCECD").cast(pl.Utf8).str.zfill(2),
        pl.col("CONTROL").cast(pl.Utf8).str.zfill(8),
        # DAMOUNT: format as PD7.2 (7 digits, 2 decimal places, no decimal point)
        (pl.col("DAMOUNT") * 100).cast(pl.Int64).cast(pl.Utf8).str.zfill(7),
        pl.col("SERIALNO").cast(pl.Utf8).str.zfill(6),
        pl.col("END_MARKER_44").cast(pl.Utf8),
        pl.col("TRAILCNT_STR").cast(pl.Utf8),
        pl.col("DTDFNO").cast(pl.Utf8).str.slice(0, 28),
        pl.col("SPACE_1").cast(pl.Utf8),
        pl.col("DIRECT_DEBIT_TEXT").cast(pl.Utf8),
        pl.col("DTDFADD1_PROCESSED").cast(pl.Utf8).str.slice(0, 50).str.ljust(50),
        pl.col("SPACE_2").cast(pl.Utf8),
        pl.col("DOFIBANK").cast(pl.Utf8).str.slice(0, 3),
        pl.col("PAYREF1").cast(pl.Utf8).str.slice(0, 50).str.ljust(50),
        pl.col("DTDFBLCD").cast(pl.Utf8).str.slice(0, 10).str.ljust(10),
        pl.col("PAYREF2").cast(pl.Utf8).str.slice(0, 20).str.ljust(20),
        pl.col("DTDFDRTRY").cast(pl.Utf8).str.slice(0, 1),
        pl.col("DTDFACTYP_PROCESSED").cast(pl.Utf8).str.slice(0, 1),
        pl.col("SPACE_3").cast(pl.Utf8).str.ljust(18),
        pl.col("RESCODE").cast(pl.Utf8).str.slice(0, 3).str.ljust(3),
        pl.col("SPACE_4").cast(pl.Utf8).str.ljust(47),
        pl.col("SPACE_5").cast(pl.Utf8).str.ljust(50),
        pl.col("SPACE_6").cast(pl.Utf8).str.ljust(50),
        pl.col("SPACE_7").cast(pl.Utf8).str.ljust(50),
        pl.col("SPACE").cast(pl.Utf8).str.ljust(50),
        pl.col("SPACE").cast(pl.Utf8).str.ljust(47)  # Reuse SPACE for last 47 chars
    ])
    
    # Rename columns to match output schema names
    output_data = output_data.rename({
        "RECORD_START": "RECORD_START",
        "DEBIT_IND": "DEBIT_IND",
        "OBANKNO": "OBANKNO",
        "ACCTNOS": "ACCTNOS",
        "FILLER_11_18": "FILLER_11_18",
        "TRANCODE": "TRANCODE",
        "SOURCECD": "SOURCECD",
        "CONTROL": "CONTROL",
        "DAMOUNT": "DAMOUNT",
        "SERIALNO": "SERIALNO",
        "END_MARKER_44": "END_MARKER_44",
        "TRAILCNT_STR": "TRAILCNT_STR",
        "DTDFNO": "DTDFNO",
        "SPACE_1": "SPACE_1",
        "DIRECT_DEBIT_TEXT": "DIRECT_DEBIT_TEXT",
        "DTDFADD1_PROCESSED": "DTDFADD1_PROCESSED",
        "SPACE_2": "SPACE_2",
        "DOFIBANK": "DOFIBANK",
        "PAYREF1": "PAYREF1",
        "DTDFBLCD": "DTDFBLCD",
        "PAYREF2": "PAYREF2",
        "DTDFDRTRY": "DTDFDRTRY",
        "DTDFACTYP_PROCESSED": "DTDFACTYP_PROCESSED",
        "SPACE_3": "SPACE_3",
        "RESCODE": "RESCODE",
        "SPACE_4": "SPACE_4",
        "SPACE_5": "SPACE_5",
        "SPACE_6": "SPACE_6",
        "SPACE_7": "SPACE_7",
        "SPACE": "SPACE",
        "SPACE_right": "SPACE_END"
    })
    
    # Write using the existing fixed_width_reader write method
    # Note: We need to implement a write function similar to the read function
    write_fixed_width_file(INTRADAY, output_data, output_schema)
    
    logger.info(f"INTRADAY file created: {INTRADAY} with {len(output_data)} records")

def write_fixed_width_file(file_path, df, schema):
    """Write DataFrame to fixed-width file using the same pattern as read"""
    logger.info(f"Writing fixed-width file: {file_path}")
    
    with open(file_path, 'w') as f:
        for row in df.iter_rows(named=True):
            # Create a list of 547 spaces (total output length)
            line_chars = [' '] * 547
            
            # Fill in each field according to schema
            for start, width, field_name in schema:
                if field_name in row:
                    value = str(row[field_name])
                    # Truncate or pad as needed
                    if len(value) > width:
                        value = value[:width]
                    else:
                        value = value.ljust(width)
                    
                    # Put the value into the line
                    for i in range(width):
                        if start + i < 547:
                            line_chars[start + i] = value[i]
            
            # Write the line
            f.write(''.join(line_chars) + '\n')
    
    logger.info(f"Fixed-width file written: {file_path}")

def generate_report(AAA_processed):
    """Generate report file"""
    logger.info(f"Generating report to {OUTPUT_RPT}")
    
    with open(OUTPUT_RPT, 'w') as f:
        f.write("DPFPXINT - FORMAT INTRADAY FILE FOR FPX POSTING REPORT\n")
        f.write("=" * 80 + "\n\n")
        f.write(f"Processing Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"Total Records Processed: {len(AAA_processed)}\n\n")
        
        # DP changes implemented
        f.write("DP CHANGES IMPLEMENTED:\n")
        f.write("-" * 40 + "\n")
        f.write("DP1248: ACCRULE field added\n")
        f.write("DP1288: DREFMODE, DOFIBANK, RESCODE, DBUSSDTE fields added\n")
        f.write("DP1288: DTDFADD1, DTDFBLCD, DTDFADD2 fields added (CHAR format)\n")
        f.write("DP2094: BNKCODE logic updated\n")
        f.write("DP6377: DTDFNO changed from $50 to $28 (LONGTRL 1)\n")
        f.write("DP6377: Added 'DIRECT DEBIT ' text\n\n")
        
        # Statistics
        if len(AAA_processed) > 0:
            f.write("STATISTICS:\n")
            f.write("-" * 40 + "\n")
            
            if "DAMOUNT" in AAA_processed.columns:
                f.write(f"Total DAMOUNT: {AAA_processed['DAMOUNT'].sum():,.2f}\n")
                f.write(f"Average DAMOUNT: {AAA_processed['DAMOUNT'].mean():,.2f}\n")
                f.write(f"Maximum DAMOUNT: {AAA_processed['DAMOUNT'].max():,.2f}\n")
                f.write(f"Minimum DAMOUNT: {AAA_processed['DAMOUNT'].min():,.2f}\n\n")
            
            if "DTYPE" in AAA_processed.columns:
                f.write("TRANSACTION TYPE DISTRIBUTION:\n")
                type_counts = AAA_processed.group_by("DTYPE").agg(pl.count().alias("count"))
                for row in type_counts.iter_rows(named=True):
                    f.write(f"  Type {row['DTYPE']}: {row['count']} records\n")
            
            if "DSTATUS" in AAA_processed.columns:
                f.write("\nTRANSACTION STATUS DISTRIBUTION:\n")
                status_counts = AAA_processed.group_by("DSTATUS").agg(pl.count().alias("count"))
                for row in status_counts.iter_rows(named=True):
                    f.write(f"  Status {row['DSTATUS']}: {row['count']} records\n")
        
        f.write("\n" + "=" * 80 + "\n")
        f.write("END OF REPORT\n")

if __name__ == "__main__":
    main()