import polars as pl
import duckdb
from datetime import datetime, timedelta
import common.parquet_splitter as parquet_splitter
import common.data_cleaner as data_cleaner
import common.fixed_width_reader as fixed_width_reader
import os
import ast
import logging
from common.batch_date import get_batch_date

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# --- Obtain date for file paths ---
date_info = get_batch_date()
file_date = date_info["file_date"]
folder_day = date_info["folder_day"]
folder_month = date_info["folder_month"]
folder_year = date_info["folder_year"]

# --- Define Global File Paths (SAS Naming Convention) ---
table_layout_folder = "/host/dp/input/table_layout/lookup"

# SAS: INFILE INPUTF1 [cite: 7]
INPUTF1 = f"/host/dp/parquet/year={folder_year}/month={folder_month}/day={folder_day}/DPFEED03_CSSSCO01.parquet"

# SAS: INFILE CORPFILE [cite: 31]
CORPFILE = f"/host/dp/input/BANKCODE_{folder_year}{folder_month}{folder_day}.txt"

# SAS Output References [cite: 45, 67]
OUT1 = f"/host/dp/output/DP_SASSSC01_PYMT_RPT_{folder_year}{folder_month}{folder_day}.txt"
LNFILE = f"/host/dp/output/DPFPXMSR_CSV_{folder_year}{folder_month}{folder_day}.csv"

# --- Construct Table Layout File Path ---
program_name = os.path.basename(__file__).rsplit('.', maxsplit=1)[0]
inputf1_dsn = INPUTF1.rsplit('/', maxsplit=1)[1].rsplit('.', maxsplit=1)[0].split('_', maxsplit=1)[1]
inputf1_layout_path = f"{table_layout_folder}/{program_name}_{inputf1_dsn}.txt"

# --- Select Clause ---
select_clause = parquet_splitter.split(inputf1_layout_path)

# --- Business Logic Implementation ---

def generate_monthly_statistical_report():
    """
    Main migration logic for FPX DDS Monthly Statistical Report.
    Replicates SAS Data Steps: SOURCE1, CORPFL, MRG1, and SEG2.
    """
    
    # [DATA SOURCE1] Load Parquet source using layout select clause [cite: 7, 30]
    SOURCE1 = pl.read_parquet(INPUTF1).select(pl.col(select_clause))

    # [DATA CORPFL] Load Corporate details from fixed-width file [cite: 31, 33]
    # Schema extracted from SAS INPUT offsets: @11, @14, @24, @39 [cite: 31, 32, 33]
    corp_schema = [
        [10, 3, "INTERID"],
        [13, 10, "SELLACNO"],
        [23, 15, "CORPNAME"],
        [38, 3, "CORPCODE"]
    ]
    CORPFL = fixed_width_reader.read(CORPFILE, corp_schema)
    
    # Filter for EDP Interface [cite: 33]
    CORPFL = CORPFL.filter(pl.col("INTERID") == 'EDP')

    # [DATA MRG1] Merge primary data with corporate file by Seller Account [cite: 34]
    MRG1 = SOURCE1.join(CORPFL, on="SELLACNO", how="inner")

    # [DATA SEG2] Performance statistical aggregation [cite: 35, 36]
    # Logic mirrors SAS conditional summing for On-Us (Public Bank) vs Off-Us [cite: 39, 42]
    SEG2 = MRG1.with_columns([
        # Successful Transaction Classifiers [cite: 38, 39, 40]
        pl.when((pl.col("TSTATUS") == 'SC') & (pl.col("BUYBNKID") == 'PBB0233'))
        .then(1).otherwise(0).alias("_psuc_mark"),
        pl.when((pl.col("TSTATUS") == 'SC') & (pl.col("BUYBNKID") != 'PBB0233'))
        .then(1).otherwise(0).alias("_fsuc_mark"),
        
        # Rejected Transaction Classifiers [cite: 41, 42]
        pl.when((pl.col("TSTATUS") == 'BR') & (pl.col("BUYBNKID") == 'PBB0233'))
        .then(1).otherwise(0).alias("_prej_mark"),
        pl.when((pl.col("TSTATUS") == 'BR') & (pl.col("BUYBNKID") != 'PBB0233'))
        .then(1).otherwise(0).alias("_frej_mark"),
    ]).group_by(["CORPCODE", "CORPNAME"]).agg([
        # On-Us Statistics (PBB) [cite: 39]
        pl.col("_psuc_mark").sum().alias("PSUC1CNT"),
        pl.when(pl.col("_psuc_mark") == 1).then(pl.col("TRXAMNT")).otherwise(0).sum().alias("PSUC1AMT"),
        pl.col("_prej_mark").sum().alias("PREJ1CNT"),
        pl.when(pl.col("_prej_mark") == 1).then(pl.col("TRXAMNT")).otherwise(0).sum().alias("PREJ1AMT"),
        
        # Off-Us Statistics (FPX/Other Banks) [cite: 40, 42]
        pl.col("_fsuc_mark").sum().alias("FSUC1CNT"),
        pl.when(pl.col("_fsuc_mark") == 1).then(pl.col("TRXAMNT")).otherwise(0).sum().alias("FSUC1AMT"),
        pl.col("_frej_mark").sum().alias("FREJ1CNT"),
        pl.when(pl.col("_frej_mark") == 1).then(pl.col("TRXAMNT")).otherwise(0).sum().alias("FREJ1AMT")
    ])

    # Calculate Totals and Success/Reject Percentages [cite: 42, 43]
    SEG2 = SEG2.with_columns([
        (pl.col("PSUC1CNT") + pl.col("FSUC1CNT")).alias("TSUC1CNT"),
        (pl.col("PSUC1AMT") + pl.col("FSUC1AMT")).alias("TSUC1AMT"),
        (pl.col("PREJ1CNT") + pl.col("FREJ1CNT")).alias("TREJ1CNT"),
        (pl.col("PREJ1AMT") + pl.col("FREJ1AMT")).alias("TREJ1AMT")
    ]).with_columns([
        (pl.col("TSUC1CNT") + pl.col("TREJ1CNT")).alias("GTOTALCNT")
    ]).with_columns([
        ((pl.col("TSUC1CNT") / pl.col("GTOTALCNT")) * 100).alias("PERCSUC"),
        ((pl.col("TREJ1CNT") / pl.col("GTOTALCNT")) * 100).alias("PERCREJ")
    ])

    # [DATA _NULL_] Export to semicolon-delimited CSV (LNFILE) [cite: 67, 82, 83]
    # Replicates the format defined in the SAS PUT statements [cite: 83-97]
    output_columns = [
        "CORPNAME", "PSUC1CNT", "PSUC1AMT", "PREJ1CNT", "PREJ1AMT", 
        "FSUC1CNT", "FSUC1AMT", "FREJ1CNT", "FREJ1AMT", 
        "TSUC1CNT", "TSUC1AMT", "TREJ1CNT", "TREJ1AMT", 
        "PERCSUC", "PERCREJ"
    ]
    SEG2.select(output_columns).write_csv(LNFILE, separator=";")

if __name__ == "__main__":
    generate_monthly_statistical_report()