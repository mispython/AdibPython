# DPFPXOPR.py
# /* PROGRAM TO PRINT PAYMENT SUMMARY TO OPERATION */
# /* SMR2017-386 */

import polars as pl
from datetime import datetime, timedelta
import common.fixed_width_reader as fixed_width_reader
import os
from common.batch_date import get_batch_data
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Obtain date for file paths
date_info = get_batch_data()
file_date = date_info["file_date"]
folder_day = date_info["folder_day"]
folder_month = date_info["folder_month"]
folder_year = date_info["folder_year"]

# Define file paths - matching SAS convention
PROCFILE = f"/host/dp/input/fpx/PROCFILE_{folder_year}{folder_month}{folder_day}.dat"
CORPFILE = f"/host/dp/input/fpx/CORPFILE_{folder_year}{folder_month}{folder_day}.dat"
OPRRPT = f"/host/dp/output/DPFPXOPR_REPORT_{folder_year}{folder_month}{folder_day}.txt"

# --- Select Clause ---
select_clause_procfile = [
    ("FUNDACC", 10, 22),       # @023 FUNDACC      $10.
    ("SHRTNAME", 3, 32),       # @033 SHRTNAME     $3.
    ("AMOUNT", 7, 141),        # @142 AMOUNT      PD7.2
    ("ACCTSTAT", 2, 158),      # @159 ACCTSTAT     $2.
    ("FILENAME", 14, 230)      # @231 FILENAME    $14.
]

select_clause_corpfile = [
    ("FUNDACC", 10, 0),        # @001 FUNDACC      $10.
    ("LONGNAME", 15, 23),      # @024 LONGNAME    $15.
    ("SHRTNAME", 3, 38),       # @039 SHRTNAME     $3.
    ("BRHNO", 3, 43)           # @044 BRHNO       3.
]

def main():
    """SAS DPFPXOPR program converted to Python with same variable names"""
    
    try:
        logger.info("Starting DPFPXOPR - PROGRAM TO PRINT PAYMENT SUMMARY TO OPERATION")
        logger.info("SMR2017-386")
        
        # Step 1: Read PROCFILE into PROCFILE dataset
        logger.info(f"Reading PROCFILE from {PROCFILE}...")
        PROCFILE_data = read_PROCFILE()
        
        # Step 2: Sort PROCFILE by FILENAME
        logger.info("Sorting PROCFILE by FILENAME...")
        PROCFILE_data = PROCFILE_data.sort("FILENAME")
        
        # Step 3: Calculate aggregates - PROCCAL dataset
        logger.info("Creating PROCCAL dataset (calculating totals by FILENAME)...")
        PROCCAL = create_PROCCAL(PROCFILE_data)
        
        # Step 4: Sort PROCCAL by FILENAME, SHRTNAME, FUNDACC
        logger.info("Sorting PROCCAL...")
        PROCCAL = PROCCAL.sort(["FILENAME", "SHRTNAME", "FUNDACC"])
        
        # Step 5: Read CORPFILE into CORPDATA
        logger.info(f"Reading CORPFILE from {CORPFILE}...")
        CORPDATA = read_CORPFILE()
        
        # Step 6: Sort CORPDATA by SHRTNAME, FUNDACC
        logger.info("Sorting CORPDATA...")
        CORPDATA = CORPDATA.sort(["SHRTNAME", "FUNDACC"])
        
        # Step 7: Merge CORPDATA and PROCCAL to create FINALISE
        logger.info("Merging CORPDATA and PROCCAL to create FINALISE...")
        FINALISE = merge_CORPDATA_PROCCAL(CORPDATA, PROCCAL)
        
        # Step 8: Generate report
        logger.info(f"Generating report to {OPRRPT}...")
        generate_report(FINALISE)
        
        logger.info("DPFPXOPR processing completed successfully.")
        
    except Exception as e:
        logger.error(f"Error in DPFPXOPR processing: {str(e)}", exc_info=True)
        raise

def read_PROCFILE():
    """SAS DATA PROCFILE; INFILE PROCFILE; INPUT @023 FUNDACC ... @231 FILENAME ...; RUN;"""
    logger.info(f"Reading PROCFILE dataset from {PROCFILE}")
    
    # Define schema using select_clause_procfile
    schema = select_clause_procfile
    
    # Read using fixed_width_reader
    PROCFILE_data = fixed_width_reader.read(PROCFILE, schema)
    
    # Convert AMOUNT from PD7.2 format
    PROCFILE_data = PROCFILE_data.with_columns([
        pl.col("AMOUNT").cast(pl.Float64).alias("AMOUNT")
    ])
    
    logger.info(f"PROCFILE read with {len(PROCFILE_data)} records")
    return PROCFILE_data

def create_PROCCAL(PROCFILE_data):
    """SAS DATA PROCCAL(DROP=AMOUNT ACCTSTAT); SET PROCFILE; BY FILENAME; ... RUN;"""
    logger.info("Creating PROCCAL dataset (aggregating by FILENAME)")
    
    # Initialize accumulators
    proccal_rows = []
    
    # Group by FILENAME
    for filename in PROCFILE_data["FILENAME"].unique():
        filename_group = PROCFILE_data.filter(pl.col("FILENAME") == filename)
        
        # Initialize for each FILENAME group
        TOTCNT = 0
        REJCNT = 0
        SUCCNT = 0
        TOTAMT = 0.0
        REJAMT = 0.0
        SUCAMT = 0.0
        
        # Process each record in the group
        for row in filename_group.iter_rows(named=True):
            amount = float(row.get("AMOUNT", 0))
            acctstat = str(row.get("ACCTSTAT", ""))
            
            TOTCNT += 1
            TOTAMT += amount
            
            if acctstat != "BR":
                SUCCNT += 1
                SUCAMT += amount
            else:
                REJCNT += 1
                REJAMT += amount
        
        # Create output row (only output at LAST.FILENAME - take first record as template)
        first_row = filename_group.row(0, named=True)
        
        output_row = {
            "FILENAME": filename,
            "FUNDACC": first_row.get("FUNDACC"),
            "SHRTNAME": first_row.get("SHRTNAME"),
            "TOTCNT": TOTCNT,
            "REJCNT": REJCNT,
            "SUCCNT": SUCCNT,
            "TOTAMT": TOTAMT,
            "REJAMT": REJAMT,
            "SUCAMT": SUCAMT
        }
        
        proccal_rows.append(output_row)
    
    # Create DataFrame from rows
    if proccal_rows:
        PROCCAL = pl.DataFrame(proccal_rows)
    else:
        PROCCAL = pl.DataFrame({
            "FILENAME": [],
            "FUNDACC": [],
            "SHRTNAME": [],
            "TOTCNT": [],
            "REJCNT": [],
            "SUCCNT": [],
            "TOTAMT": [],
            "REJAMT": [],
            "SUCAMT": []
        })
    
    logger.info(f"PROCCAL created with {len(PROCCAL)} records")
    return PROCCAL

def read_CORPFILE():
    """SAS DATA CORPDATA; INFILE CORPFILE VSAM; INPUT @001 FUNDACC ... @044 BRHNO ...; RUN;"""
    logger.info(f"Reading CORPFILE dataset from {CORPFILE}")
    
    # Define schema using select_clause_corpfile
    schema = select_clause_corpfile
    
    # Read using fixed_width_reader
    CORPDATA = fixed_width_reader.read(CORPFILE, schema)
    
    # Convert BRHNO to integer
    CORPDATA = CORPDATA.with_columns([
        pl.col("BRHNO").cast(pl.Int64).alias("BRHNO")
    ])
    
    logger.info(f"CORPFILE read with {len(CORPDATA)} records")
    return CORPDATA

def merge_CORPDATA_PROCCAL(CORPDATA, PROCCAL):
    """SAS DATA FINALISE; MERGE CORPDATA(IN=A) PROCCAL(IN=B); BY SHRTNAME FUNDACC; IF B THEN OUTPUT; RUN;"""
    logger.info("Merging CORPDATA and PROCCAL to create FINALISE")
    
    # Perform left join (keep only records where B is present)
    FINALISE = CORPDATA.join(
        PROCCAL,
        on=["SHRTNAME", "FUNDACC"],
        how="inner"  # IF B THEN OUTPUT = inner join
    )
    
    logger.info(f"FINALISE created with {len(FINALISE)} records")
    return FINALISE

def generate_report(FINALISE):
    """SAS DATA _NULL_; FILE OPRRPT; ... PUT ... RUN;"""
    logger.info(f"Generating report to {OPRRPT}")
    
    if len(FINALISE) == 0:
        logger.warning("No records to report")
        with open(OPRRPT, 'w') as f:
            f.write("NO DATA AVAILABLE\n")
        return
    
    # Initialize variables
    CNT = 0
    TTOTAMT = 0.0
    TTOTCNT = 0
    TREJAMT = 0.0
    TREJCNT = 0
    TSUCAMT = 0.0
    TSUCCNT = 0
    TIFAMT = 0.0
    TIFCNT = 0
    
    # Get total number of records (NOBS=TRN in SAS)
    TRN = len(FINALISE)
    
    # Sort FINALISE if needed
    FINALISE_sorted = FINALISE.sort(["FUNDACC", "SHRTNAME"])
    
    with open(OPRRPT, 'w') as f:
        # Write page header
        pageno = 1
        write_page_header(f, pageno)
        linecnt = 5
        
        # Process each row
        for idx, row in enumerate(FINALISE_sorted.iter_rows(named=True)):
            # Check for page break (52 lines per page)
            if linecnt >= 52 and idx > 0:
                write_page_header(f, pageno + 1)
                pageno += 1
                linecnt = 5
            
            # Get values from row
            cnt_val = idx + 1
            fundacc = str(row.get("FUNDACC", "")).ljust(10)
            longname = str(row.get("LONGNAME", "")).ljust(14)
            brhno = int(row.get("BRHNO", 0))
            filename = str(row.get("FILENAME", "")).ljust(14)
            totamt = float(row.get("TOTAMT", 0))
            totcnt = int(row.get("TOTCNT", 0))
            rejamt = float(row.get("REJAMT", 0))
            rejcnt = int(row.get("REJCNT", 0))
            sucamt = float(row.get("SUCAMT", 0))
            succnt = int(row.get("SUCCNT", 0))
            
            # Check for insufficient flag (IF REMARK EQ 'IF')
            remark = ""
            if totcnt >= 2:
                totcnt_adj = totcnt - 2
                tifamt_adj = totamt
                tifcnt_adj = totcnt
            else:
                totcnt_adj = totcnt
                tifamt_adj = 0.0
                tifcnt_adj = 0
            
            # Accumulate totals
            TTOTAMT += totamt
            TTOTCNT += totcnt
            TREJAMT += rejamt
            TREJCNT += rejcnt
            TSUCAMT += sucamt
            TSUCCNT += succnt
            
            if remark == "IF":
                TIFAMT += tifamt_adj
                TIFCNT += tifcnt_adj
            
            CNT += 1
            
            # Write detail line
            detail_line = (f"{cnt_val:03d} {fundacc:10} {longname:14} {brhno:3d} "
                          f"{filename:14} {totamt:16,.2f} {totcnt:7d} "
                          f"{rejamt:15,.2f} {rejcnt:7d} {sucamt:15,.2f} "
                          f"{succnt:7d} {remark:2}")
            f.write(detail_line + "\n")
            linecnt += 1
            
            # Check if end of file (EOF equivalent)
            if idx == TRN - 1:
                # Write totals section
                write_totals_section(f, CNT, TTOTCNT, TTOTAMT, TSUCCNT, TSUCAMT,
                                   TREJCNT, TREJAMT, TIFCNT, TIFAMT)
    
    logger.info(f"Report generated: {OPRRPT}")

def write_page_header(f, pageno):
    """Write page header matching SAS NEWPAGE section"""
    current_date = datetime.now()
    report_date = current_date.strftime("%d/%m/%y")
    report_time = current_date.strftime("%H:%M:%S")
    
    f.write("REPORT NO   : FPX/OPR/001     P U B L I C  B A N K  B E R H A D")
    f.write(f"                                                    PAGE        : {pageno:4d}\n")
    f.write("PROGRAM ID  : DPFPXOPR        SUMMARY REPORT OF ALL MYCLEAR FPX PAYMENT PROCESSED")
    f.write(f"                              REPORT DATE : {report_date}\n")
    f.write(f"                                                                                 TIME        : {report_time}\n")
    f.write("\n\n\n")
    f.write("NO  ACCOUNT NO   CORPORATE NAME       BRH  PYMTFILE NAME     PAYMENT AMOUNT  PYMT CNT  REJECTED AMOUNT  REJ CNT  SUCCESS AMOUNT  SUC CNT  REMARK\n")
    f.write("--- -----------  ----------------    ---  ---------------  ---------------  -------  ---------------  -------  ---------------  -------  ------\n")

def write_totals_section(f, cnt, ttotcnt, ttotamt, tsuccnt, tsucamt, trejcnt, trejamt, tifcnt, tifamt):
    """Write totals section matching SAS END section"""
    f.write("\n============================\n")
    f.write(f"TOTAL NO OF CORP      : {cnt:7d}\n")
    f.write(f"TOTAL PAYMENT COUNT   : {ttotcnt:7d}\n")
    f.write(f"TOTAL PAYMENT AMOUNT  : {ttotamt:16,.2f}\n")
    f.write(f"TOTAL PROCESSED COUNT : {tsuccnt:7d}\n")
    f.write(f"TOTAL PROCESSED AMOUNT: {tsucamt:16,.2f}\n")
    f.write(f"TOTAL REJECTED COUNT  : {trejcnt:7d}\n")
    f.write(f"TOTAL REJECTED AMOUNT : {trejamt:16,.2f}\n")
    f.write(f"TOTAL INSUFFICIENT CNT: {tifcnt:7d}\n")
    f.write(f"TOTAL INSUFFICIENT AMT: {tifamt:16,.2f}\n")
    f.write("============================\n")
    f.write("\n\nCHECKED BY\n")
    f.write("\nOS/CO : ____________________    INITIAL : ____________________    DATE/TIME : ____________________\n")
    f.write("\nSOS   : ____________________    INITIAL : ____________________    DATE/TIME : ____________________\n")
    f.write("\nSCOS  : ____________________    INITIAL : ____________________    DATE/TIME : ____________________\n")

if __name__ == "__main__":
    main()
