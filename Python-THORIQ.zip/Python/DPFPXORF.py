# DPFPXORF.py
# /****    *   *   *   *   *   * * *   *   *   *   *   *   *   *    ****/
# /****                        DP8168                               ****/
# /**** GENERATE FPX MONTHLY REFUND REPORT FROM MAFPXTXT DB2        ****/
# /****    *   *   *   *   *   *   *   *   *   *   *   *   *   *    ****/

import polars as pl
from datetime import datetime
import common.fixed_width_reader as fixed_width_reader
from common.batch_date import get_batch_data
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Obtain date for file paths
date_info = get_batch_data()
file_date = date_info["file_date"]
folder_day = date_info["folder_day"]
folder_month = date_info["folder_month"]
folder_year = date_info["folder_year"]

# Define file paths - matching SAS convention
CTRLDATE = f"/host/dp/input/fpx/CTRLDATE_{folder_year}{folder_month}{folder_day}.dat"
DB2TRXF = f"/host/dp/input/fpx/DB2TRXF_{folder_year}{folder_month}{folder_day}.dat"
RPT01 = f"/host/dp/output/DPFPXORF_REPORT_{folder_year}{folder_month}{folder_day}.txt"

# --- Select Clause ---
select_clause_db2trx = [
    ("TRANS_ID", 16, 0),          # @001 TRANS_ID         $16.
    ("TOKEN", 2, 16),              # @017 TOKEN             $2.
    ("SELLER_ID", 10, 18),         # @019 SELLER_ID        $10.
    ("SELLER_ACCT", 20, 28),       # @029 SELLER_ACCT      $20.
    ("SELLER_NAME", 30, 48),       # @049 SELLER_NAME      $30.
    ("SELLER_BANK_ID", 15, 79),    # @080 SELLER_BANK_ID   $15.
    ("BUYER_BANK_ID", 15, 94),     # @095 BUYER_BANK_ID    $15.
    ("TRANS_FEE", 5, 109),         # @110 TRANS_FEE          5.2
    ("DB_AMOUNT", 13, 120),        # @121 DB_AMOUNT         13.2
    ("BUYER_ACCTNO", 20, 134),     # @135 BUYER_ACCTNO     $20.
    ("BUYER_NAME", 40, 154),       # @155 BUYER_NAME       $40.
    ("BUYER_ID", 10, 194),         # @195 BUYER_ID         $10.
    ("DB_TIMESTAMP", 26, 204)      # @205 DB_TIMESTAMP     $26.
]

def main():
    """SAS DPFPXORF program converted to Python with same variable names"""
    
    try:
        logger.info("Starting DPFPXORF - GENERATE FPX MONTHLY REFUND REPORT FROM MAFPXTXT DB2")
        logger.info("DP8168")
        
        # Step 1: Read control date from CTRLDATE
        logger.info(f"Reading CTRLDATE from {CTRLDATE}...")
        BDATE, SDATE = read_BATDATE()
        
        # Step 2: Read transaction data from DB2TRXF into DB2TRX
        logger.info(f"Reading DB2TRX from {DB2TRXF}...")
        DB2TRX = read_DB2TRX()
        
        # Step 3: Sort DB2TRX by BUYER_NAME (equivalent to PROC SORT)
        logger.info("Sorting DB2TRX by BUYER_NAME...")
        DB2TRX = DB2TRX.sort("BUYER_NAME")
        
        # Step 4: Print DB2TRX (PROC PRINT equivalent)
        logger.info("PROC PRINT equivalent - DB_ORF dataset created")
        
        # Step 5: Generate report
        logger.info(f"Generating ORF report to {RPT01}...")
        generate_report(DB2TRX, BDATE, SDATE)
        
        logger.info("DPFPXORF processing completed successfully.")
        
    except Exception as e:
        logger.error(f"Error in DPFPXORF processing: {str(e)}", exc_info=True)
        raise

def read_BATDATE():
    """SAS DATA BATDATE; INFILE CTRLDATE; INPUT @01 BATCHDTE YYMMDD8.; ... RUN;"""
    logger.info(f"Reading batch date from {CTRLDATE}")
    
    try:
        with open(CTRLDATE, 'r') as f:
            # Read first line and parse as YYMMDD8 format
            line = f.readline().strip()
            
            if len(line) >= 8:
                yy = line[0:2]
                mm = line[2:4]
                dd = line[4:6]
                
                # Convert YYMMDD to DDMMYY format
                # Assuming YY is 20YY for 00-99
                year = "20" + yy if int(yy) < 100 else yy
                BDATE = f"{dd}/{mm}/{year}"
                SDATE = f"01/{mm}/{year}"
                
                logger.info(f"Batch Date: {BDATE}, Start Date: {SDATE}")
                return BDATE, SDATE
            else:
                logger.warning(f"CTRLDATE line too short: {line}")
                # Use current date as fallback
                current_date = datetime.now()
                BDATE = current_date.strftime("%d/%m/%Y")
                SDATE = current_date.strftime("01/%m/%Y")
                return BDATE, SDATE
                
    except FileNotFoundError:
        logger.warning(f"CTRLDATE file not found, using current date")
        current_date = datetime.now()
        BDATE = current_date.strftime("%d/%m/%Y")
        SDATE = current_date.strftime("01/%m/%Y")
        return BDATE, SDATE

def read_DB2TRX():
    """SAS DATA DB2TRX; INFILE DB2TRXF MISSOVER; INPUT @001 TRANS_ID ... @205 DB_TIMESTAMP ...; RUN;"""
    logger.info(f"Reading DB2TRX from {DB2TRXF}")
    
    # Define schema using select_clause_db2trx
    schema = select_clause_db2trx
    
    # Read using fixed_width_reader
    DB2TRX = fixed_width_reader.read(DB2TRXF, schema)
    
    # Convert TRANS_FEE and DB_AMOUNT to float (5.2 and 13.2 formats)
    DB2TRX = DB2TRX.with_columns([
        pl.col("TRANS_FEE").cast(pl.Float64).alias("TRANS_FEE"),
        pl.col("DB_AMOUNT").cast(pl.Float64).alias("DB_AMOUNT")
    ])
    
    logger.info(f"DB2TRX read with {len(DB2TRX)} records")
    return DB2TRX

def generate_report(DB2TRX, BDATE, SDATE):
    """SAS DATA REPORT; SET DB2TRX END=EOF; BY BUYER_NAME; ... FILE RPT01; PUT ... RUN;"""
    logger.info(f"Generating ORF report to {RPT01}")
    
    if len(DB2TRX) == 0:
        logger.warning("No records to report")
        with open(RPT01, 'w') as f:
            f.write("NO DATA AVAILABLE\n")
        return
    
    # Initialize variables
    CNT = 0
    TOTCNT = 0.0
    TOTFEE = 0.0
    
    with open(RPT01, 'w') as f:
        # Write header section (only at _N_ = 1, which is FIRST record)
        write_report_header(f, SDATE, BDATE)
        
        # Process each buyer group
        previous_buyer = None
        cnt1 = 0
        feeamount = 0.0
        totamount = 0.0
        
        for idx, row in enumerate(DB2TRX.iter_rows(named=True)):
            buyer_name = str(row.get("BUYER_NAME", "")).strip()
            
            # Check for FIRST.BUYER_NAME
            if buyer_name != previous_buyer:
                # FIRST.BUYER_NAME processing
                cnt1 = 0
                feeamount = 0.0
                totamount = 0.0
                previous_buyer = buyer_name
            
            # Accumulate
            trans_fee = float(row.get("TRANS_FEE", 0))
            feeamount += trans_fee
            
            # Check for LAST.BUYER_NAME (next row has different buyer or EOF)
            is_last_buyer = False
            if idx < len(DB2TRX) - 1:
                next_row = DB2TRX.row(idx + 1, named=True)
                next_buyer = str(next_row.get("BUYER_NAME", "")).strip()
                if next_buyer != buyer_name:
                    is_last_buyer = True
            else:
                is_last_buyer = True  # Last record is always LAST
            
            if is_last_buyer:
                # IF LAST.BUYER_NAME THEN DO;
                cnt = feeamount / 0.5
                TOTCNT += cnt
                TOTFEE += feeamount
                
                buyer_name_str = str(row.get("BUYER_NAME", "")).ljust(40)
                buyer_id_str = str(row.get("BUYER_ID", "")).ljust(10)
                buyer_acctno_str = str(row.get("BUYER_ACCTNO", "")).ljust(20)
                
                detail_line = (f"|{buyer_name_str:40}|{buyer_id_str:10}|"
                             f"{buyer_acctno_str:20}|{feeamount:12,.2f}|"
                             f"0.50{' '*11}|{cnt:9,.0f}|")
                f.write(detail_line + "\n")
        
        # Write totals (EOF section)
        write_report_totals(f, TOTFEE, TOTCNT)
    
    logger.info(f"ORF report generated: {RPT01}")

def write_report_header(f, SDATE, BDATE):
    """Write report header section matching SAS PUT statements"""
    
    f.write("|" + " "*50 + "||||P U B L I C  B A N K  B H D\n")
    f.write("|" + " "*30 + "|||FPX ONLINE REFUND TRANSACTION FROM")
    f.write(f"{SDATE:>12} UNTIL {BDATE:>8}\n")
    
    f.write("|" + " "*38 + "|")
    f.write("FPX BUYER" + " "*30 + "|")
    f.write("FPX BUYER" + " "*10 + "|")
    f.write("PBB DEBITING" + " "*9 + "|")
    f.write("TOTAL FEE" + " "*2 + "|")
    f.write("ORF FEE PER" + " "*14 + "|")
    f.write("NO.OF ORF" + " "*7 + "|\n")
    
    f.write("|" + " "*38 + "|")
    f.write("  NAME    " + " "*30 + "|")
    f.write("   ID " + " "*5 + "|")
    f.write("ACCOUNT NUMBER" + " "*0 + "|")
    f.write("   (RM)   " + " "*0 + "|")
    f.write("TRANSACTION (RM)" + " "*0 + "|")
    f.write("  COUNT  " + " "*0 + "|\n")
    
    f.write("|" + " "*38 + "|")
    f.write("          " + " "*30 + "|")
    f.write("      " + " "*5 + "|")
    f.write("              " + " "*0 + "|")
    f.write("   (A)   " + " "*0 + "|")
    f.write("  @RM0.50  (B)  " + " "*0 + "|")
    f.write(" C = A/B  " + " "*0 + "|\n")
    f.write("\n")

def write_report_totals(f, TOTFEE, TOTCNT):
    """Write totals section matching SAS EOF PUT statements"""
    f.write("|" + " "*38 + "|" + " "*10 + "|")
    f.write("   TOTAL    " + " "*8 + "|")
    f.write(f"{TOTFEE:12,.2f}|" + " "*15 + "|")
    f.write(f"{TOTCNT:9,.0f}|\n")

if __name__ == "__main__":
    main()
