# DPFPXR2M.py
# /* GENERATE FPX MONTHLY REPORT (ALL FPX PCS AND E-MANDATE PCS) */
# /* ONLY SUCCESSFUL TRX (GRAB FROM TRANSACTION HISTORY) */
# /* DP7781 - Extends DPFPXR2D with two additional reports */

import polars as pl
from datetime import datetime, timedelta
import common.fixed_width_reader as fixed_width_reader
from common.batch_date import get_batch_date
import os
import logging
import math

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Obtain date for file paths
date_info = get_batch_date()
file_date = date_info["file_date"]
folder_day = date_info["folder_day"]
folder_month = date_info["folder_month"]
folder_year = date_info["folder_year"]

# Define file paths
CTRLDATE = f"/host/dp/input/fpx/CTRLDATE_{folder_year}{folder_month}{folder_day}.dat"
TRBLGS = f"/host/dp/input/fpx/TRBLGS_{folder_year}{folder_month}{folder_day}.dat"
MAFPXSAT = f"/host/dp/input/fpx/MAFPXSAT_{folder_year}{folder_month}{folder_day}.dat"
IMSTRXF = f"/host/dp/input/fpx/IMSTRXF_{folder_year}{folder_month}{folder_day}.dat"
DB2TRXF = f"/host/dp/input/fpx/DB2TRXF_{folder_year}{folder_month}{folder_day}.dat"
RPT01 = f"/host/dp/output/DPFPXR2M_REPORT_{folder_year}{folder_month}{folder_day}.txt"
RPT02 = f"/host/dp/output/DPFPXR2M_NOTINDB2_{folder_year}{folder_month}{folder_day}.txt"
RPT03 = f"/host/dp/output/DPFPXR2M_NOCHARGESELLER_{folder_year}{folder_month}{folder_day}.txt"

def main():
    """SAS DPFPXR2M program - FPX Monthly Report Generation"""
    
    try:
        logger.info("Starting DPFPXR2M - FPX MONTHLY REPORT GENERATION")
        
        # Step 1: Get report start date
        batch_date = read_batch_date()
        if not batch_date:
            logger.error("Failed to read batch date")
            return
        
        logger.info(f"Batch date: {batch_date['BDATE']}")
        
        # Step 2: Read business registration number
        TRBLGS_data = read_trblgs()
        
        # Step 3: Read PBB Seller PC from DB2 MAFPXSAT
        MAFPXSAT_data = read_mafpxsat()
        
        # Step 4: Merge PC with business registration
        PCLIST = merge_pc_list(MAFPXSAT_data, TRBLGS_data)
        
        # Step 5: Read successful transaction history
        IMSTRX, IMSFEE = read_transaction_history()
        
        # Step 6: Merge transaction with fee
        IMSTRXFEE, IMSNTRXFEE = merge_trx_fee(IMSTRX, IMSFEE)
        
        # Step 7: Read DB2 transactions
        DB2TRX = read_db2_transactions()
        
        # Step 8: Merge all accounts
        ALLDB = merge_all_db(PCLIST, DB2TRX)
        
        # Step 9: Final merge with transaction history
        ALLACC, IMSSDBN = merge_final(ALLDB, IMSTRXFEE)
        
        # Step 10: Sum transactions by group
        FPXTXTSUM = sum_transactions(ALLACC)
        
        # Step 11: Calculate remarks and generate main report (RPT01)
        ALL_ACCT = calculate_remarks(FPXTXTSUM)
        logger.info(f"Writing main report to {RPT01}")
        generate_report1(ALL_ACCT, batch_date, RPT01)
        
        # Step 12: Generate REPORT2 - Posted transactions not in DB2 (RPT02)
        logger.info(f"Writing REPORT2 (not in DB2) to {RPT02}")
        generate_report2(IMSSDBN, batch_date, RPT02)
        
        # Step 13: Generate REPORT3 - TRX with no fee charge on seller (RPT03)
        logger.info(f"Writing REPORT3 (no charge seller) to {RPT03}")
        generate_report3(IMSNTRXFEE, batch_date, RPT03)
        
        logger.info("DPFPXR2M processing completed successfully.")
        
    except Exception as e:
        logger.error(f"Error in DPFPXR2M processing: {str(e)}")
        raise

def read_batch_date():
    """Read batch date from control file"""
    
    try:
        if not os.path.exists(CTRLDATE):
            logger.warning(f"File not found: {CTRLDATE}")
            return None
        
        with open(CTRLDATE, 'r') as f:
            line = f.readline().strip()
            if len(line) >= 8:
                yy = line[0:2]
                mm = line[2:4]
                dd = line[4:6]
                
                bdate = f"{dd}/{mm}/20{yy}"
                sdate = f"01/{mm}/20{yy}"
                
                return {
                    "BDATE": bdate,
                    "SDATE": sdate,
                    "DATEYY": yy,
                    "DATEMM": mm,
                    "DATEDD": dd
                }
    except Exception as e:
        logger.error(f"Error reading batch date: {str(e)}")
    
    return None

def read_trblgs():
    """Read business registration number from TRBLGS file"""
    
    logger.info(f"Reading TRBLGS from {TRBLGS}")
    
    if not os.path.exists(TRBLGS):
        logger.warning(f"File not found: {TRBLGS}")
        return pl.DataFrame()
    
    records = []
    try:
        with open(TRBLGS, 'r') as f:
            for line in f:
                if len(line) < 776:
                    continue
                
                try:
                    reptno = line[23:26].strip() if len(line) > 25 else ""
                    fmtcode = line[26:28].strip() if len(line) > 27 else ""
                    
                    if reptno == "1001" and fmtcode == "001":
                        acctno = line[109:115].strip() if len(line) > 114 else ""
                        busreg = line[775:787].strip() if len(line) > 786 else ""
                        
                        records.append({"ACCTNO": acctno, "BUSREG": busreg})
                except:
                    continue
        
        if records:
            df = pl.DataFrame(records)
            logger.info(f"TRBLGS loaded with {len(df)} records")
            return df
        return pl.DataFrame()
    except Exception as e:
        logger.error(f"Error reading TRBLGS: {str(e)}")
        return pl.DataFrame()

def read_mafpxsat():
    """Read MAFPXSAT"""
    
    logger.info(f"Reading MAFPXSAT from {MAFPXSAT}")
    
    if not os.path.exists(MAFPXSAT):
        logger.warning(f"File not found: {MAFPXSAT}")
        return pl.DataFrame()
    
    records = []
    try:
        with open(MAFPXSAT, 'r') as f:
            for line in f:
                if len(line) < 20:
                    continue
                try:
                    seller_id = line[0:10].strip() if len(line) > 9 else ""
                    acctno = line[10:20].strip() if len(line) > 19 else ""
                    keya = acctno + seller_id
                    records.append({"SELLER_ID": seller_id, "ACCTNO": acctno, "KEYA": keya})
                except:
                    continue
        
        if records:
            df = pl.DataFrame(records)
            logger.info(f"MAFPXSAT loaded with {len(df)} records")
            return df
        return pl.DataFrame()
    except Exception as e:
        logger.error(f"Error reading MAFPXSAT: {str(e)}")
        return pl.DataFrame()

def merge_pc_list(mafpxsat, trblgs):
    """Merge PC with business registration"""
    
    logger.info("Merging MAFPXSAT with TRBLGS")
    
    if len(mafpxsat) == 0:
        return pl.DataFrame()
    
    merged = mafpxsat.join(trblgs, on="ACCTNO", how="left")
    logger.info(f"PCLIST created with {len(merged)} records")
    return merged

def read_transaction_history():
    """Read successful transaction history"""
    
    logger.info(f"Reading transaction history from {IMSTRXF}")
    
    if not os.path.exists(IMSTRXF):
        logger.warning(f"File not found: {IMSTRXF}")
        return pl.DataFrame(), pl.DataFrame()
    
    imstrx_records = []
    imsfee_records = []
    
    try:
        with open(IMSTRXF, 'r') as f:
            for line in f:
                if len(line) < 620:
                    continue
                
                try:
                    tran_code = int(line[611:614].strip() if len(line) > 613 else "0")
                    
                    if tran_code == 606:
                        acctno = line[8:18].strip() if len(line) > 17 else ""
                        process_date = line[19:27].strip() if len(line) > 26 else ""
                        data_type = line[27:28].strip() if len(line) > 27 else ""
                        trans_id = line[51:67].strip() if len(line) > 66 else ""
                        buyer_bank_id = line[265:280].strip() if len(line) > 279 else ""
                        amount = float(line[576:589].strip() if len(line) > 588 else "0") / 100
                        serial_number = line[590:600].strip() if len(line) > 599 else ""
                        keyb = acctno + serial_number
                        
                        imstrx_records.append({
                            "ACCTNO": acctno,
                            "DATA_TYPE": data_type,
                            "TRANS_ID": trans_id,
                            "AMOUNT": amount,
                            "KEYB": keyb,
                            "PROCESS_DATE": process_date,
                            "BUYER_BANK_ID": buyer_bank_id,
                            "POST_FEE": 0
                        })
                    
                    elif tran_code == 816:
                        acctno = line[8:18].strip() if len(line) > 17 else ""
                        post_fee = float(line[576:589].strip() if len(line) > 588 else "0") / 100
                        serial_number = line[590:600].strip() if len(line) > 599 else ""
                        keyb = acctno + serial_number
                        
                        imsfee_records.append({
                            "POST_FEE": post_fee,
                            "KEYB": keyb
                        })
                except:
                    continue
        
        imstrx = pl.DataFrame(imstrx_records) if imstrx_records else pl.DataFrame()
        imsfee = pl.DataFrame(imsfee_records) if imsfee_records else pl.DataFrame()
        
        logger.info(f"IMSTRX: {len(imstrx)} records, IMSFEE: {len(imsfee)} records")
        return imstrx, imsfee
    except Exception as e:
        logger.error(f"Error reading transaction history: {str(e)}")
        return pl.DataFrame(), pl.DataFrame()

def merge_trx_fee(imstrx, imsfee):
    """Merge transaction with fee"""
    
    if len(imstrx) == 0:
        return pl.DataFrame(), pl.DataFrame()
    
    imstrxfee = imstrx.join(imsfee, on="KEYB", how="left")
    imsntrxfee = imstrx.join(imsfee, on="KEYB", how="anti")
    
    logger.info(f"IMSTRXFEE: {len(imstrxfee)} records, IMSNTRXFEE: {len(imsntrxfee)} records")
    return imstrxfee, imsntrxfee

def read_db2_transactions():
    """Read DB2 transactions"""
    
    logger.info(f"Reading DB2 transactions from {DB2TRXF}")
    
    if not os.path.exists(DB2TRXF):
        logger.warning(f"File not found: {DB2TRXF}")
        return pl.DataFrame()
    
    records = []
    try:
        with open(DB2TRXF, 'r') as f:
            for line in f:
                if len(line) < 250:
                    continue
                
                try:
                    seller_id = line[0:10].strip() if len(line) > 9 else ""
                    seller_name = line[10:40].strip() if len(line) > 39 else ""
                    acctno = line[41:51].strip() if len(line) > 50 else ""
                    trans_id = line[61:77].strip() if len(line) > 76 else ""
                    b2b_b2c_ind = line[108:111].strip() if len(line) > 110 else ""
                    onoff = line[117:124].strip() if len(line) > 123 else ""
                    casacard = line[124:131].strip() if len(line) > 130 else ""
                    channel = line[134:140].strip() if len(line) > 139 else ""
                    db_seller_fee = float(line[159:164].strip() if len(line) > 163 else "0") / 100
                    db_buyer_fee = float(line[165:170].strip() if len(line) > 169 else "0") / 100
                    db_percent_on = float(line[171:176].strip() if len(line) > 175 else "0") / 100
                    db_percent_off = float(line[177:182].strip() if len(line) > 181 else "0") / 100
                    db_memo = line[232:233].strip() if len(line) > 232 else ""
                    
                    keya = acctno + seller_id
                    keyc = f"{acctno}{seller_id}{b2b_b2c_ind}{casacard}{onoff}{channel}"
                    
                    cnt = 1 if trans_id and trans_id.strip() else 0
                    source_ind = onoff + casacard
                    
                    records.append({
                        "SELLER_ID": seller_id,
                        "SELLER_NAME": seller_name,
                        "ACCTNO": acctno,
                        "TRANS_ID": trans_id,
                        "B2B_B2C_IND": b2b_b2c_ind,
                        "ONOFF": onoff,
                        "CASACARD": casacard,
                        "CHANNEL": channel,
                        "DB_SELLER_FEE": db_seller_fee,
                        "DB_BUYER_FEE": db_buyer_fee,
                        "DB_PERCENT_ON": db_percent_on,
                        "DB_PERCENT_OFF": db_percent_off,
                        "DB_MEMO": db_memo,
                        "KEYA": keya,
                        "KEYC": keyc,
                        "CNT": cnt,
                        "SOURCE_IND": source_ind
                    })
                except:
                    continue
        
        if records:
            df = pl.DataFrame(records)
            logger.info(f"DB2TRX loaded with {len(df)} records")
            return df
        return pl.DataFrame()
    except Exception as e:
        logger.error(f"Error reading DB2 transactions: {str(e)}")
        return pl.DataFrame()

def merge_all_db(pclist, db2trx):
    """Merge PCLIST with DB2TRX"""
    
    if len(pclist) == 0 or len(db2trx) == 0:
        return pl.DataFrame()
    
    merged = pclist.join(db2trx, on="KEYA", how="inner")
    logger.info(f"ALLDB created with {len(merged)} records")
    return merged

def merge_final(alldb, imstrxfee):
    """Final merge with transaction history"""
    
    if len(alldb) == 0:
        return pl.DataFrame(), pl.DataFrame()
    
    allacc_records = []
    imssdbn_records = []
    
    merged = alldb.join(imstrxfee, on="TRANS_ID", how="outer")
    
    for row in merged.iter_rows(named=True):
        has_e = row.get("KEYA") is not None
        has_f = row.get("KEYB") is not None
        
        if has_e and has_f:
            casacard = row.get("CASACARD", "")
            onoff = row.get("ONOFF", "")
            amount = row.get("AMOUNT", 0) or 0
            db_seller_fee = row.get("DB_SELLER_FEE", 0) or 0
            db_percent_on = row.get("DB_PERCENT_ON", 0) or 0
            db_percent_off = row.get("DB_PERCENT_OFF", 0) or 0
            cnt = row.get("CNT", 0) or 0
            
            if casacard == "CASA   ":
                debit_fee = cnt * db_seller_fee
            else:
                if onoff == "OFF-US ":
                    debit_fee = (cnt * db_seller_fee) + ((db_percent_off / 100) * amount)
                else:
                    debit_fee = (cnt * db_seller_fee) + ((db_percent_on / 100) * amount)
            
            debit_fee = round(debit_fee, 2)
            row_copy = dict(row)
            row_copy["DEBIT_FEE"] = debit_fee
            allacc_records.append(row_copy)
        
        elif has_e and not has_f:
            row_copy = dict(row)
            row_copy["CNT"] = 0
            row_copy["AMOUNT"] = 0
            row_copy["DEBIT_FEE"] = 0
            row_copy["POST_FEE"] = 0
            allacc_records.append(row_copy)
        
        else:
            imssdbn_records.append(row)
    
    allacc = pl.DataFrame(allacc_records) if allacc_records else pl.DataFrame()
    imssdbn = pl.DataFrame(imssdbn_records) if imssdbn_records else pl.DataFrame()
    
    logger.info(f"ALLACC: {len(allacc)} records, IMSSDBN: {len(imssdbn)} records")
    return allacc, imssdbn

def sum_transactions(allacc):
    """Sum transactions by KEYC group"""
    
    if len(allacc) == 0:
        return pl.DataFrame()
    
    summary = allacc.group_by("KEYC").agg([
        pl.col("CNT").sum().alias("TCNT"),
        pl.col("AMOUNT").sum().alias("TAMOUNT"),
        pl.col("DEBIT_FEE").sum().alias("TDEBIT_FEE"),
        pl.col("POST_FEE").sum().alias("TPOST_FEE"),
        pl.first("SELLER_ID").alias("SELLER_ID"),
        pl.first("SELLER_NAME").alias("SELLER_NAME"),
        pl.first("ACCTNO").alias("ACCTNO"),
        pl.first("B2B_B2C_IND").alias("B2B_B2C_IND"),
        pl.first("SOURCE_IND").alias("SOURCE_IND"),
        pl.first("CHANNEL").alias("CHANNEL"),
        pl.first("DB_SELLER_FEE").alias("DB_SELLER_FEE"),
        pl.first("DB_BUYER_FEE").alias("DB_BUYER_FEE"),
        pl.first("DB_PERCENT_ON").alias("DB_PERCENT_ON"),
        pl.first("DB_PERCENT_OFF").alias("DB_PERCENT_OFF"),
        pl.first("DB_MEMO").alias("DB_MEMO"),
        pl.first("BUSREG").alias("BUSREG")
    ]).sort("KEYC", descending=True)
    
    logger.info(f"FPXTXTSUM created with {len(summary)} summary records")
    return summary

def calculate_remarks(fpxtxtsum):
    """Calculate remarks for each group"""
    
    remarks_list = []
    
    for row in fpxtxtsum.iter_rows(named=True):
        row_copy = dict(row)
        
        tdebit_fee = round(row.get("TDEBIT_FEE", 0) or 0, 2)
        tpost_fee = round(row.get("TPOST_FEE", 0) or 0, 2)
        tcnt = row.get("TCNT", 0) or 0
        db_memo = row.get("DB_MEMO", "") or ""
        db_seller_fee = row.get("DB_SELLER_FEE", 0) or 0
        
        if db_memo == "M":
            remarks = "MEMO CHARGE"
        elif db_memo == "B":
            remarks = "CHARGE BUYER"
        elif tdebit_fee == tpost_fee and tdebit_fee == 0 and tcnt == 0:
            remarks = "NO TRANSACTION"
        elif tdebit_fee == tpost_fee and tdebit_fee == 0 and db_seller_fee == 0:
            remarks = "FOC"
        elif tdebit_fee == tpost_fee and tpost_fee > 0:
            remarks = "CHARGED"
        elif tdebit_fee > tpost_fee and tpost_fee == 0:
            remarks = "NOT CHARGED"
        elif tdebit_fee > tpost_fee:
            remarks = "AMOUNT UNDERCHARGED"
        elif tdebit_fee < tpost_fee:
            remarks = "AMOUNT OVERCHARGED"
        else:
            remarks = "UNKNOWN"
        
        row_copy["REMARKS"] = remarks
        row_copy["TDEBIT_FEE"] = tdebit_fee
        row_copy["TPOST_FEE"] = tpost_fee
        remarks_list.append(row_copy)
    
    all_acct = pl.DataFrame(remarks_list) if remarks_list else pl.DataFrame()
    
    if len(all_acct) > 0:
        all_acct = all_acct.sort([pl.col("REMARKS"), pl.col("KEYC").cast(pl.Utf8).str.reverse()])
    
    return all_acct

def generate_report1(all_acct, batch_date, output_file):
    """Generate REPORT1 - Main report"""
    
    logger.info(f"Generating REPORT1 with {len(all_acct)} records")
    
    sdate = batch_date.get("SDATE", "01/01/2020")
    bdate = batch_date.get("BDATE", "31/12/2020")
    
    try:
        with open(output_file, 'w') as f:
            headers_written = False
            
            for row in all_acct.iter_rows(named=True):
                if not headers_written:
                    # Write headers
                    f.write(f"||||P U B L I C  B A N K  B H D\n")
                    f.write(f"|||FPX TRANSACTIONS BY SELLERS FROM {sdate} UNTIL {bdate}\n\n")
                    f.write("| FLAT SERVICE FEE PER TRX | % SERVICE FEE OF TRX AMOUNT | TOTAL FEE DEBITED | TOTAL FEE POSTED | RECON BETWEEN A & B :\n")
                    f.write("| FEE PER TRX SELLER | FEE PER TRX SELLER | BUYER |  | A | B | REMARKS |\n")
                    f.write("| 1A | 1B |  | A | B | C |\n")
                    f.write("\n")
                    headers_written = True
                
                if row.get("AMOUNT") is not None and row.get("AMOUNT") != 0:
                    seller_name = str(row.get("SELLER_NAME", "")).ljust(26)
                    busreg = str(row.get("BUSREG", "")).ljust(12)
                    seller_id = str(row.get("SELLER_ID", "")).ljust(10)
                    acctno = str(row.get("ACCTNO", "")).rjust(10)
                    b2b_b2c = str(row.get("B2B_B2C_IND", "")).ljust(3)
                    source_ind = str(row.get("SOURCE_IND", "")).ljust(14)
                    channel = str(row.get("CHANNEL", "")).ljust(6)
                    tcnt = str(row.get("TCNT", 0)).rjust(7)
                    tamount = f"{row.get('TAMOUNT', 0):13.2f}"
                    db_seller_fee = f"{row.get('DB_SELLER_FEE', 0):5.2f}"
                    db_buyer_fee = f"{row.get('DB_BUYER_FEE', 0):5.2f}"
                    remarks = str(row.get("REMARKS", "")).rjust(20)
                    
                    source_ind_clean = row.get("SOURCE_IND", "").strip()
                    if source_ind_clean == "ON-US CARD":
                        percent = f"{row.get('DB_PERCENT_ON', 0):5.2f}%"
                    elif source_ind_clean == "OFF-US CARD":
                        percent = f"{row.get('DB_PERCENT_OFF', 0):5.2f}%"
                    else:
                        percent = " 0.00%"
                    
                    line = f"|{seller_name}|{busreg}|{seller_id}|{acctno}|{b2b_b2c}|{source_ind}|{channel}|{tcnt}|{tamount}|{db_seller_fee}|{db_buyer_fee}|{percent}|{remarks}|"
                    f.write(line + "\n")
        
        logger.info(f"REPORT1 generated successfully")
    except Exception as e:
        logger.error(f"Error generating REPORT1: {str(e)}")

def generate_report2(imssdbn, batch_date, output_file):
    """Generate REPORT2 - Posted transactions not in DB2"""
    
    logger.info(f"Generating REPORT2 with {len(imssdbn)} records")
    
    sdate = batch_date.get("SDATE", "01/01/2020")
    bdate = batch_date.get("BDATE", "31/12/2020")
    
    try:
        with open(output_file, 'w') as f:
            f.write(f"||||P U B L I C  B A N K  B H D\n")
            f.write(f"|||FPX TRANSACTIONS BY SELLERS FROM {sdate} UNTIL {bdate}\n")
            f.write(f"|||POSTED TRANSACTION NOT IN MA DB2\n\n")
            
            f.write("| ACCOUNT NUMBER | TRANSACTION ID | TRANSACTION DATE | DATA TYPE | TRANSACTION AMOUNT | FEE AMOUNT | BUYER BANK |\n\n")
            
            cnt = 0
            for row in imssdbn.iter_rows(named=True):
                cnt += 1
                acctno = str(row.get("ACCTNO", "")).rjust(10)
                trans_id = str(row.get("TRANS_ID", "")).ljust(16)
                process_date = str(row.get("PROCESS_DATE", ""))
                data_type = str(row.get("DATA_TYPE", ""))
                amount = f"{row.get('AMOUNT', 0):13.2f}"
                post_fee = f"{row.get('POST_FEE', 0):13.2f}"
                buyer_bank = str(row.get("BUYER_BANK_ID", "")).ljust(15)
                
                line = f"|{acctno}|{trans_id}|{process_date}|{data_type}|{amount}|{post_fee}|{buyer_bank}|"
                f.write(line + "\n")
        
        logger.info(f"REPORT2 generated successfully with {cnt} records")
    except Exception as e:
        logger.error(f"Error generating REPORT2: {str(e)}")

def generate_report3(imsntrxfee, batch_date, output_file):
    """Generate REPORT3 - TRX with no fee charge on seller"""
    
    logger.info(f"Generating REPORT3 with {len(imsntrxfee)} records")
    
    sdate = batch_date.get("SDATE", "01/01/2020")
    bdate = batch_date.get("BDATE", "31/12/2020")
    
    try:
        with open(output_file, 'w') as f:
            f.write(f"||||P U B L I C  B A N K  B H D\n")
            f.write(f"|||FPX TRANSACTIONS BY SELLERS FROM {sdate} UNTIL {bdate}\n")
            f.write(f"|||TRX FEE DO NOT CHARGE ON SELLER(TRX HISTORY)\n\n")
            
            f.write("| ACCOUNT NUMBER | TRANSACTION ID | TRANSACTION DATE | TRANSACTION AMOUNT |\n\n")
            
            cnt = 0
            for row in imsntrxfee.iter_rows(named=True):
                cnt += 1
                acctno = str(row.get("ACCTNO", "")).rjust(10)
                trans_id = str(row.get("TRANS_ID", "")).ljust(16)
                process_date = str(row.get("PROCESS_DATE", ""))
                amount = f"{row.get('AMOUNT', 0):13.2f}"
                
                line = f"|{acctno}|{trans_id}|{process_date}|{amount}|"
                f.write(line + "\n")
        
        logger.info(f"REPORT3 generated successfully with {cnt} records")
    except Exception as e:
        logger.error(f"Error generating REPORT3: {str(e)}")

if __name__ == "__main__":
    main()
