# DPFPXRES.py
# /* RESIDENT CODE */

import polars as pl
import common.fixed_width_reader as fixed_width_reader
from common.batch_date import get_batch_data
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Obtain date for file paths
date_info = get_batch_data()
file_date = date_info["file_date"]
folder_day = date_info["folder_day"]
folder_month = date_info["folder_month"]
folder_year = date_info["folder_year"]

# Define file paths - matching SAS convention
INPUTF1 = f"/host/dp/input/fpx/INPUTF1_{folder_year}{folder_month}{folder_day}.dat"
INPUTF2 = f"/host/dp/input/fpx/INPUTF2_{folder_year}{folder_month}{folder_day}.dat"
OUTFILE = f"/host/dp/output/DPFPXRES_OUTPUT_{folder_year}{folder_month}{folder_day}.dat"

# --- Select Clause ---
select_clause_inputf1 = [
    ("SERIAL", 20, 9)          # @10 SERIAL      $20.
]

select_clause_inputf2 = [
    ("SERIAL", 20, 4),         # @05 SERIAL      $20.
    ("RECORD", 1032, 0)        # @1 RECORD      $1032.
]

def main():
    """SAS DPFPXRES program converted to Python with same variable names"""
    
    try:
        logger.info("Starting DPFPXRES - RESIDENT CODE")
        
        # Step 1: Read INPUTF1 into RESIDENT
        logger.info(f"Reading RESIDENT from {INPUTF1}...")
        RESIDENT = read_RESIDENT()
        
        # Step 2: Sort RESIDENT by SERIAL
        logger.info("Sorting RESIDENT by SERIAL...")
        RESIDENT = RESIDENT.sort("SERIAL")
        
        # Step 3: Read INPUTF2 into TDFAAI
        logger.info(f"Reading TDFAAI from {INPUTF2}...")
        TDFAAI = read_TDFAAI()
        
        # Step 4: Sort TDFAAI by SERIAL
        logger.info("Sorting TDFAAI by SERIAL...")
        TDFAAI = TDFAAI.sort("SERIAL")
        
        # Step 5: Merge RESIDENT and TDFAAI to create MRG
        logger.info("Merging RESIDENT and TDFAAI to create MRG...")
        MRG = merge_RESIDENT_TDFAAI(RESIDENT, TDFAAI)
        
        # Step 6: Write output file
        logger.info(f"Writing output to {OUTFILE}...")
        write_OUTFILE(MRG)
        
        logger.info("DPFPXRES processing completed successfully.")
        
    except Exception as e:
        logger.error(f"Error in DPFPXRES processing: {str(e)}", exc_info=True)
        raise

def read_RESIDENT():
    """SAS DATA RESIDENT; INFILE INPUTF1; INPUT @10 SERIAL $20. @771 RESIDENTCD $02.; RUN;"""
    logger.info(f"Reading RESIDENT from {INPUTF1}")
    
    # Define schema using select_clause_inputf1
    schema = select_clause_inputf1
    
    # Need to also read RESIDENTCD at position 771 (0-indexed: 770)
    schema_extended = [
        ("SERIAL", 20, 9),         # @10 SERIAL      $20.
        ("RESIDENTCD", 2, 770)     # @771 RESIDENTCD $02.
    ]
    
    # Read using fixed_width_reader
    RESIDENT = fixed_width_reader.read(INPUTF1, schema_extended)
    
    logger.info(f"RESIDENT created with {len(RESIDENT)} records")
    return RESIDENT

def read_TDFAAI():
    """SAS DATA TDFAAI; INFILE INPUTF2 TRUNCOVER; INPUT @05 SERIAL $20. @1 RECORD $1032.; RUN;"""
    logger.info(f"Reading TDFAAI from {INPUTF2}")
    
    # Define schema using select_clause_inputf2
    schema = select_clause_inputf2
    
    # Read using fixed_width_reader
    TDFAAI = fixed_width_reader.read(INPUTF2, schema)
    
    logger.info(f"TDFAAI created with {len(TDFAAI)} records")
    return TDFAAI

def merge_RESIDENT_TDFAAI(RESIDENT, TDFAAI):
    """SAS DATA MRG; MERGE RESIDENT(IN=A) TDFAAI(IN=B); BY SERIAL; RUN;"""
    logger.info("Merging RESIDENT and TDFAAI to create MRG")
    
    # Perform outer merge (keep all records from both datasets, matching by SERIAL)
    MRG = RESIDENT.join(
        TDFAAI,
        on="SERIAL",
        how="outer"
    )
    
    logger.info(f"MRG created with {len(MRG)} records")
    return MRG

def write_OUTFILE(MRG):
    """SAS DATA _NULL_; FILE OUTFILE; SET MRG END=EOF; PUT @001 RECORD $1032. @1033 RESIDENTCD $2.; RUN;"""
    logger.info(f"Writing output file to {OUTFILE}")
    
    with open(OUTFILE, 'w') as f:
        # Write each record as fixed-width: RECORD (1032 chars) + RESIDENTCD (2 chars)
        for row in MRG.iter_rows(named=True):
            record = str(row.get("RECORD", "")).ljust(1032)[:1032]
            residentcd = str(row.get("RESIDENTCD", "")).ljust(2)[:2]
            
            # Combine and write
            output_line = record + residentcd
            f.write(output_line + "\n")
    
    logger.info(f"Output file created: {OUTFILE} with {len(MRG)} records")

if __name__ == "__main__":
    main()
