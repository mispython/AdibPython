# DPFPXRO1.py
# /****                        DP8587                               ****/
# /***  GENERATE FPX DAILY REPORT (ALL FPX PCS AND E-MANDATE PCS)    ***/
# /****                  CREATE HEADER ONLY                          ***/

from datetime import datetime
from common.batch_date import get_batch_data
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Obtain date for file paths
date_info = get_batch_data()
file_date = date_info["file_date"]
folder_day = date_info["folder_day"]
folder_month = date_info["folder_month"]
folder_year = date_info["folder_year"]

# Define file paths - matching SAS convention
CTRLDATE = f"/host/dp/input/fpx/CTRLDATE_{folder_year}{folder_month}{folder_day}.dat"
RPT01 = f"/host/dp/output/DPFPXRO1_REPORT_{folder_year}{folder_month}{folder_day}.txt"

def main():
    """SAS DPFPXRO1 program converted to Python with same variable names"""
    
    try:
        logger.info("Starting DPFPXRO1 - GENERATE FPX DAILY REPORT (CREATE HEADER ONLY)")
        logger.info("DP8587")
        
        # Step 1: Read control date from CTRLDATE
        logger.info(f"Reading CTRLDATE from {CTRLDATE}...")
        BDATE, SDATE = read_BATDATE()
        
        # Step 2: Generate report with header
        logger.info(f"Generating report header to {RPT01}...")
        generate_report_header(BDATE, SDATE)
        
        logger.info("DPFPXRO1 processing completed successfully.")
        
    except Exception as e:
        logger.error(f"Error in DPFPXRO1 processing: {str(e)}", exc_info=True)
        raise

def read_BATDATE():
    """SAS DATA BATDATE; INFILE CTRLDATE; INPUT @01 BATCHDTE YYMMDD8.; ... RUN;"""
    logger.info(f"Reading batch date from {CTRLDATE}")
    
    try:
        with open(CTRLDATE, 'r') as f:
            # Read first line and parse as YYMMDD8 format
            line = f.readline().strip()
            
            if len(line) >= 8:
                yy = line[0:2]
                mm = line[2:4]
                dd = line[4:6]
                
                # Convert YYMMDD to DDMMYY format
                year = "20" + yy if int(yy) < 100 else yy
                BDATE = f"{dd}/{mm}/{year}"
                SDATE = f"01/{mm}/{year}"
                
                logger.info(f"Batch Date: {BDATE}, Start Date: {SDATE}")
                return BDATE, SDATE
            else:
                logger.warning(f"CTRLDATE line too short: {line}")
                current_date = datetime.now()
                BDATE = current_date.strftime("%d/%m/%Y")
                SDATE = current_date.strftime("01/%m/%Y")
                return BDATE, SDATE
                
    except FileNotFoundError:
        logger.warning(f"CTRLDATE file not found, using current date")
        current_date = datetime.now()
        BDATE = current_date.strftime("%d/%m/%Y")
        SDATE = current_date.strftime("01/%m/%Y")
        return BDATE, SDATE

def generate_report_header(BDATE, SDATE):
    """SAS DATA REPORT; FILE RPT01; PUT ... OUTPUT REPORT; RUN;"""
    logger.info(f"Generating report header to {RPT01}")
    
    with open(RPT01, 'w') as f:
        # Write header section
        f.write("|" + " "*50 + "||||P U B L I C  B A N K  B H D\n")
        f.write("|" + " "*33 + "|||FPX TRANSACTIONS BY SELLERS FROM")
        f.write(f"{SDATE:>12} UNTIL {BDATE:>8}\n")
        
        # Write column headers - row 1
        f.write("|" + " "*10 + "|" + " "*28 + "|")
        f.write("BUSINESS" + " "*6 + "|" + " "*12 + "|" + " "*12 + "|" + " "*6 + "|")
        f.write(" "*7 + "|" + " "*7 + "|")
        f.write("TOTAL" + " "*7 + "|" + " "*6 + "|")
        f.write("TOTAL" + " "*10 + "|" + " "*12 + "|")
        f.write("FEE PER TRX" + " "*15 + "|\n")
        
        # Write column headers - row 2
        f.write("|" + " "*1 + "DATE" + " "*6 + "|")
        f.write("PBB SELLER" + " "*18 + "|")
        f.write("REG NO." + " "*6 + "|")
        f.write("SELLER ID" + " "*9 + "|")
        f.write("SELLER A/C" + " "*9 + "|")
        f.write("TYPE" + " "*2 + "|")
        f.write("SOURCE" + " "*4 + "|")
        f.write("CHANNEL" + " "*0 + "|")
        f.write("COUNT" + " "*8 + "|")
        f.write("AMOUNT" + " "*7 + "|")
        f.write("SELLER" + " "*21 + "|")
        f.write("BUYER" + " "*22 + "|\n")
    
    logger.info(f"Report header generated: {RPT01}")

if __name__ == "__main__":
    main()
