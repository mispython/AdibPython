# DPFPXRO2.py
# /* DP6027 - MERGE DATA WITH LHD FILE TO GET THE AGENCY CODE AND */
# /*          OUPUT IT TO SORT BY AGENCY CODE DP6027 */
# /*          (ESMR 2016-802) */
# /** - TO GENERATE STATISTIC REPORT ON POSTED & UNPOSTED ITEM */
# /**   FOR ALL KIND OF PAYMENT SERVICES. */

import polars as pl
import common.fixed_width_reader as fixed_width_reader
from common.batch_date import get_batch_data
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Obtain date for file paths
date_info = get_batch_data()
file_date = date_info["file_date"]
folder_day = date_info["folder_day"]
folder_month = date_info["folder_month"]
folder_year = date_info["folder_year"]

# Define file paths - matching SAS convention
INPUTF1 = f"/host/dp/input/fpx/INPUTF1_{folder_year}{folder_month}{folder_day}.dat"
OUTPUT1 = f"/host/dp/output/DPFPXRO2_OUTPUT_{folder_year}{folder_month}{folder_day}.dat"

# --- Select Clause ---
select_clause_inputf1 = [
    ("RECALL", 170, 0)         # @001 RECALL      $170.
]

def main():
    """SAS DPFPXRO2 program converted to Python with same variable names"""
    
    try:
        logger.info("Starting DPFPXRO2 - DP6027 - GENERATE STATISTIC REPORT ON POSTED & UNPOSTED ITEM")
        logger.info("ESMR 2016-802")
        
        # Step 1: Read INPUTF1 into RECTALL
        logger.info(f"Reading RECTALL from {INPUTF1}...")
        RECTALL = read_RECTALL()
        
        # Step 2: Write output file
        logger.info(f"Writing output to {OUTPUT1}...")
        write_OUTPUT1(RECTALL)
        
        logger.info("DPFPXRO2 processing completed successfully.")
        
    except Exception as e:
        logger.error(f"Error in DPFPXRO2 processing: {str(e)}", exc_info=True)
        raise

def read_RECTALL():
    """SAS DATA RECTALL; INFILE INPUTF1; INPUT @001 RECALL $170.; RUN;"""
    logger.info(f"Reading RECTALL from {INPUTF1}")
    
    # Define schema using select_clause_inputf1
    schema = select_clause_inputf1
    
    # Read using fixed_width_reader
    RECTALL = fixed_width_reader.read(INPUTF1, schema)
    
    logger.info(f"RECTALL created with {len(RECTALL)} records")
    return RECTALL

def write_OUTPUT1(RECTALL):
    """SAS DATA _NULL_; SET RECTALL END=EOF; FILE OUTPUT1; PUT @001 RECALL $170.; RUN;"""
    logger.info(f"Writing output file to {OUTPUT1}")
    
    with open(OUTPUT1, 'w') as f:
        # Write each record (170 chars fixed-width)
        for row in RECTALL.iter_rows(named=True):
            recall = str(row.get("RECALL", "")).ljust(170)[:170]
            f.write(recall + "\n")
    
    logger.info(f"Output file created: {OUTPUT1} with {len(RECTALL)} records")

if __name__ == "__main__":
    main()
