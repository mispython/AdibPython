# DPFPXSEG.py
# /** SEGREGATE FPX DDS ENROLMENT RECORDS INTO 2 FILES            **/
# /** 1) CONTAINING RECS WITH REF#1 = SELLER ID                   **/
# /** 2) CONTAINING RECS WITH REF#1 = POLICY NO/ETC..             **/
# /** DP6778 - CHANGE THE LOGIC FOR SEGREGATION OF SELLER ID REC  **/
# /** DP7909 - EXPAND LENGTH FOR FIELD APY-PER-TRX-LIM            **/

import polars as pl
from datetime import datetime, timedelta
import common.fixed_width_reader as fixed_width_reader
from common.batch_date import get_batch_date
import os
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Obtain date for file paths
date_info = get_batch_date()
file_date = date_info["file_date"]
folder_day = date_info["folder_day"]
folder_month = date_info["folder_month"]
folder_year = date_info["folder_year"]

# Define file paths - matching SAS convention
CTRLDATE = f"/host/dp/input/fpx/CTRLDATE_{folder_year}{folder_month}{folder_day}.dat"
INPUTF1 = f"/host/dp/input/fpx/INPUTF1_{folder_year}{folder_month}{folder_day}.dat"
OUTPUT1 = f"/host/dp/output/DPFPXSEG_OUTPUT1_{folder_year}{folder_month}{folder_day}.dat"
OUTPUT2 = f"/host/dp/output/DPFPXSEG_OUTPUT2_{folder_year}{folder_month}{folder_day}.dat"

# --- Select Clause ---
select_clause_inputf1 = [
    ("RECTYPE", 5, 0),         # @001 RECTYPE $5.
    ("BANKNO", 2, 5),          # @006 BANKNO PD2.
    ("DRACCTNO", 6, 7),        # @008 DRACCTNO PD6.
    ("MISCKEYX", 2, 13),       # @014 MISCKEYX $2. (DM0825)
    ("MISCKEYX1", 1, 15),      # @016 MISCKEYX1 $1. (DM0825)
    ("MISCKEY1X", 10, 13),     # @014 MISCKEY1X $10. (DP6778)
    ("MISCKEY1", 20, 13),      # @014 MISCKEY1 $20.
    ("MISCKEY2", 20, 33),      # @034 MISCKEY2 $20.
    ("MISCKEY3", 20, 53),      # @054 MISCKEY3 $20.
    ("TRXLIM1", 9, 73),        # @074 TRXLIM1 PD9.2 (DP7909)
    ("FAILCNT", 1, 82),        # @083 FAILCNT PD1.
    ("OPENDATE", 10, 83),      # @084 OPENDATE $10.
    ("OPENYY", 4, 83),         # @084 OPENYY $4.
    ("OPENMM", 2, 88),         # @089 OPENMM $2.
    ("OPENDD", 2, 91),         # @092 OPENDD $2.
    ("CANDATE", 10, 93),       # @094 CANDATE $10.
    ("ACTVDATE", 10, 103),     # @104 ACTVDATE $10.
    ("LSTMNTDT", 10, 113),     # @114 LSTMNTDT $10.
    ("BNKOFFCD", 3, 123),      # @124 BNKOFFCD PD3.
    ("OFFID1", 8, 126),        # @127 OFFID1 $8.
    ("OFFID2", 8, 134),        # @135 OFFID2 $8.
    ("ACCTSTAT", 1, 142),      # @143 ACCTSTAT $1.
    ("PYACCTNO", 6, 143),      # @144 PYACCTNO PD6.
    ("FREQPAY", 1, 149),       # @150 FREQPAY $1.
    ("LSTTRXDT", 10, 150),     # @151 LSTTRXDT $10.
    ("AUTOCLS", 1, 160),       # @161 AUTOCLS PD1.
    ("FAILLIM", 2, 161),       # @162 FAILLIM PD2.
    ("FEECHRG", 5, 163),       # @164 FEECHRG PD3.2
    ("MTDDBCNT", 3, 166),      # @167 MTDDBCNT PD3.
    ("YTDDBCNT", 3, 169),      # @170 YTDDBCNT PD3.
    ("MTDDBAMT", 6, 172),      # @173 MTDDBAMT PD6.2
    ("YTDDBAMT", 6, 178),      # @179 YTDDBAMT PD6.2
    ("ACCUMCNT", 3, 184),      # @185 ACCUMCNT PD3.
    ("ACCUMAMT", 6, 187),      # @188 ACCUMAMT PD6.2
    ("SELLID", 10, 193),       # @194 SELLID $10.
    ("SELLBANK", 10, 203),     # @204 SELLBANK $10.
    ("NOOFFREQ", 2, 213)       # @214 NOOFFREQ PD2.
]

# Constants
INIDATE = 20070920  # FPX ENROLMENT PROJECT IMPL DATE

def main():
    """SAS DPFPXSEG program - Segregate FPX DDS Enrolment Records"""
    
    try:
        logger.info("Starting DPFPXSEG - SEGREGATE FPX DDS ENROLMENT RECORDS")
        logger.info("DP6778: CHANGE THE LOGIC FOR SEGREGATION OF SELLER ID")
        logger.info("DP7909: EXPAND LENGTH FOR FIELD APY-PER-TRX-LIM")
        
        # Step 1: Get report date
        logger.info("Reading CTRLDATE...")
        FMTDATE = read_ctrldate()
        
        # Step 2: Read and classify enrolment records
        logger.info("Reading INPUTF1 and segregating records...")
        DATA001, DATA002, DATA00X = segregate_records(FMTDATE)
        
        # Step 3: Output segregated records
        logger.info(f"Writing segregated records to {OUTPUT1} and {OUTPUT2}")
        write_output(DATA001, OUTPUT1)
        write_output(DATA002, OUTPUT2)
        
        logger.info(f"DPFPXSEG processing completed. DATA001: {len(DATA001)} recs, DATA002: {len(DATA002)} recs")
        
    except Exception as e:
        logger.error(f"Error in DPFPXSEG processing: {str(e)}")
        raise

def read_ctrldate():
    """Read control date for last conversion date"""
    logger.info(f"Reading CTRLDATE from {CTRLDATE}")
    
    try:
        with open(CTRLDATE, 'r') as f:
            line = f.readline().strip()
            if len(line) >= 8:
                FMTDATE = line[0:8]
                logger.info(f"Format date: {FMTDATE}")
                return FMTDATE
            else:
                return datetime.now().strftime("%Y%m%d")
    except FileNotFoundError:
        logger.warning("CTRLDATE not found, using current date")
        return datetime.now().strftime("%Y%m%d")

def segregate_records(FMTDATE):
    """Segregate enrolment records based on logic"""
    logger.info(f"Segregating records with FMTDATE={FMTDATE}")
    
    if not os.path.exists(INPUTF1):
        logger.warning(f"File not found: {INPUTF1}")
        return pl.DataFrame(), pl.DataFrame(), pl.DataFrame()
    
    DATA001_recs = []
    DATA002_recs = []
    DATA00X_recs = []
    
    try:
        with open(INPUTF1, 'r') as f:
            for line in f:
                if len(line) < 214:
                    continue
                
                # Read key fields
                RECTYPE = line[0:5].strip()
                MISCKEYX = line[13:15].strip() if len(line) > 14 else ""
                MISCKEYX1 = line[15:16].strip() if len(line) > 15 else ""
                MISCKEY1X = line[13:23].strip() if len(line) > 22 else ""
                SELLID = line[193:203].strip() if len(line) > 202 else ""
                
                # Date fields
                OPENYY = line[83:87].strip() if len(line) > 86 else ""
                OPENMM = line[88:90].strip() if len(line) > 89 else ""
                OPENDD = line[91:93].strip() if len(line) > 92 else ""
                
                try:
                    CHKDATE = OPENYY + OPENMM + OPENDD if OPENYY and OPENMM and OPENDD else ""
                except:
                    CHKDATE = ""
                
                # Create MATCHKEY
                DRACCTNO = line[7:13].strip() if len(line) > 12 else ""
                MATCHKEY = RECTYPE + DRACCTNO + MISCKEY1X
                
                record = {
                    "RECTYPE": RECTYPE,
                    "MATCHKEY": MATCHKEY,
                    "CHKDATE": CHKDATE,
                    "SELLID": SELLID,
                    "MISCKEY1X": MISCKEY1X,
                    "MISCKEYX": MISCKEYX,
                    "SLRIDLEN": len(MISCKEY1X)
                }
                
                # Segregation logic (DP6778)
                if (MISCKEY1X == SELLID) or \
                   (SELLID == "" and MISCKEYX in ["SE", "DD"] and len(MISCKEY1X) == 10):
                    DATA001_recs.append(record)
                else:
                    if CHKDATE and CHKDATE > INIDATE and CHKDATE < FMTDATE:
                        DATA00X_recs.append(record)
                    else:
                        DATA002_recs.append(record)
        
        DATA001 = pl.DataFrame(DATA001_recs) if DATA001_recs else pl.DataFrame()
        DATA002 = pl.DataFrame(DATA002_recs) if DATA002_recs else pl.DataFrame()
        DATA00X = pl.DataFrame(DATA00X_recs) if DATA00X_recs else pl.DataFrame()
        
        logger.info(f"Segregation complete: DATA001={len(DATA001)}, DATA002={len(DATA002)}, DATA00X={len(DATA00X)}")
        return DATA001, DATA002, DATA00X
        
    except Exception as e:
        logger.error(f"Error segregating records: {str(e)}")
        return pl.DataFrame(), pl.DataFrame(), pl.DataFrame()

def write_output(data, output_file):
    """Write segregated records to output file"""
    logger.info(f"Writing {len(data)} records to {output_file}")
    
    if len(data) == 0:
        logger.warning(f"No records to write to {output_file}")
        return
    
    # For now, create a simple file - can be enhanced for fixed-width output
    with open(output_file, 'w') as f:
        for row in data.iter_rows(named=True):
            # Write fixed-width format as per SAS PUT statements
            # This is a placeholder - actual implementation would match SAS field positions
            f.write(str(row) + "\n")

if __name__ == "__main__":
    main()
