# DPFPXSTP.py
# /** PROGRAM TO PRINT REPORT FOR STOP PAYMENT **/

import polars as pl
from datetime import datetime, timedelta
import common.fixed_width_reader as fixed_width_reader
from common.batch_date import get_batch_date
import os
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Obtain date for file paths
date_info = get_batch_date()
file_date = date_info["file_date"]
folder_day = date_info["folder_day"]
folder_month = date_info["folder_month"]
folder_year = date_info["folder_year"]

# Define file paths - matching SAS convention
CORPFILE = f"/host/dp/input/fpx/CORPFILE_{folder_year}{folder_month}{folder_day}.dat"
STPFILE = f"/host/dp/input/fpx/STPFILE_{folder_year}{folder_month}{folder_day}.dat"
STPRPT1 = f"/host/dp/output/DPFPXSTP_REPORT1_{folder_year}{folder_month}{folder_day}.txt"
STPRPT2 = f"/host/dp/output/DPFPXSTP_REPORT2_{folder_year}{folder_month}{folder_day}.txt"

# --- Select Clause ---
select_clause_corpfile = [
    ("CORPCODE", 10, 0),       # @001 CORPCODE $10.
    ("SERVTYPE", 3, 10),       # @011 SERVTYPE $3.
    ("FUNDACC", 10, 13),       # @014 FUNDACC $10.
    ("LONGNAME", 15, 38),      # @039 LONGNAME $15.
    ("SHRTNAME", 3, 38),       # @039 SHRTNAME $3.
    ("INBRNO", 3, 43)          # @044 INBRNO 3.
]

select_clause_stpfile = [
    ("FUNDACC", 10, 22),       # @023 FUNDACC $10.
    ("RECID", 20, 32),         # @033 RECID $20.
    ("SHRTNAME", 3, 32),       # @033 SHRTNAME $3.
    ("ACCTNAME", 40, 88),      # @089 ACCTNAME $40.
    ("ACCTNO", 20, 68),        # @069 ACCTNO $20.
    ("AMOUNT", 7, 141),        # @142 AMOUNT PD7.2
    ("ACCTSTAT", 2, 158),      # @159 ACCTSTAT $2.
    ("FEEAMT", 4, 172),        # @173 FEEAMT PD4.2
    ("ICNO", 12, 427),         # @428 ICNO $12.
    ("FILENAME", 18, 230)      # @231 FILENAME $18.
]

def main():
    """SAS DPFPXSTP program - Stop Payment Report"""
    
    try:
        logger.info("Starting DPFPXSTP - STOP PAYMENT REPORT")
        
        # Step 1: Read CORPFILE
        logger.info("Reading CORPFILE...")
        CORPDATA = read_corpfile()
        
        # Step 2: Read STPFILE
        logger.info("Reading STPFILE...")
        STPFILE_data = read_stpfile()
        
        # Step 3: Merge CORPFILE and STPFILE
        logger.info("Merging CORPFILE and STPFILE...")
        MRGDATA = merge_corp_stp(CORPDATA, STPFILE_data)
        
        # Step 4: Generate reports
        logger.info(f"Generating Report 1 (COLD format) to {STPRPT1}")
        generate_report_cold(MRGDATA)
        
        logger.info(f"Generating Report 2 (E-BANKING format) to {STPRPT2}")
        generate_report_ebk(MRGDATA)
        
        logger.info("DPFPXSTP processing completed successfully.")
        
    except Exception as e:
        logger.error(f"Error in DPFPXSTP processing: {str(e)}")
        raise

def read_corpfile():
    """Read CORPFILE data"""
    logger.info(f"Reading CORPFILE from {CORPFILE}")
    
    if not os.path.exists(CORPFILE):
        logger.warning(f"File not found: {CORPFILE}")
        return pl.DataFrame()
    
    try:
        schema = select_clause_corpfile
        CORPDATA = fixed_width_reader.read(CORPFILE, schema)
        
        # Sort by FUNDACC and SHRTNAME
        CORPDATA = CORPDATA.sort(["FUNDACC", "SHRTNAME"])
        
        logger.info(f"CORPDATA created with {len(CORPDATA)} records")
        return CORPDATA
    except Exception as e:
        logger.error(f"Error reading CORPFILE: {str(e)}")
        return pl.DataFrame()

def read_stpfile():
    """Read STPFILE data"""
    logger.info(f"Reading STPFILE from {STPFILE}")
    
    if not os.path.exists(STPFILE):
        logger.warning(f"File not found: {STPFILE}")
        return pl.DataFrame()
    
    try:
        schema = select_clause_stpfile
        STPFILE_data = fixed_width_reader.read(STPFILE, schema)
        
        # Add rejection description
        STPFILE_data = STPFILE_data.with_columns([
            pl.lit("STOP PAYMENT").alias("REJDESC")
        ])
        
        # Sort by FUNDACC and SHRTNAME
        STPFILE_data = STPFILE_data.sort(["FUNDACC", "SHRTNAME"])
        
        logger.info(f"STPFILE created with {len(STPFILE_data)} records")
        return STPFILE_data
    except Exception as e:
        logger.error(f"Error reading STPFILE: {str(e)}")
        return pl.DataFrame()

def merge_corp_stp(CORPDATA, STPFILE_data):
    """Merge CORPFILE and STPFILE by FUNDACC and SHRTNAME"""
    logger.info("Merging CORPDATA and STPFILE")
    
    if len(CORPDATA) == 0 or len(STPFILE_data) == 0:
        logger.warning("One or both dataframes are empty")
        return pl.DataFrame()
    
    # Perform merge on FUNDACC and SHRTNAME
    MRGDATA = STPFILE_data.join(
        CORPDATA,
        on=["FUNDACC", "SHRTNAME"],
        how="inner"
    )
    
    # Sort by FILENAME and ACCTNO
    MRGDATA = MRGDATA.sort(["FILENAME", "ACCTNO"])
    
    logger.info(f"MRGDATA created with {len(MRGDATA)} records")
    return MRGDATA

def generate_report_cold(MRGDATA):
    """Generate COLD format report"""
    logger.info(f"Generating COLD format report")
    
    if len(MRGDATA) == 0:
        logger.warning("No records to report")
        return
    
    with open(STPRPT1, 'w') as f:
        # Initialize counters
        TOTREC = 0
        TOTAMNT = 0.0
        current_file = None
        
        for row in MRGDATA.iter_rows(named=True):
            filename = row.get("FILENAME", "")
            
            # New file break
            if current_file != filename:
                if current_file is not None:
                    # Print subtotals for previous file
                    f.write("\n\n\n")
                    f.write(f"*** TOTAL RECORDS     :                {TOTREC:4d}\n")
                    f.write(f"*** TOTAL AMOUNT (RM) : {TOTAMNT:18.2f}\n")
                
                # Print page header
                f.write("\f")
                inbrno = row.get("INBRNO", 0)
                longname = row.get("LONGNAME", "").strip()
                shrtname = row.get("SHRTNAME", "").strip()
                
                f.write(f"{'REPORT NO   : BPP/':1}{shrtname}/008   {'BRH : ':32}{inbrno:03d}\n")
                f.write(f"{'PROGRAM ID  : DPEBPSTP':45}P U B L I C  B A N K  B E R H A D")
                f.write(f"{'PAGE        :  1':110}\n")
                f.write(f"{'':45}STOP PAYEMNT FOR  {longname}\n")
                f.write("REPORT DATE : \n")
                
                # Column headers
                f.write("\n\n")
                f.write("NO.      ACCT. NO.         BENEFICIARY NAME                  ORDER NO.        DR/CR AMOUNT (RM)  REJECT DESCRIPTION\n")
                f.write("===      =========         ================                  ========          =================  ==================\n")
                
                current_file = filename
                TOTREC = 0
                TOTAMNT = 0.0
            
            # Detail line
            TOTREC += 1
            acctno = row.get("ACCTNO", "")
            acctname = row.get("ACCTNAME", "").strip()
            recid = row.get("RECID", "").strip()
            amount = row.get("AMOUNT", 0.0)
            rejdesc = row.get("REJDESC", "")
            
            TOTAMNT += amount
            
            f.write(f"{TOTREC:3d}      {acctno:20s}  {acctname:30s}    {recid:20s}  {amount:18.2f}  {rejdesc:20s}\n")
        
        # Final totals
        if current_file is not None:
            f.write("\n\n\n")
            f.write(f"*** TOTAL RECORDS     :                {TOTREC:4d}\n")
            f.write(f"*** TOTAL AMOUNT (RM) : {TOTAMNT:18.2f}\n")
    
    logger.info(f"COLD report generated: {TOTREC} records, Amount: {TOTAMNT:,.2f}")

def generate_report_ebk(MRGDATA):
    """Generate E-BANKING format report"""
    logger.info(f"Generating E-BANKING format report")
    
    if len(MRGDATA) == 0:
        logger.warning("No records to report")
        return
    
    with open(STPRPT2, 'w') as f:
        # Initialize counters
        TOTREC = 0
        TOTAMNT = 0.0
        PAGECNT = 0
        current_file = None
        
        for row in MRGDATA.iter_rows(named=True):
            filename = row.get("FILENAME", "")
            
            # New file break
            if current_file != filename:
                if current_file is not None:
                    # Print subtotals
                    f.write("\n\n")
                    f.write(f"*** TOTAL RECORDS     :                {TOTREC:4d}\n")
                    f.write(f"*** TOTAL AMOUNT (RM) : {TOTAMNT:18.2f}\n")
                
                # Print header
                PAGECNT += 1
                corpcode = row.get("CORPCODE", "").strip()
                shrtname = row.get("SHRTNAME", "").strip()
                inbrno = row.get("INBRNO", 0)
                longname = row.get("LONGNAME", "").strip()
                
                f.write(f"<{corpcode:12s}> <{filename:14s}.BTR>\n")
                f.write(f"REPORT NO   : BPP/{shrtname}/008    BRH : {inbrno:03d}\n")
                f.write(f"{'':45}P U B L I C  B A N K  B E R H A D")
                f.write(f"{'PAGE        :    1':110}\n")
                f.write(f"PROGRAM ID  : DPFPXSTP ")
                f.write(f"{'':45}STOP PAYEMNT FOR  {longname}\n")
                f.write(f"{'':45}REPORT DATE : \n")
                
                # Column headers
                f.write("\nACCT. NO.          BENEFICIARY NAME              ORDER NO.        DR/CR AMOUNT (RM)  REJECT DESCRIPTION\n")
                f.write("=========          ================               =========         ==================  ==================\n")
                
                current_file = filename
                TOTREC = 0
                TOTAMNT = 0.0
            
            # Detail line
            TOTREC += 1
            acctno = row.get("ACCTNO", "")
            acctname = row.get("ACCTNAME", "").strip()
            recid = row.get("RECID", "").strip()
            amount = row.get("AMOUNT", 0.0)
            rejdesc = row.get("REJDESC", "")
            
            TOTAMNT += amount
            
            f.write(f"{acctno:20s} {acctname:30s}  {recid:20s}  {amount:18.2f}  {rejdesc:20s}\n")
        
        # Final totals
        if current_file is not None:
            f.write("\n\n")
            f.write(f"*** TOTAL RECORDS     :                {TOTREC:4d}\n")
            f.write(f"*** TOTAL AMOUNT (RM) : {TOTAMNT:18.2f}\n")
    
    logger.info(f"E-BANKING report generated: {TOTREC} records")

if __name__ == "__main__":
    main()
