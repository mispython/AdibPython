# DPFPXUCV.py
# /****   DP9530 | SMR2024-3657                                   ****/
# /****   VERIFY UCM RETURN FILE                                  ****/

import polars as pl
from datetime import datetime, timedelta
import common.fixed_width_reader as fixed_width_reader
from common.batch_date import get_batch_date
import os
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Obtain date for file paths
date_info = get_batch_date()
file_date = date_info["file_date"]
folder_day = date_info["folder_day"]
folder_month = date_info["folder_month"]
folder_year = date_info["folder_year"]

# Define file paths - matching SAS convention
INPUTF1 = f"/host/dp/input/ucm/INPUTF1_{folder_year}{folder_month}{folder_day}.dat"
OUTFILE = f"/host/dp/output/DPFPXUCV_VERIFY_{folder_year}{folder_month}{folder_day}.txt"

# --- Select Clause ---
select_clause_ucm = [
    ("DATAUN", 1, 0)   # @001 DATAUN $1.
]

def main():
    """SAS DPFPXUCV program - UCM Return File Verification (DP9530/SMR2024-3657)"""
    
    try:
        logger.info("Starting DPFPXUCV - UCM RETURN FILE VERIFICATION")
        
        # Step 1: Read and classify UCM return file
        logger.info(f"Reading UCM file from {INPUTF1}")
        UCMRT = read_ucm_file()
        
        # Step 2: Verify file structure
        logger.info("Verifying UCM file structure")
        verify_ucm_file(UCMRT)
        
        logger.info("DPFPXUCV processing completed successfully.")
        
    except Exception as e:
        logger.error(f"Error in DPFPXUCV processing: {str(e)}")
        raise

def read_ucm_file():
    """Read UCM return file and classify record types"""
    logger.info(f"Reading INPUTF1 from {INPUTF1}")
    
    if not os.path.exists(INPUTF1):
        logger.warning(f"File not found: {INPUTF1}")
        return pl.DataFrame({
            "DATAUN": [],
            "DATATYPE": [],
            "DATAUA": []
        })
    
    records = []
    try:
        with open(INPUTF1, 'r') as f:
            for line in f:
                if len(line) >= 1:
                    DATAUN = line[0]
                    
                    # Classify based on DATAUN value
                    if DATAUN == '3':
                        DATAUA = '0'
                    elif DATAUN == '0':
                        DATAUA = '1'
                    elif DATAUN == '9':
                        DATAUA = '2'
                    else:
                        DATAUA = '9'
                    
                    DATATYPE = DATAUA + DATAUN
                    
                    records.append({
                        "DATAUN": DATAUN,
                        "DATAUA": DATAUA,
                        "DATATYPE": DATATYPE
                    })
        
        UCMRT = pl.DataFrame(records)
        logger.info(f"UCMRT created with {len(UCMRT)} records")
        return UCMRT
        
    except Exception as e:
        logger.error(f"Error reading UCM file: {str(e)}")
        return pl.DataFrame({
            "DATAUN": [],
            "DATATYPE": [],
            "DATAUA": []
        })

def verify_ucm_file(UCMRT):
    """Verify UCM file structure for header, detail, and trailer records"""
    logger.info("Verifying UCM file structure")
    
    with open(OUTFILE, 'w') as f:
        # Check if file is empty
        if len(UCMRT) == 0:
            f.write("*" * 42 + "\n")
            f.write("        UCM RETURN FILE IS EMPTY!!!\n")
            f.write("-" * 42 + "\n")
            f.write("   PLEASE CONTACT DEPOSIT/UCM TEAM\n")
            f.write("           FOR ASSISTANCE!!!\n")
            f.write("*" * 42 + "\n")
            logger.warning("UCM file is empty")
            return
        
        # Count record types
        HDR = len(UCMRT.filter(pl.col("DATATYPE") == "03"))
        DTL = len(UCMRT.filter(pl.col("DATATYPE") == "10"))
        TRL = len(UCMRT.filter(pl.col("DATATYPE") == "29"))
        
        # Verify header exists
        if HDR != 1:
            f.write("*" * 42 + "\n")
            f.write("        UCM RETURN FILE DOES NOT HAVE\n")
            f.write("              HEADER RECORD!!\n")
            f.write("-" * 42 + "\n")
            f.write("   PLEASE CONTACT DEPOSIT/UCM TEAM\n")
            f.write("           FOR ASSISTANCE!!!\n")
            f.write("*" * 42 + "\n")
            logger.error("UCM file missing HEADER record")
            return
        
        # Verify trailer exists
        if TRL != 1:
            f.write("*" * 42 + "\n")
            f.write("        UCM RETURN FILE DOES NOT HAVE\n")
            f.write("             TRAILER RECORD!!\n")
            f.write("-" * 42 + "\n")
            f.write("   PLEASE CONTACT DEPOSIT/UCM TEAM\n")
            f.write("           FOR ASSISTANCE!!!\n")
            f.write("*" * 42 + "\n")
            logger.error("UCM file missing TRAILER record")
            return
        
        # File is complete - all checks passed
        if HDR == 1 and DTL >= 1 and TRL == 1:
            f.write("*" * 42 + "\n")
            f.write("     UCM RETURN FILE IS IN ORDER\n")
            f.write("*" * 42 + "\n")
            logger.info(f"UCM file verification passed: HDR={HDR}, DTL={DTL}, TRL={TRL}")

if __name__ == "__main__":
    main()
