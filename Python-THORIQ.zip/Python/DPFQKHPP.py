# DPFQKHPP.py
# /* PROGRAM: DPFQKHPP - FPX DAILY PAYMENT FILE (OPM) FOR QUICKASH  */
# /* PURPOSE: FPX DAILY PAYMENT FILE (OPM) FOR QUICKASH MALAYSIA    */
# /*          SDN BHD (3999514522)                                  */

import polars as pl
from datetime import datetime, timedelta
import common.fixed_width_reader as fixed_width_reader
from common.batch_date import get_batch_date
import os
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Obtain date for file paths
date_info = get_batch_date()
file_date = date_info["file_date"]
folder_day = date_info["folder_day"]
folder_month = date_info["folder_month"]
folder_year = date_info["folder_year"]

# Define file paths
INPUTF1 = f"/host/dp/input/quickash/INPUTF1_{folder_year}{folder_month}{folder_day}.dat"
CONTROL1 = f"/host/dp/input/quickash/CONTROL1_{folder_year}{folder_month}{folder_day}.dat"
CONTROL2 = f"/host/dp/input/quickash/CONTROL2_{folder_year}{folder_month}{folder_day}.dat"
OUTPUT1 = f"/host/dp/output/DPFQKHPP_OUTPUT_{folder_year}{folder_month}{folder_day}.dat"

# --- Select Clause ---
select_clause_aaa = [
    ("PROCDT", 6, 0),          # @001 PROCDT $6.
    ("FTRANSID", 16, 6),       # @007 FTRANSID $16.
    ("FSELORDN", 40, 22),      # @023 FSELORDN $40.
    ("TRANAMT", 13, 62),       # @063 TRANAMT 13.
    ("TRXNFEE", 13, 75),       # @076 TRXNFEE 13.
    ("NETTAMT", 13, 88),       # @089 NETTAMT 13.
    ("RECNO", 6, 101),         # @102 RECNO 6.
    ("TRANCDE", 3, 107),       # @108 TRANCDE $3.
    ("FSELERID", 10, 110),     # @111 FSELERID $10.
    ("FSELACNO", 20, 120),     # @121 FSELACNO $20.
    ("FBUYBKID", 15, 140),     # @141 FBUYBKID $15.
    ("FSELERDE", 30, 155),     # @156 FSELERDE $30.
    ("FBUYACNO", 20, 185)      # @186 FBUYACNO $20.
]

# Production seller ID
PROD_SELLER_ID = "SE00027963"

def main():
    """SAS DPFQKHPP program - FPX Daily Payment File for QuickCash"""
    
    try:
        logger.info("Starting DPFQKHPP - FPX DAILY PAYMENT FILE FOR QUICKASH")
        
        # Step 1: Read and filter transaction data
        logger.info("Reading transaction file...")
        AAA = read_inputf1()
        
        if len(AAA) == 0:
            logger.warning("No transactions found, generating empty file")
            write_empty_output()
            return
        
        # Step 2: Read control data
        logger.info("Reading control files...")
        RACTNO, RPTDAY, RPTDAYDD, RPTDAYMM, RPTDCCYY = read_control_files()
        
        # Step 3: Generate output
        logger.info(f"Generating output to {OUTPUT1}")
        generate_output(AAA, RACTNO, RPTDAY, RPTDAYDD, RPTDAYMM, RPTDCCYY)
        
        logger.info("DPFQKHPP processing completed successfully.")
        
    except Exception as e:
        logger.error(f"Error in DPFQKHPP processing: {str(e)}")
        raise

def read_inputf1():
    """Read and filter transaction data for QuickCash seller"""
    logger.info(f"Reading INPUTF1 from {INPUTF1}")
    
    if not os.path.exists(INPUTF1):
        logger.warning(f"File not found: {INPUTF1}")
        return pl.DataFrame()
    
    try:
        schema = select_clause_aaa
        AAA = fixed_width_reader.read(INPUTF1, schema)
        
        # Filter for production seller ID
        AAA = AAA.filter(pl.col("FSELERID") == PROD_SELLER_ID)
        
        # Sort by FTRANSID
        AAA = AAA.sort("FTRANSID")
        
        logger.info(f"AAA created with {len(AAA)} records")
        return AAA
    except Exception as e:
        logger.error(f"Error reading INPUTF1: {str(e)}")
        return pl.DataFrame()

def read_control_files():
    """Read control files for account and date information"""
    logger.info("Reading CONTROL1 and CONTROL2")
    
    RACTNO = ""
    RPTDAY = datetime.now().strftime("%Y%m%d")
    RPTDAYDD = datetime.now().strftime("%d")
    RPTDAYMM = datetime.now().strftime("%m")
    RPTDCCYY = datetime.now().strftime("%Y")
    
    try:
        # Read CONTROL1 for account number
        if os.path.exists(CONTROL1):
            with open(CONTROL1, 'r') as f:
                line = f.readline()
                if len(line) >= 10:
                    RACTNO = line[0:10].strip()
    except Exception as e:
        logger.warning(f"Error reading CONTROL1: {str(e)}")
    
    try:
        # Read CONTROL2 for processing date
        if os.path.exists(CONTROL2):
            with open(CONTROL2, 'r') as f:
                line = f.readline()
                if len(line) >= 8:
                    RPTDAY = line[0:8].strip()
                    RPTDCCYY = RPTDAY[0:4]
                    RPTDAYMM = RPTDAY[4:6]
                    RPTDAYDD = RPTDAY[6:8]
    except Exception as e:
        logger.warning(f"Error reading CONTROL2: {str(e)}")
    
    return RACTNO, RPTDAY, RPTDAYDD, RPTDAYMM, RPTDCCYY

def write_empty_output():
    """Write empty file with header and trailer"""
    logger.info(f"Writing empty file to {OUTPUT1}")
    
    with open(OUTPUT1, 'w') as f:
        # Header
        f.write("0PBBFPX20250114" + " " * 104 + "\n")
        # Trailer
        f.write("0PBBFPX202501148*0" + "0" * 15 + "0" * 15 + "0" * 15 + "0" * 7 + "0" * 15 + " " * 24 + "\n")

def generate_output(AAA, RACTNO, RPTDAY, RPTDAYDD, RPTDAYMM, RPTDCCYY):
    """Generate output file with transaction data"""
    logger.info(f"Generating output with {len(AAA)} records")
    
    if len(AAA) == 0:
        write_empty_output()
        return
    
    with open(OUTPUT1, 'w') as f:
        # Initialize counters
        SUBCNT = 0
        SUBTOT = 0.0
        SUBFEE = 0.0
        GTOTCNT = 0
        GTOTAMT = 0.0
        
        # Header
        header = f"0PBBFPX{RPTDCCYY}{RPTDAYMM}{RPTDAYDD}" + " " * 104
        f.write(header + "\n")
        
        # Detail records
        for row in AAA.iter_rows(named=True):
            SUBCNT += 1
            GTOTCNT += 1
            
            FTRANSID = str(row.get("FTRANSID", "")).strip().ljust(16)
            FSELORDN = str(row.get("FSELORDN", "")).strip().ljust(40)
            FBUYBKID = str(row.get("FBUYBKID", "")).strip().ljust(15)
            STAMT = int(row.get("TRANAMT", 0))
            TRXNFEE = int(row.get("TRXNFEE", 0))
            NETAMT = STAMT - TRXNFEE
            RECNO = str(row.get("RECNO", "")).strip()
            
            if RECNO == "0":
                PRECNO = "      "
            else:
                PRECNO = str(int(RECNO)).zfill(6)
            
            SUBTOT += STAMT
            SUBFEE += TRXNFEE
            GTOTAMT += STAMT
            
            # Detail line: 1FTRANSID(16)FSELORDN(40)FBUYBKID(15)STAMT(13)TRXNFEE(13)NETAMT(13)PRECNO(6)
            detail = f"1{FTRANSID}{FSELORDN}{FBUYBKID}{str(STAMT).zfill(13)}{str(TRXNFEE).zfill(13)}{str(NETAMT).zfill(13)}{PRECNO}"
            f.write(detail + "\n")
        
        # Trailer
        SUBNET = SUBTOT - SUBFEE
        trailer = f"9PBBFPX{RPTDCCYY}{RPTDAYMM}{RPTDAYDD}{str(SUBCNT).zfill(8)}{str(SUBTOT).zfill(16)}{str(SUBFEE).zfill(16)}{str(SUBNET).zfill(16)}{str(GTOTCNT).zfill(8)}{str(GTOTAMT).zfill(16)}" + " " * 24
        f.write(trailer + "\n")
    
    logger.info(f"Output generated: {SUBCNT} detail records, Total amount: {GTOTAMT}")

if __name__ == "__main__":
    main()
