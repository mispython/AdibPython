# DPFQKHR1.py
# /* PROGRAM: DPFQKHR1 - FPX DAILY TRANSACTION FILE (ODR) FOR QUICKASH */
# /* PURPOSE: FPX DAILY TRANSACTION REPORT FOR QUICKASH MALAYSIA SDN BHD */
# /* DP5770: AMENDED PROGRAM TO INCLUDE TRAN FEE/GST FEE AND NET AMOUNT */
# /* DP7304 AAB2: CHANGE HARDCODE GST TO READ FROM PARAMETER FILE */

import polars as pl
from datetime import datetime, timedelta
import common.fixed_width_reader as fixed_width_reader
from common.batch_date import get_batch_date
import os
import logging
import math

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Obtain date for file paths
date_info = get_batch_date()
file_date = date_info["file_date"]
folder_day = date_info["folder_day"]
folder_month = date_info["folder_month"]
folder_year = date_info["folder_year"]

# Define file paths
INPUTF1 = f"/host/dp/input/quickash/INPUTF1_{folder_year}{folder_month}{folder_day}.dat"
GSTRATE_FILE = f"/host/dp/input/quickash/GSTRATE_{folder_year}{folder_month}{folder_day}.dat"
CONTROL1 = f"/host/dp/input/quickash/CONTROL1_{folder_year}{folder_month}{folder_day}.dat"
CONTROL2 = f"/host/dp/input/quickash/CONTROL2_{folder_year}{folder_month}{folder_day}.dat"
CONTRP = f"/host/dp/input/quickash/CONTRP_{folder_year}{folder_month}{folder_day}.dat"
BANKBRCH = f"/host/dp/input/quickash/BANKBRCH_{folder_year}{folder_month}{folder_day}.dat"
OUTPUT_REPORT = f"/host/dp/output/DPFQKHR1_REPORT_{folder_year}{folder_month}{folder_day}.txt"

# --- Select Clause ---
select_clause_aaa = [
    ("PROCDT", 6, 0),
    ("FTRANSID", 16, 6),
    ("FSELORDN", 40, 22),
    ("TRANAMT", 13, 62),
    ("TRXNFEE", 13, 75),
    ("NETTAMT", 13, 88),
    ("RECNO", 6, 101),
    ("TRANCDE", 3, 107),
    ("FSELERID", 10, 110),
    ("FSELACNO", 20, 120),
    ("FBUYBKID", 15, 140),
    ("FSELERDE", 30, 155),
    ("FBUYACNO", 20, 185)
]

# Constants
PROD_SELLER_ID = "SE00027963"

def main():
    """SAS DPFQKHR1 program - FPX Daily Transaction Report for QuickCash"""
    
    try:
        logger.info("Starting DPFQKHR1 - FPX DAILY TRANSACTION REPORT FOR QUICKASH")
        logger.info("DP5770: Include transaction fee and GST fee detail")
        logger.info("DP7304: Read GST rate from parameter file")
        
        # Step 1: Read GST rate
        GSTRATE = read_gst_rate()
        logger.info(f"GST Rate: {GSTRATE}")
        
        # Step 2: Read transaction data
        AAA = read_inputf1()
        
        # Step 3: Read control data
        RACTNO, RPTDAY, RPTDAYDD, RPTDAYMM, RPTDCCYY = read_control_files()
        CRPCDE, BRHCDE, PYTCD, RPTNM, REF01, REF02, SUBIN = read_report_control()
        RPTBNM = read_bank_branch(BRHCDE)
        
        # Step 4: Generate report
        logger.info(f"Generating transaction report to {OUTPUT_REPORT}")
        generate_report(AAA, GSTRATE, RACTNO, RPTDAY, RPTDAYDD, RPTDAYMM, RPTDCCYY,
                       CRPCDE, BRHCDE, RPTNM, RPTBNM)
        
        logger.info("DPFQKHR1 processing completed successfully.")
        
    except Exception as e:
        logger.error(f"Error in DPFQKHR1 processing: {str(e)}")
        raise

def read_gst_rate():
    """Read GST rate from parameter file (DP7304)"""
    logger.info("Reading GST rate")
    
    GSTRATE = 0.00
    try:
        if os.path.exists(GSTRATE_FILE):
            with open(GSTRATE_FILE, 'r') as f:
                line = f.readline()
                if len(line) >= 1:
                    try:
                        GSTRATE = float(line.strip()) / 100
                    except:
                        GSTRATE = 0.00
    except Exception as e:
        logger.warning(f"Error reading GST rate: {str(e)}")
    
    return GSTRATE

def read_inputf1():
    """Read transaction data"""
    logger.info(f"Reading INPUTF1 from {INPUTF1}")
    
    if not os.path.exists(INPUTF1):
        logger.warning(f"File not found: {INPUTF1}")
        return pl.DataFrame()
    
    try:
        schema = select_clause_aaa
        AAA = fixed_width_reader.read(INPUTF1, schema)
        AAA = AAA.filter(pl.col("FSELERID") == PROD_SELLER_ID)
        AAA = AAA.sort("FTRANSID")
        logger.info(f"AAA created with {len(AAA)} records")
        return AAA
    except Exception as e:
        logger.error(f"Error reading INPUTF1: {str(e)}")
        return pl.DataFrame()

def read_control_files():
    """Read control files"""
    RACTNO = ""
    RPTDAY = datetime.now().strftime("%Y%m%d")
    RPTDAYDD = datetime.now().strftime("%d")
    RPTDAYMM = datetime.now().strftime("%m")
    RPTDCCYY = datetime.now().strftime("%Y")
    
    try:
        if os.path.exists(CONTROL1):
            with open(CONTROL1, 'r') as f:
                line = f.readline()
                if len(line) >= 10:
                    RACTNO = line[0:10].strip()
    except:
        pass
    
    try:
        if os.path.exists(CONTROL2):
            with open(CONTROL2, 'r') as f:
                line = f.readline()
                if len(line) >= 8:
                    RPTDAY = line[0:8].strip()
                    RPTDCCYY = RPTDAY[0:4]
                    RPTDAYMM = RPTDAY[4:6]
                    RPTDAYDD = RPTDAY[6:8]
    except:
        pass
    
    return RACTNO, RPTDAY, RPTDAYDD, RPTDAYMM, RPTDCCYY

def read_report_control():
    """Read report control parameters"""
    CRPCDE = "    "
    BRHCDE = "    "
    PYTCD = "   "
    RPTNM = " " * 40
    REF01 = " " * 20
    REF02 = " " * 20
    SUBIN = " "
    
    try:
        if os.path.exists(CONTRP):
            with open(CONTRP, 'r') as f:
                for line in f:
                    if len(line) >= 100:
                        CRPCDE = line[11:15].strip()
                        BRHCDE = line[16:20].strip()
                        RPTNM = line[25:65].strip()
                        REF01 = line[79:99].strip()
                        REF02 = line[99:119].strip()
    except:
        pass
    
    return CRPCDE, BRHCDE, PYTCD, RPTNM, REF01, REF02, SUBIN

def read_bank_branch(BRHCDE):
    """Read bank branch name"""
    RPTBNM = "BRANCH"
    
    try:
        if os.path.exists(BANKBRCH):
            with open(BANKBRCH, 'r') as f:
                for line in f:
                    if len(line) >= 35 and line[1:5].strip() == BRHCDE:
                        RPTBNM = line[11:41].strip()
                        break
    except:
        pass
    
    return RPTBNM

def generate_report(AAA, GSTRATE, RACTNO, RPTDAY, RPTDAYDD, RPTDAYMM, RPTDCCYY,
                   CRPCDE, BRHCDE, RPTNM, RPTBNM):
    """Generate detailed transaction report"""
    
    if len(AAA) == 0:
        with open(OUTPUT_REPORT, 'w') as f:
            f.write("\n")
            f.write(" " * 30 + "NO TRANSACTIONS FOR THE DAY\n")
            f.write("\n" + "-" * 131 + "\n")
            f.write("GRAND TOTAL COUNT   :           0\n")
            f.write("GRAND TOTAL AMOUNT  :        0.00\n")
            f.write("GRAND TOTAL FEE     :        0.00\n")
            f.write("GRAND TOTAL NET AMT :        0.00\n")
            f.write("-" * 131 + "\n")
        return
    
    with open(OUTPUT_REPORT, 'w') as f:
        GTOTCNT = 0
        GTOTAMT = 0.0
        GTOTFEE = 0.0
        GTOTNAMT = 0.0
        LINECNT = 8
        PAGECNT = 0
        
        # Print header
        LINECNT = write_page_header(f, PAGECNT, RPTDAY, RPTDAYDD, RPTDAYMM, RPTDCCYY,
                                    CRPCDE, BRHCDE, RPTBNM, RPTNM, RACTNO)
        PAGECNT += 1
        
        for idx, row in enumerate(AAA.iter_rows(named=True)):
            # Check for page break
            if LINECNT >= 52:
                f.write("\f")
                LINECNT = write_page_header(f, PAGECNT, RPTDAY, RPTDAYDD, RPTDAYMM,
                                           RPTDCCYY, CRPCDE, BRHCDE, RPTBNM, RPTNM, RACTNO)
                PAGECNT += 1
            
            LINECNT += 2
            
            STCNT = idx + 1
            STAMT = int(row.get("TRANAMT", 0)) / 100
            TRXNFEE = int(row.get("TRXNFEE", 0)) / 100
            NETAMT = STAMT - TRXNFEE
            RECNO = str(row.get("RECNO", "")).strip()
            
            if RECNO == "0":
                PRECNO = "      "
            else:
                PRECNO = str(int(RECNO)).zfill(6)
            
            GTOTCNT += 1
            GTOTAMT += STAMT
            GTOTFEE += TRXNFEE
            GTOTNAMT = GTOTAMT - GTOTFEE
            
            # Detail line
            FTRANSID = str(row.get("FTRANSID", "")).strip()
            FSELORDN = str(row.get("FSELORDN", "")).strip()
            FBUYBKID = str(row.get("FBUYBKID", "")).strip()
            
            f.write(f"{STCNT:4d} {FTRANSID:20s} {FSELORDN:40s} {FBUYBKID:10s} {STAMT:13.2f} {TRXNFEE:11.2f} {NETAMT:11.2f} {PRECNO:6s}\n")
        
        # Print summary
        f.write("\n")
        f.write(f"TOTAL COUNT  :            {GTOTCNT:4d}\n")
        f.write(f"TOTAL AMOUNT :             {GTOTAMT:18.2f}\n")
        f.write(f"TOTAL FEE    :             {GTOTFEE:13.2f}\n")
        f.write(f"TOTAL NET AMOUNT :         {GTOTNAMT:13.2f}\n")
        f.write(f"GRAND TOTAL COUNT   :      {GTOTCNT:4d}\n")
        f.write(f"GRAND TOTAL AMOUNT  :      {GTOTAMT:18.2f}\n")
        f.write(f"GRAND TOTAL FEE     :      {GTOTFEE:13.2f}\n")
        f.write(f"GRAND TOTAL NET AMT :      {GTOTNAMT:13.2f}\n")
        f.write("-" * 131 + "\n")

def write_page_header(f, pagecnt, rptday, rptdaydd, rptdaymm, rptdccyy,
                     crpcde, brhcde, rptbnm, rptnm, ractno):
    """Write page header"""
    
    f.write(f"REPORT NO : {crpcde} -D-002" + " " * 54 + f"DAILY TRANSACTION REPORT" + " " * 11 + f"PAGE : {pagecnt}\n")
    f.write(f"{brhcde} {rptbnm} " + " " * 60 + f"DATE : {rptdaydd}/{rptdaymm}/{rptdccyy}\n")
    f.write(f"PROGRAM ID : DPFQKHR1\n")
    f.write(f"{rptnm} COLLECTION ACCOUNT ({ractno})\n\n")
    f.write(" " * 99 + "TRANSACTION" + " " * 8 + "NET\n")
    f.write(f"NO. {rptnm:20s}SELLER ORDER NO" + " " * 15 + "BUYER BANK" + " " * 2 + "AMOUNT" + " " * 5 + "FEE" + " " * 8 + "AMOUNT" + " " * 8 + "HOST NO\n")
    f.write("-" * 131 + "\n")
    
    return 8

if __name__ == "__main__":
    main()
