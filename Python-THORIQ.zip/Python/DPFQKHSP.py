# DPFQKHSP.py
# /* ACCUMULATE ALL TRANSACTIONS INTO A CUMULATIVE SUMMARY FILE FOR QKH */
# /* VIA COLD SORTED BY NAME OF PAYEE CORPORATION */
# /* INPUT 1: Current daily transactions */
# /* INPUT 2: Previous cumulative summary file */
# /* OUTPUT: Updated cumulative summary file */

import polars as pl
from datetime import datetime, timedelta
import common.fixed_width_reader as fixed_width_reader
from common.batch_date import get_batch_date
import os
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Obtain date for file paths
date_info = get_batch_date()
file_date = date_info["file_date"]
folder_day = date_info["folder_day"]
folder_month = date_info["folder_month"]
folder_year = date_info["folder_year"]

# Define file paths
INPUTF1 = f"/host/dp/input/quickash/INPUTF1_{folder_year}{folder_month}{folder_day}.dat"
INPUTF2 = f"/host/dp/input/quickash/INPUTF2_{folder_year}{folder_month}{folder_day}.dat"
CONTROL2 = f"/host/dp/input/quickash/CONTROL2_{folder_year}{folder_month}{folder_day}.dat"
OUTPUT1 = f"/host/dp/output/DPFQKHSP_CUMSUM_{folder_year}{folder_month}{folder_day}.dat"

# --- Select Clause ---
select_clause_qkh = [
    ("PROCDT", 6, 0),
    ("FTRANSID", 16, 6),
    ("FSELORDN", 40, 22),
    ("TRANAMT", 13, 62),
    ("TRXNFEE", 13, 75),
    ("NETTAMT", 13, 88),
    ("RECNO", 6, 101),
    ("TRANCDE", 3, 107),
    ("FSELERID", 10, 110),
    ("FSELACNO", 20, 120),
    ("FBUYBKID", 15, 140),
    ("FSELERDE", 30, 155),
    ("FBUYACNO", 20, 185)
]

def main():
    """SAS DPFQKHSP program - QuickCash Cumulative Summary File"""
    
    try:
        logger.info("Starting DPFQKHSP - QUICKASH CUMULATIVE SUMMARY FILE GENERATION")
        
        # Step 1: Read current day transactions
        logger.info(f"Reading current transactions from {INPUTF1}")
        AAA = read_input_file(INPUTF1)
        
        # Step 2: Read control date
        logger.info(f"Reading control date from {CONTROL2}")
        control_date = read_control_date()
        
        # Step 3: Read previous cumulative file
        logger.info(f"Reading previous summary from {INPUTF2}")
        PREVFILE = read_input_file(INPUTF2)
        
        # Step 4: Extract date boundaries from previous file
        date_bounds = extract_date_bounds(PREVFILE, AAA)
        
        # Step 5: Determine if cumulative or reset based on report date (01st of month)
        logger.info("Processing cumulative summary")
        output_records = process_cumulative(control_date, AAA, PREVFILE, date_bounds)
        
        # Step 6: Write output file
        logger.info(f"Writing cumulative summary to {OUTPUT1}")
        write_output(output_records, OUTPUT1)
        
        logger.info("DPFQKHSP processing completed successfully.")
        
    except Exception as e:
        logger.error(f"Error in DPFQKHSP processing: {str(e)}")
        raise

def read_input_file(file_path):
    """Read transaction file"""
    
    if not os.path.exists(file_path):
        logger.warning(f"File not found: {file_path}")
        return pl.DataFrame()
    
    records = []
    try:
        with open(file_path, 'r') as f:
            for line in f:
                if len(line) < 205:
                    continue
                
                try:
                    record = {
                        "PROCDT": line[0:6].strip() if len(line) > 5 else "",
                        "FTRANSID": line[6:22].strip() if len(line) > 21 else "",
                        "FSELORDN": line[22:62].strip() if len(line) > 61 else "",
                        "TRANAMT": float(line[62:75].strip() if len(line) > 74 else "0"),
                        "TRXNFEE": float(line[75:88].strip() if len(line) > 87 else "0"),
                        "NETTAMT": float(line[88:101].strip() if len(line) > 100 else "0"),
                        "RECNO": line[101:107].strip() if len(line) > 106 else "",
                        "TRANCDE": line[107:110].strip() if len(line) > 109 else "",
                        "FSELERID": line[110:120].strip() if len(line) > 119 else "",
                        "FSELACNO": line[120:140].strip() if len(line) > 139 else "",
                        "FBUYBKID": line[140:155].strip() if len(line) > 154 else "",
                        "FSELERDE": line[155:185].strip() if len(line) > 184 else "",
                        "FBUYACNO": line[185:205].strip() if len(line) > 204 else ""
                    }
                    records.append(record)
                except:
                    continue
        
        if records:
            df = pl.DataFrame(records)
            logger.info(f"Read {len(df)} transaction records from {os.path.basename(file_path)}")
            return df
        return pl.DataFrame()
    except Exception as e:
        logger.error(f"Error reading {file_path}: {str(e)}")
        return pl.DataFrame()

def read_control_date():
    """Read processing date from control file"""
    
    control_date = {
        "RPTDAY": "01010100",
        "RPTDAYDD": "01",
        "RPTDAYMM": "01",
        "RPTDAYYY": "00",
        "RPTDAYCC": "01"
    }
    
    try:
        if os.path.exists(CONTROL2):
            with open(CONTROL2, 'r') as f:
                line = f.readline().strip()
                if len(line) >= 8:
                    # Format: YYYYMMDD (8 digits)
                    actdate = line[:8]
                    yy = actdate[2:4]  # YY
                    mm = actdate[4:6]  # MM
                    dd = actdate[6:8]  # DD
                    cc = actdate[0:2]  # CC (century)
                    
                    control_date = {
                        "RPTDAY": actdate,
                        "RPTDAYDD": dd,
                        "RPTDAYMM": mm,
                        "RPTDAYYY": yy,
                        "RPTDAYCC": cc
                    }
                    logger.info(f"Control date: {cc}{yy}{mm}{dd}")
    except Exception as e:
        logger.warning(f"Error reading control date: {str(e)}")
    
    return control_date

def extract_date_bounds(prevfile, aaa):
    """Extract first and last dates from files"""
    
    bounds = {
        "RDD1": "01",
        "RMM1": "01",
        "RYY1": "00",
        "RDD2": "01",
        "RMM2": "01",
        "RYY2": "00"
    }
    
    # Get first date from PREVFILE
    if len(prevfile) > 0:
        first_rec = prevfile.row(0, named=True)
        procdt = str(first_rec.get("PROCDT", "010100"))
        if len(procdt) >= 6:
            bounds["RDD1"] = procdt[0:2]
            bounds["RMM1"] = procdt[2:4]
            bounds["RYY1"] = procdt[4:6]
        
        # Get last date from PREVFILE
        last_rec = prevfile.row(len(prevfile) - 1, named=True)
        procdt = str(last_rec.get("PROCDT", "010100"))
        if len(procdt) >= 6:
            bounds["RDD2"] = procdt[0:2]
            bounds["RMM2"] = procdt[2:4]
            bounds["RYY2"] = procdt[4:6]
    
    logger.info(f"Date bounds - Start: {bounds['RDD1']}/{bounds['RMM1']}/{bounds['RYY1']}, End: {bounds['RDD2']}/{bounds['RMM2']}/{bounds['RYY2']}")
    
    return bounds

def process_cumulative(control_date, aaa, prevfile, date_bounds):
    """Process cumulative summary"""
    
    output_records = []
    
    # Check if report date is 01 (first day of month - reset cycle)
    rptdaydd = control_date.get("RPTDAYDD", "01")
    
    if rptdaydd == "01":
        # First day of month: output only current day's transactions (AAA)
        logger.info("Report date is 01st - outputting current day transactions only (reset cycle)")
        if len(aaa) > 0:
            for row in aaa.iter_rows(named=True):
                output_records.append(row)
    else:
        # Other days: merge previous cumulative file with current day (sorted by PROCDT, FTRANSID)
        logger.info("Report date is not 01st - outputting cumulative (previous + current)")
        
        # Combine PREVFILE and AAA
        if len(prevfile) > 0:
            for row in prevfile.iter_rows(named=True):
                output_records.append(row)
        
        if len(aaa) > 0:
            for row in aaa.iter_rows(named=True):
                output_records.append(row)
        
        # Sort by PROCDT and FTRANSID
        if output_records:
            df = pl.DataFrame(output_records)
            df = df.sort([pl.col("PROCDT"), pl.col("FTRANSID")])
            output_records = [row for row in df.iter_rows(named=True)]
    
    logger.info(f"Processing output: {len(output_records)} records")
    
    return output_records

def write_output(records, output_file):
    """Write output file in fixed format"""
    
    logger.info(f"Writing {len(records)} records to cumulative summary file")
    
    if len(records) == 0:
        logger.warning("No records to write")
        return
    
    try:
        with open(output_file, 'w') as f:
            for record in records:
                procdt = str(record.get("PROCDT", "")).ljust(6)
                ftransid = str(record.get("FTRANSID", "")).ljust(16)
                fselordn = str(record.get("FSELORDN", "")).ljust(40)
                tranamt = float(record.get("TRANAMT", 0))
                trxnfee = float(record.get("TRXNFEE", 0))
                nettamt = float(record.get("NETTAMT", 0))
                recno = str(record.get("RECNO", "")).ljust(6)
                trancde = str(record.get("TRANCDE", "")).ljust(3)
                fselerid = str(record.get("FSELERID", "")).ljust(10)
                fselacno = str(record.get("FSELACNO", "")).ljust(20)
                fbuybkid = str(record.get("FBUYBKID", "")).ljust(15)
                fselerde = str(record.get("FSELERDE", "")).ljust(30)
                fbuyacno = str(record.get("FBUYACNO", "")).ljust(20)
                
                # Build fixed-format line (300 chars total)
                line = (
                    f"{procdt}"
                    f"{ftransid}"
                    f"{fselordn}"
                    f"{tranamt:13.0f}"
                    f"{trxnfee:13.0f}"
                    f"{nettamt:13.0f}"
                    f"{recno}"
                    f"{trancde}"
                    f"{fselerid}"
                    f"{fselacno}"
                    f"{fbuybkid}"
                    f"{fselerde}"
                    f"{fbuyacno}"
                )
                
                f.write(line + "\n")
        
        logger.info(f"Cumulative summary file written successfully to {output_file}")
    
    except Exception as e:
        logger.error(f"Error writing output file: {str(e)}")
        raise

if __name__ == "__main__":
    main()
