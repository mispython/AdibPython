# DPFQKHSU.py
# /* QUICKASH MALAYSIA SDN BHD - COLLECTION ACCOUNT (3999514522) */
# /* TO PRODUCE A SUMMARY FILE FOR REPORTING */
# /* CLONED FROM DPISVDSU */

import polars as pl
from datetime import datetime, timedelta
import common.fixed_width_reader as fixed_width_reader
from common.batch_date import get_batch_date
import os
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Obtain date for file paths
date_info = get_batch_date()
file_date = date_info["file_date"]
folder_day = date_info["folder_day"]
folder_month = date_info["folder_month"]
folder_year = date_info["folder_year"]

# Define file paths
INPUTF1 = f"/host/dp/input/quickash/INPUTF1_{folder_year}{folder_month}{folder_day}.dat"
INPUTF2 = f"/host/dp/input/quickash/INPUTF2_{folder_year}{folder_month}{folder_day}.dat"
CONTROL1 = f"/host/dp/input/quickash/CONTROL1_{folder_year}{folder_month}{folder_day}.dat"
CONTROL2 = f"/host/dp/input/quickash/CONTROL2_{folder_year}{folder_month}{folder_day}.dat"
OUTPUT1 = f"/host/dp/output/DPFQKHSU_OUTPUT_{folder_year}{folder_month}{folder_day}.dat"
EXCPO = f"/host/dp/output/DPFQKHSU_EXCEPTIONS_{folder_year}{folder_month}{folder_day}.txt"

# --- Select Clause ---
select_clause_aaa = [
    ("BANKNO", 3, 4),
    ("ACCTNO", 10, 8),
    ("PROCDT", 8, 19),
    ("DATATYP", 1, 27),
    ("USERIND", 1, 29),
    ("ATMNUM", 4, 30),
    ("FRMTCDE", 3, 47),
    ("TRANCDE", 3, 50),
    ("SRCECDE", 3, 53),
    ("TERMNO", 4, 57),
    ("TRXNTIME", 6, 65),
    ("TRANAMT", 13, 72),
    ("EBKCHQ", 6, 88),
    ("RECNO", 6, 90),
    ("CHQNO", 6, 90),
    ("TRAITYP", 1, 96),
    ("TRAITY2", 1, 110),
    ("TTRANCODE", 3, 107),
    ("FLTDAY", 2, 196),
    ("BANKCHQ", 2, 198),
    ("COMMIND", 1, 119),
    ("TRAILDT1", 200, 96),
    ("TRAILDT2", 200, 296),
    ("TRAILDT3", 115, 496)
]

PROD_SELLER_ID = "SE00027963"

def main():
    """SAS DPFQKHSU program - QuickCash Summary File Generation"""
    
    try:
        logger.info("Starting DPFQKHSU - QUICKASH SUMMARY FILE GENERATION")
        
        # Step 1: Read transaction file
        AAA = read_inputf1()
        
        if len(AAA) == 0:
            logger.warning("No transactions found")
            return
        
        # Step 2: Read extended file
        BBB = read_inputf2()
        
        # Step 3: Read control files
        RACCTNO = read_control1()
        
        # Step 4: Process and merge data
        logger.info("Processing transaction data")
        OUTFF, EXCPO_data = process_transactions(AAA, BBB)
        
        # Step 5: Generate output
        logger.info(f"Writing output to {OUTPUT1}")
        write_output(OUTFF, OUTPUT1)
        
        if len(EXCPO_data) > 0:
            logger.info(f"Writing exceptions to {EXCPO}")
            write_exceptions(EXCPO_data, EXCPO)
        
        logger.info("DPFQKHSU processing completed successfully.")
        
    except Exception as e:
        logger.error(f"Error in DPFQKHSU processing: {str(e)}")
        raise

def read_inputf1():
    """Read transaction file and filter"""
    logger.info(f"Reading INPUTF1 from {INPUTF1}")
    
    if not os.path.exists(INPUTF1):
        logger.warning(f"File not found: {INPUTF1}")
        return pl.DataFrame()
    
    records = []
    try:
        with open(INPUTF1, 'r') as f:
            for line in f:
                if len(line) < 100:
                    continue
                
                try:
                    TTRANCODE = line[107:110].strip() if len(line) > 109 else "000"
                    SRCECDE = line[53:56].strip() if len(line) > 55 else ""
                    
                    # Skip if transaction code is 874 (delete) or source code not 313 (FPX)
                    if TTRANCODE == "874":
                        continue
                    if SRCECDE != "313":
                        continue
                    
                    # Extract key fields
                    record = {
                        "ACCTNO": line[8:18].strip() if len(line) > 17 else "",
                        "PROCDT": line[19:27].strip() if len(line) > 26 else "",
                        "DATATYP": line[27:28].strip() if len(line) > 27 else "",
                        "TRANCDE": line[50:53].strip() if len(line) > 52 else "",
                        "SRCECDE": SRCECDE,
                        "TRANAMT": int(line[72:85].strip() if len(line) > 84 else 0),
                        "EBKCHQ": line[88:94].strip() if len(line) > 93 else "",
                        "RECNO": line[90:96].strip() if len(line) > 95 else "",
                        "TRAILDT1": line[96:296].strip() if len(line) > 295 else ""
                    }
                    records.append(record)
                except:
                    continue
        
        if records:
            AAA = pl.DataFrame(records)
            logger.info(f"AAA created with {len(AAA)} records")
            return AAA
        return pl.DataFrame()
    except Exception as e:
        logger.error(f"Error reading INPUTF1: {str(e)}")
        return pl.DataFrame()

def read_inputf2():
    """Read extended transaction file"""
    logger.info(f"Reading INPUTF2 from {INPUTF2}")
    
    if not os.path.exists(INPUTF2):
        logger.warning(f"File not found: {INPUTF2}")
        return pl.DataFrame()
    
    records = []
    try:
        with open(INPUTF2, 'r') as f:
            for line in f:
                if len(line) < 100:
                    continue
                
                FSELERID = line[191:201].strip() if len(line) > 200 else ""
                if FSELERID != PROD_SELLER_ID:
                    continue
                
                record = {
                    "FTRANSID": line[0:16].strip() if len(line) > 15 else "",
                    "FSELERID": FSELERID,
                    "FSELORDN": line[151:191].strip() if len(line) > 190 else ""
                }
                records.append(record)
        
        if records:
            BBB = pl.DataFrame(records)
            logger.info(f"BBB created with {len(BBB)} records")
            return BBB
        return pl.DataFrame()
    except Exception as e:
        logger.error(f"Error reading INPUTF2: {str(e)}")
        return pl.DataFrame()

def read_control1():
    """Read control account number"""
    RACCTNO = ""
    try:
        if os.path.exists(CONTROL1):
            with open(CONTROL1, 'r') as f:
                line = f.readline()
                if len(line) >= 10:
                    RACCTNO = line[0:10].strip()
    except:
        pass
    return RACCTNO

def process_transactions(AAA, BBB):
    """Process and merge transaction data"""
    
    # Merge AAA and BBB on transaction ID
    OUTFF = AAA
    if len(BBB) > 0:
        OUTFF = AAA.join(BBB, left_on="TRANID", right_on="FTRANSID", how="inner")
    
    # Identify exceptions (in AAA but not in BBB)
    EXCPO_data = AAA.anti_join(BBB, on="TRANID") if len(BBB) > 0 else AAA
    
    return OUTFF, EXCPO_data

def write_output(OUTFF, output_file):
    """Write output file"""
    logger.info(f"Writing output with {len(OUTFF)} records")
    
    if len(OUTFF) == 0:
        return
    
    with open(output_file, 'w') as f:
        for row in OUTFF.iter_rows(named=True):
            WSDD = str(row.get("PROCDT", ""))[-2:]
            WSMM = str(row.get("PROCDT", ""))[4:6]
            WSYY = str(row.get("PROCDT", ""))[2:4]
            TRANAMT = int(row.get("TRANAMT", 0)) / 100
            TRXNFEE = int(row.get("TRXNFEE", 0)) / 100 if "TRXNFEE" in row else 0
            NETTAMT = TRANAMT - TRXNFEE
            
            if row.get("COMMIND") and row.get("TRANAMT") != 150:
                line = f"{WSDD}{WSMM}{WSYY}{str(row.get('FTRANSID', '')).ljust(16)}{str(row.get('FSELORDN', '')).ljust(40)}{TRANAMT:13.2f}{TRXNFEE:13.2f}{NETTAMT:13.2f}"
                f.write(line + "\n")

def write_exceptions(EXCPO_data, exc_file):
    """Write exception records"""
    logger.info(f"Writing {len(EXCPO_data)} exception records")
    
    with open(exc_file, 'w') as f:
        f.write("========== DAILY EXCEPTION REPORT ==========\n")
        f.write("   FOR QUICKASH MALAYSIA SDN BHD\n")
        f.write("=========================================\n\n")
        
        TOTAMT = 0.0
        TOTCNT = 0
        
        for idx, row in enumerate(EXCPO_data.iter_rows(named=True)):
            TOTCNT += 1
            TRANAMT = int(row.get("TRANAMT", 0)) / 100
            TOTAMT += TRANAMT
            
            WSDD = str(row.get("PROCDT", ""))[-2:]
            WSMM = str(row.get("PROCDT", ""))[4:6]
            WSYY = str(row.get("PROCDT", ""))[2:4]
            
            f.write(f"{TOTCNT:7d} {WSDD}/{WSMM}/{WSYY} {str(row.get('FTRANSID', '')).ljust(16)} {TRANAMT:13.2f} {str(row.get('TRANCDE', '')).ljust(3)} {str(row.get('SRCECDE', '')).ljust(3)}\n")
        
        f.write("\n")
        f.write(f"TOTAL EXCEPTION AMOUNT  : {TOTAMT:13.2f}\n")
        f.write(f"TOTAL EXCEPTION COUNT   : {TOTCNT:7d}\n")

if __name__ == "__main__":
    main()
