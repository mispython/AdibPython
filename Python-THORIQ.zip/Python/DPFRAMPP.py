# DPFRAMPP.py
# /* RAM CREDIT INFORMATION SDN BHD - COLLECTION ACCOUNT (3999572915) */
# /* TO PRODUCE DAILY PAYMENT FILE FOR TRANSMISSION TO BANK */

import polars as pl
from datetime import datetime, timedelta
import common.fixed_width_reader as fixed_width_reader
from common.batch_date import get_batch_date
import os
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Obtain date for file paths
date_info = get_batch_date()
file_date = date_info["file_date"]
folder_day = date_info["folder_day"]
folder_month = date_info["folder_month"]
folder_year = date_info["folder_year"]

# Define file paths
INPUTF1 = f"/host/dp/input/ram/INPUTF1_{folder_year}{folder_month}{folder_day}.dat"
CONTROL1 = f"/host/dp/input/ram/CONTROL1_{folder_year}{folder_month}{folder_day}.dat"
CONTROL2 = f"/host/dp/input/ram/CONTROL2_{folder_year}{folder_month}{folder_day}.dat"
OUTPUT1 = f"/host/dp/output/DPFRAMPP_OUTPUT_{folder_year}{folder_month}{folder_day}.dat"

# --- Select Clause ---
select_clause_ram = [
    ("PROCDT", 8, 19),
    ("FTRANSID", 16, 0),
    ("FSELORDN", 40, 151),
    ("TRANAMT", 13, 72),
    ("TRXNFEE", 13, 78),
    ("NETTAMT", 13, 85),
    ("RECNO", 6, 90),
    ("TRANCDE", 3, 50),
    ("FSELERID", 10, 192),
    ("FSELACNO", 10, 202),
    ("FBUYBKID", 4, 212),
    ("FSELERDE", 10, 216),
    ("FBUYACNO", 12, 226)
]

# RAM Credit Information Collection Account
PROD_SELLER_ID = "SE00031978"

def main():
    """SAS DPFRAMPP program - RAM Credit Payment File Generation"""
    
    try:
        logger.info("Starting DPFRAMPP - RAM CREDIT DAILY PAYMENT FILE GENERATION")
        
        # Step 1: Read transaction file
        logger.info(f"Reading transaction file from {INPUTF1}")
        INPUTF1_data = read_inputf1()
        
        # Step 2: Read control files
        RACTNO = read_control1()
        RPTDATE = read_control2()
        
        # Step 3: Process records
        logger.info("Processing payment records")
        OUTPUT_records = process_records(INPUTF1_data, RACTNO, RPTDATE)
        
        # Step 4: Write output file
        logger.info(f"Writing payment file to {OUTPUT1}")
        write_output(OUTPUT_records, OUTPUT1)
        
        logger.info("DPFRAMPP processing completed successfully.")
        
    except Exception as e:
        logger.error(f"Error in DPFRAMPP processing: {str(e)}")
        raise

def read_inputf1():
    """Read transaction file from input F1"""
    
    if not os.path.exists(INPUTF1):
        logger.warning(f"File not found: {INPUTF1}")
        return pl.DataFrame()
    
    records = []
    try:
        df = fixed_width_reader.read(INPUTF1, select_clause_ram)
        
        # Filter for RAM Credit production seller ID
        df_filtered = df.filter(pl.col("FSELERID") == PROD_SELLER_ID)
        
        logger.info(f"Read {len(df)} records, filtered to {len(df_filtered)} for seller ID {PROD_SELLER_ID}")
        
        return df_filtered
    except Exception as e:
        logger.error(f"Error reading INPUTF1: {str(e)}")
        return pl.DataFrame()

def read_control1():
    """Read control file for account number"""
    
    RACTNO = ""
    try:
        if os.path.exists(CONTROL1):
            with open(CONTROL1, 'r') as f:
                line = f.readline().strip()
                if len(line) >= 10:
                    RACTNO = line[:10]
                    logger.info(f"Read control account: {RACTNO}")
    except Exception as e:
        logger.error(f"Error reading CONTROL1: {str(e)}")
    
    return RACTNO

def read_control2():
    """Read control file for report date"""
    
    RPTDATE = {
        "RPTDAYDD": "00",
        "RPTDAYMM": "00",
        "RPTDCCYY": "00"
    }
    
    try:
        if os.path.exists(CONTROL2):
            with open(CONTROL2, 'r') as f:
                line = f.readline().strip()
                if len(line) >= 6:
                    yymmdd = line[:6]  # YYMMDD format
                    RPTDATE["RPTDAYDD"] = yymmdd[4:6]
                    RPTDATE["RPTDAYMM"] = yymmdd[2:4]
                    RPTDATE["RPTDCCYY"] = "20" + yymmdd[0:2]
                    logger.info(f"Read report date: {RPTDATE['RPTDCCYY']}-{RPTDATE['RPTDAYMM']}-{RPTDATE['RPTDAYDD']}")
    except Exception as e:
        logger.error(f"Error reading CONTROL2: {str(e)}")
    
    return RPTDATE

def process_records(df, account_no, report_date):
    """Process transaction records and add header/trailer"""
    
    output_records = []
    
    # Header record
    header = {
        "RECTYPE": "0",
        "ACCTNO": account_no.ljust(10),
        "RPTDAYDD": report_date["RPTDAYDD"],
        "RPTDAYMM": report_date["RPTDAYMM"],
        "RPTDCCYY": report_date["RPTDCCYY"],
        "RECCOUNT": str(len(df)).zfill(6),
        "TOTAMOUNT": "0",
        "FILLER": ""
    }
    output_records.append(header)
    
    # Detail records
    total_amount = 0
    
    if len(df) > 0:
        for row in df.iter_rows(named=True):
            try:
                tranamt = int(row.get("TRANAMT", 0)) if row.get("TRANAMT") else 0
                total_amount += tranamt
                
                detail = {
                    "RECTYPE": "1",
                    "FTRANSID": str(row.get("FTRANSID", "")).ljust(16),
                    "FSELORDN": str(row.get("FSELORDN", "")).ljust(40),
                    "FBUYBKID": str(row.get("FBUYBKID", "")).ljust(4),
                    "TRANAMT": str(tranamt).zfill(13),
                    "TRXNFEE": str(int(row.get("TRXNFEE", 0)) if row.get("TRXNFEE") else 0).zfill(13),
                    "NETTAMT": str(int(row.get("NETTAMT", 0)) if row.get("NETTAMT") else tranamt).zfill(13),
                    "RECNO": str(row.get("RECNO", "")).ljust(6),
                    "TRANCDE": str(row.get("TRANCDE", "")).ljust(3),
                    "FSELERID": str(row.get("FSELERID", "")).ljust(10),
                    "FSELACNO": str(row.get("FSELACNO", "")).ljust(10),
                    "FSELERDE": str(row.get("FSELERDE", "")).ljust(10),
                    "FBUYACNO": str(row.get("FBUYACNO", "")).ljust(12)
                }
                output_records.append(detail)
            except Exception as e:
                logger.warning(f"Error processing record: {str(e)}")
                continue
    
    # Trailer record
    trailer = {
        "RECTYPE": "9",
        "RECCOUNT": str(len(df)).zfill(6),
        "TOTAMOUNT": str(total_amount).zfill(15),
        "FILLER": ""
    }
    output_records.append(trailer)
    
    return output_records

def write_output(records, output_file):
    """Write output file in fixed-format"""
    
    logger.info(f"Writing {len(records)} records (including header and trailer)")
    
    try:
        with open(output_file, 'w') as f:
            for record in records:
                rectype = record.get("RECTYPE", "")
                
                if rectype == "0":
                    # Header: REC=0, ACCTNO(10), DD(2), MM(2), CCYY(4), RECCOUNT(6), TOTAMOUNT(15)
                    line = f"{rectype}{record['ACCTNO']}{record['RPTDAYDD']}{record['RPTDAYMM']}{record['RPTDCCYY']}{record['RECCOUNT']}{record.get('TOTAMOUNT', '').rjust(15)}"
                
                elif rectype == "1":
                    # Detail: REC=1, FTRANSID(16), FSELORDN(40), FBUYBKID(4), TRANAMT(13), TRXNFEE(13), NETTAMT(13), RECNO(6), TRANCDE(3), FSELERID(10), FSELACNO(10), FSELERDE(10), FBUYACNO(12)
                    line = f"{rectype}{record['FTRANSID']}{record['FSELORDN']}{record['FBUYBKID']}{record['TRANAMT']}{record['TRXNFEE']}{record['NETTAMT']}{record['RECNO']}{record['TRANCDE']}{record['FSELERID']}{record['FSELACNO']}{record['FSELERDE']}{record['FBUYACNO']}"
                
                elif rectype == "9":
                    # Trailer: REC=9, RECCOUNT(6), TOTAMOUNT(15)
                    line = f"{rectype}{record['RECCOUNT']}{record['TOTAMOUNT']}"
                
                else:
                    continue
                
                f.write(line + "\n")
        
        logger.info(f"Payment file written successfully to {output_file}")
    
    except Exception as e:
        logger.error(f"Error writing output file: {str(e)}")
        raise

if __name__ == "__main__":
    main()
