# DPFRAMR1.py
# /* FPX DAILY TRANSACTION FILE (ODR) FOR RAM CREDIT INFORMATION (3999572915) */
# /* DP7304 AAB2 - CHANGE HARDCODE GST TO READ FROM PARAMETER FILE */

import polars as pl
from datetime import datetime, timedelta
import common.fixed_width_reader as fixed_width_reader
from common.batch_date import get_batch_date
import os
import logging
import math

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Obtain date for file paths
date_info = get_batch_date()
file_date = date_info["file_date"]
folder_day = date_info["folder_day"]
folder_month = date_info["folder_month"]
folder_year = date_info["folder_year"]

# Define file paths
INPUTF1 = f"/host/dp/input/ram/INPUTF1_{folder_year}{folder_month}{folder_day}.dat"
GSTRATE_FILE = f"/host/dp/input/ram/GSTRATE_{folder_year}{folder_month}{folder_day}.dat"
CONTROL1 = f"/host/dp/input/ram/CONTROL1_{folder_year}{folder_month}{folder_day}.dat"
CONTROL2 = f"/host/dp/input/ram/CONTROL2_{folder_year}{folder_month}{folder_day}.dat"
CONTRP = f"/host/dp/input/ram/CONTRP_{folder_year}{folder_month}{folder_day}.dat"
BANKBRCH = f"/host/dp/input/ram/BANKBRCH_{folder_year}{folder_month}{folder_day}.dat"
OUTPUT1 = f"/host/dp/output/DPFRAMR1_REPORT_{folder_year}{folder_month}{folder_day}.txt"

# --- Select Clause ---
select_clause_ram = [
    ("PROCDT", 6, 0),
    ("FTRANSID", 16, 6),
    ("FSELORDN", 40, 22),
    ("TRANAMT", 13, 62),
    ("TRXNFEE", 13, 75),
    ("NETTAMT", 13, 88),
    ("RECNO", 6, 101),
    ("TRANCDE", 3, 107),
    ("FSELERID", 10, 110),
    ("FSELACNO", 20, 120),
    ("FBUYBKID", 15, 140),
    ("FSELERDE", 30, 155),
    ("FBUYACNO", 20, 185)
]

PROD_SELLER_ID = "SE00031978"

def main():
    """SAS DPFRAMR1 program - RAM Credit Daily Transaction Report"""
    
    try:
        logger.info("Starting DPFRAMR1 - RAM CREDIT DAILY TRANSACTION REPORT")
        
        # Step 1: Read GST rate
        gst_rate = read_gst_rate()
        
        # Step 2: Read transaction file
        AAA, BBB = read_and_classify_transactions()
        
        # Step 3: Read control files
        ractno = read_control1()
        rptdate = read_control2()
        corp_info = read_report_control()
        bank_branch = read_bank_branch(corp_info.get("BRHCDE", ""))
        
        # Step 4: Process and merge data
        logger.info("Processing daily transactions")
        output_records = process_transactions(AAA, BBB, gst_rate, ractno, rptdate, corp_info, bank_branch)
        
        # Step 5: Write output file
        logger.info(f"Writing report to {OUTPUT1}")
        write_report(output_records, ractno, rptdate, corp_info, bank_branch)
        
        logger.info("DPFRAMR1 processing completed successfully.")
        
    except Exception as e:
        logger.error(f"Error in DPFRAMR1 processing: {str(e)}")
        raise

def read_gst_rate():
    """Read GST rate from parameter file"""
    
    gst_rate = 0.06  # Default 6%
    try:
        if os.path.exists(GSTRATE_FILE):
            with open(GSTRATE_FILE, 'r') as f:
                line = f.readline().strip()
                if len(line) >= 4:
                    gst_rate = float(line[:4]) / 100
                    logger.info(f"GST rate from file: {gst_rate*100:.2f}%")
    except Exception as e:
        logger.warning(f"Error reading GST rate: {str(e)}, using default 6%")
    
    return gst_rate

def read_and_classify_transactions():
    """Read and classify transactions by fee amount"""
    
    logger.info(f"Reading transactions from {INPUTF1}")
    
    if not os.path.exists(INPUTF1):
        logger.warning(f"File not found: {INPUTF1}")
        return pl.DataFrame(), pl.DataFrame()
    
    aaa_records = []
    bbb_records = []
    
    try:
        with open(INPUTF1, 'r') as f:
            for line in f:
                if len(line) < 200:
                    continue
                
                try:
                    fselerid = line[110:120].strip() if len(line) > 119 else ""
                    
                    if fselerid != PROD_SELLER_ID:
                        continue
                    
                    record = {
                        "PROCDT": line[0:6].strip() if len(line) > 5 else "",
                        "FTRANSID": line[6:22].strip() if len(line) > 21 else "",
                        "FSELORDN": line[22:62].strip() if len(line) > 61 else "",
                        "TRANAMT": float(line[62:75].strip() if len(line) > 74 else "0"),
                        "TRXNFEE": float(line[75:88].strip() if len(line) > 87 else "0"),
                        "NETTAMT": float(line[88:101].strip() if len(line) > 100 else "0"),
                        "RECNO": line[101:107].strip() if len(line) > 106 else "",
                        "TRANCDE": line[107:110].strip() if len(line) > 109 else "",
                        "FSELERID": fselerid,
                        "FSELACNO": line[120:140].strip() if len(line) > 139 else "",
                        "FBUYBKID": line[140:155].strip() if len(line) > 154 else "",
                        "FSELERDE": line[155:185].strip() if len(line) > 184 else "",
                        "FBUYACNO": line[185:205].strip() if len(line) > 204 else ""
                    }
                    
                    # Segregate B2B (250) and B2C (200) by fee
                    trxnfee = record["TRXNFEE"]
                    if trxnfee == 200:
                        aaa_records.append(record)
                    else:
                        bbb_records.append(record)
                except:
                    continue
        
        aaa = pl.DataFrame(aaa_records) if aaa_records else pl.DataFrame()
        bbb = pl.DataFrame(bbb_records) if bbb_records else pl.DataFrame()
        
        logger.info(f"B2C (200 fee): {len(aaa)} records, B2B (other fee): {len(bbb)} records")
        return aaa, bbb
    except Exception as e:
        logger.error(f"Error reading transactions: {str(e)}")
        return pl.DataFrame(), pl.DataFrame()

def read_control1():
    """Read control account number"""
    
    ractno = ""
    try:
        if os.path.exists(CONTROL1):
            with open(CONTROL1, 'r') as f:
                line = f.readline().strip()
                if len(line) >= 10:
                    ractno = line[:10]
                    logger.info(f"Control account: {ractno}")
    except Exception as e:
        logger.warning(f"Error reading CONTROL1: {str(e)}")
    
    return ractno

def read_control2():
    """Read control processing date"""
    
    rptdate = {
        "RPTDAYDD": "01",
        "RPTDAYMM": "01",
        "RPTDCCYY": "2020"
    }
    
    try:
        if os.path.exists(CONTROL2):
            with open(CONTROL2, 'r') as f:
                line = f.readline().strip()
                if len(line) >= 8:
                    yy = line[0:2]
                    mm = line[2:4]
                    dd = line[4:6]
                    ccyy = "20" + yy
                    
                    rptdate = {
                        "RPTDAYDD": dd,
                        "RPTDAYMM": mm,
                        "RPTDCCYY": ccyy
                    }
                    logger.info(f"Report date: {ccyy}-{mm}-{dd}")
    except Exception as e:
        logger.warning(f"Error reading CONTROL2: {str(e)}")
    
    return rptdate

def read_report_control():
    """Read report control parameters"""
    
    corp_info = {
        "CRPCDE": "",
        "BRHCDE": "",
        "RPTNM": "",
        "REF01": "",
        "REF02": ""
    }
    
    try:
        if os.path.exists(CONTRP):
            with open(CONTRP, 'r') as f:
                for line in f:
                    if len(line) < 120:
                        continue
                    
                    cacctno = line[0:10].strip() if len(line) > 9 else ""
                    corpcode = line[11:15].strip() if len(line) > 14 else ""
                    brchcode = line[16:20].strip() if len(line) > 19 else ""
                    reptnm = line[25:65].strip() if len(line) > 64 else ""
                    refer1 = line[79:99].strip() if len(line) > 98 else ""
                    refer2 = line[99:119].strip() if len(line) > 118 else ""
                    
                    corp_info = {
                        "CRPCDE": corpcode,
                        "BRHCDE": brchcode,
                        "RPTNM": reptnm,
                        "REF01": refer1,
                        "REF02": refer2
                    }
                    break
    except Exception as e:
        logger.warning(f"Error reading CONTRP: {str(e)}")
    
    return corp_info

def read_bank_branch(branch_code):
    """Read bank branch name"""
    
    brch_name = ""
    try:
        if os.path.exists(BANKBRCH):
            with open(BANKBRCH, 'r') as f:
                for line in f:
                    if len(line) < 40:
                        continue
                    
                    brchcode = line[1:5].strip() if len(line) > 4 else ""
                    brchname = line[11:41].strip() if len(line) > 40 else ""
                    
                    if brchcode == branch_code:
                        brch_name = brchname
                        logger.info(f"Branch name: {brch_name}")
                        break
    except Exception as e:
        logger.warning(f"Error reading BANKBRCH: {str(e)}")
    
    return brch_name

def process_transactions(aaa, bbb, gst_rate, ractno, rptdate, corp_info, bank_branch):
    """Process and combine transactions"""
    
    output_records = []
    
    # Combine AAA and BBB
    if len(aaa) > 0:
        for row in aaa.iter_rows(named=True):
            output_records.append(row)
    
    if len(bbb) > 0:
        for row in bbb.iter_rows(named=True):
            output_records.append(row)
    
    logger.info(f"Processing {len(output_records)} total transactions")
    
    return output_records

def write_report(records, ractno, rptdate, corp_info, bank_branch):
    """Write transaction report"""
    
    logger.info(f"Generating report with {len(records)} transactions")
    
    try:
        with open(OUTPUT1, 'w') as f:
            # Write header
            f.write(f"RAM CREDIT INFORMATION SDN BHD\n")
            f.write(f"DAILY TRANSACTION REPORT\n")
            f.write(f"Date: {rptdate['RPTDCCYY']}-{rptdate['RPTDAYMM']}-{rptdate['RPTDAYDD']}\n")
            f.write(f"Account: {ractno}\n")
            f.write(f"Report: {corp_info.get('RPTNM', '')}\n")
            f.write(f"Branch: {bank_branch}\n\n")
            
            f.write("Transaction ID        Seller Order                        Amount        Fee       Net Amount\n")
            f.write("-" * 100 + "\n\n")
            
            total_amt = 0
            total_fee = 0
            total_net = 0
            
            for record in records:
                ftransid = str(record.get("FTRANSID", "")).ljust(16)
                fselordn = str(record.get("FSELORDN", "")).ljust(40)
                tranamt = float(record.get("TRANAMT", 0))
                trxnfee = float(record.get("TRXNFEE", 0))
                nettamt = float(record.get("NETTAMT", 0))
                
                total_amt += tranamt
                total_fee += trxnfee
                total_net += nettamt
                
                line = f"{ftransid}{fselordn}{tranamt:13.2f}{trxnfee:13.2f}{nettamt:13.2f}\n"
                f.write(line)
            
            f.write("-" * 100 + "\n")
            f.write(f"TOTALS:{' '*57}{total_amt:13.2f}{total_fee:13.2f}{total_net:13.2f}\n")
        
        logger.info(f"Report generated successfully")
    except Exception as e:
        logger.error(f"Error writing report: {str(e)}")
        raise

if __name__ == "__main__":
    main()
