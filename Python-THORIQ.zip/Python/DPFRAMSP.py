# DPFRAMSP.py
# /* ACCUMULATE ALL TRANSACTIONS INTO A CUMULATIVE SUMMARY FILE FOR RAM */
# /* VIA COLD SORTED BY NAME OF PAYEE CORPORATION */

import polars as pl
from datetime import datetime, timedelta
import common.fixed_width_reader as fixed_width_reader
from common.batch_date import get_batch_date
import os
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Obtain date for file paths
date_info = get_batch_date()
file_date = date_info["file_date"]
folder_day = date_info["folder_day"]
folder_month = date_info["folder_month"]
folder_year = date_info["folder_year"]

# Define file paths
INPUTF1 = f"/host/dp/input/ram/INPUTF1_{folder_year}{folder_month}{folder_day}.dat"
INPUTF2 = f"/host/dp/input/ram/INPUTF2_{folder_year}{folder_month}{folder_day}.dat"
CONTROL2 = f"/host/dp/input/ram/CONTROL2_{folder_year}{folder_month}{folder_day}.dat"
OUTPUT1 = f"/host/dp/output/DPFRAMSP_CUMSUM_{folder_year}{folder_month}{folder_day}.dat"

def main():
    """SAS DPFRAMSP program - RAM Cumulative Summary File"""
    
    try:
        logger.info("Starting DPFRAMSP - RAM CUMULATIVE SUMMARY FILE GENERATION")
        
        # Step 1: Read current day transactions
        logger.info(f"Reading current transactions from {INPUTF1}")
        AAA = read_input_file(INPUTF1)
        
        # Step 2: Read control date
        logger.info(f"Reading control date from {CONTROL2}")
        control_date = read_control_date()
        
        # Step 3: Read previous cumulative file
        logger.info(f"Reading previous summary from {INPUTF2}")
        PREVFILE = read_input_file(INPUTF2)
        
        # Step 4: Process cumulative summary
        logger.info("Processing cumulative summary")
        output_records = process_cumulative(control_date, AAA, PREVFILE)
        
        # Step 5: Write output file
        logger.info(f"Writing cumulative summary to {OUTPUT1}")
        write_output(output_records, OUTPUT1)
        
        logger.info("DPFRAMSP processing completed successfully.")
        
    except Exception as e:
        logger.error(f"Error in DPFRAMSP processing: {str(e)}")
        raise

def read_input_file(file_path):
    """Read transaction file"""
    
    if not os.path.exists(file_path):
        logger.warning(f"File not found: {file_path}")
        return pl.DataFrame()
    
    records = []
    try:
        with open(file_path, 'r') as f:
            for line in f:
                if len(line) < 205:
                    continue
                
                try:
                    record = {
                        "PROCDT": line[0:6].strip() if len(line) > 5 else "",
                        "FTRANSID": line[6:22].strip() if len(line) > 21 else "",
                        "FSELORDN": line[22:62].strip() if len(line) > 61 else "",
                        "TRANAMT": float(line[62:75].strip() if len(line) > 74 else "0"),
                        "TRXNFEE": float(line[75:88].strip() if len(line) > 87 else "0"),
                        "NETTAMT": float(line[88:101].strip() if len(line) > 100 else "0"),
                        "RECNO": line[101:107].strip() if len(line) > 106 else "",
                        "TRANCDE": line[107:110].strip() if len(line) > 109 else "",
                        "FSELERID": line[110:120].strip() if len(line) > 119 else "",
                        "FSELACNO": line[120:140].strip() if len(line) > 139 else "",
                        "FBUYBKID": line[140:155].strip() if len(line) > 154 else "",
                        "FSELERDE": line[155:185].strip() if len(line) > 184 else "",
                        "FBUYACNO": line[185:205].strip() if len(line) > 204 else ""
                    }
                    records.append(record)
                except:
                    continue
        
        if records:
            df = pl.DataFrame(records)
            logger.info(f"Read {len(df)} transaction records from {os.path.basename(file_path)}")
            return df
        return pl.DataFrame()
    except Exception as e:
        logger.error(f"Error reading {file_path}: {str(e)}")
        return pl.DataFrame()

def read_control_date():
    """Read processing date from control file"""
    
    control_date = {
        "RPTDAYDD": "01",
        "RPTDAYMM": "01",
        "RPTDAYYY": "00",
        "RPTDAYCC": "01"
    }
    
    try:
        if os.path.exists(CONTROL2):
            with open(CONTROL2, 'r') as f:
                line = f.readline().strip()
                if len(line) >= 8:
                    yy = line[0:2]
                    mm = line[2:4]
                    dd = line[4:6]
                    cc = line[6:8]
                    
                    control_date = {
                        "RPTDAYDD": dd,
                        "RPTDAYMM": mm,
                        "RPTDAYYY": yy,
                        "RPTDAYCC": cc
                    }
    except Exception as e:
        logger.warning(f"Error reading control date: {str(e)}")
    
    return control_date

def process_cumulative(control_date, aaa, prevfile):
    """Process cumulative summary"""
    
    output_records = []
    
    rptdaydd = control_date.get("RPTDAYDD", "01")
    
    if rptdaydd == "01":
        # First day of month: output only current day's transactions (reset cycle)
        logger.info("Report date is 01st - outputting current day transactions only")
        if len(aaa) > 0:
            for row in aaa.iter_rows(named=True):
                output_records.append(row)
    else:
        # Other days: merge previous with current
        logger.info("Report date is not 01st - outputting cumulative")
        
        if len(prevfile) > 0:
            for row in prevfile.iter_rows(named=True):
                output_records.append(row)
        
        if len(aaa) > 0:
            for row in aaa.iter_rows(named=True):
                output_records.append(row)
        
        # Sort by PROCDT and FTRANSID
        if output_records:
            df = pl.DataFrame(output_records)
            df = df.sort([pl.col("PROCDT"), pl.col("FTRANSID")])
            output_records = [row for row in df.iter_rows(named=True)]
    
    logger.info(f"Processing output: {len(output_records)} records")
    
    return output_records

def write_output(records, output_file):
    """Write output file in fixed format"""
    
    logger.info(f"Writing {len(records)} records to cumulative summary file")
    
    if len(records) == 0:
        logger.warning("No records to write")
        return
    
    try:
        with open(output_file, 'w') as f:
            for record in records:
                procdt = str(record.get("PROCDT", "")).ljust(6)
                ftransid = str(record.get("FTRANSID", "")).ljust(16)
                fselordn = str(record.get("FSELORDN", "")).ljust(40)
                tranamt = float(record.get("TRANAMT", 0))
                trxnfee = float(record.get("TRXNFEE", 0))
                nettamt = float(record.get("NETTAMT", 0))
                recno = str(record.get("RECNO", "")).ljust(6)
                trancde = str(record.get("TRANCDE", "")).ljust(3)
                fselerid = str(record.get("FSELERID", "")).ljust(10)
                fselacno = str(record.get("FSELACNO", "")).ljust(20)
                fbuybkid = str(record.get("FBUYBKID", "")).ljust(15)
                fselerde = str(record.get("FSELERDE", "")).ljust(30)
                fbuyacno = str(record.get("FBUYACNO", "")).ljust(20)
                
                line = (
                    f"{procdt}"
                    f"{ftransid}"
                    f"{fselordn}"
                    f"{tranamt:13.0f}"
                    f"{trxnfee:13.0f}"
                    f"{nettamt:13.0f}"
                    f"{recno}"
                    f"{trancde}"
                    f"{fselerid}"
                    f"{fselacno}"
                    f"{fbuybkid}"
                    f"{fselerde}"
                    f"{fbuyacno}"
                )
                
                f.write(line + "\n")
        
        logger.info(f"Cumulative summary file written successfully")
    
    except Exception as e:
        logger.error(f"Error writing output file: {str(e)}")
        raise

if __name__ == "__main__":
    main()
