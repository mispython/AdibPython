# DPFRAMSU.py
# /* GENERATE SUMMARY REPORTING FILE FOR RAM CREDIT */
# /* SIMILAR TO DPFQKHSU - SUMMARY FILE FOR REPORTING */

import polars as pl
from datetime import datetime, timedelta
import common.fixed_width_reader as fixed_width_reader
from common.batch_date import get_batch_date
import os
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Obtain date for file paths
date_info = get_batch_date()
file_date = date_info["file_date"]
folder_day = date_info["folder_day"]
folder_month = date_info["folder_month"]
folder_year = date_info["folder_year"]

# Define file paths
INPUTF1 = f"/host/dp/input/ram/INPUTF1_{folder_year}{folder_month}{folder_day}.dat"
INPUTF2 = f"/host/dp/input/ram/INPUTF2_{folder_year}{folder_month}{folder_day}.dat"
CONTROL1 = f"/host/dp/input/ram/CONTROL1_{folder_year}{folder_month}{folder_day}.dat"
CONTROL2 = f"/host/dp/input/ram/CONTROL2_{folder_year}{folder_month}{folder_day}.dat"
OUTPUT1 = f"/host/dp/output/DPFRAMSU_OUTPUT_{folder_year}{folder_month}{folder_day}.dat"
EXCPO = f"/host/dp/output/DPFRAMSU_EXCEPTIONS_{folder_year}{folder_month}{folder_day}.txt"

def main():
    """SAS DPFRAMSU program - RAM Summary File Generation"""
    
    try:
        logger.info("Starting DPFRAMSU - RAM SUMMARY FILE GENERATION")
        
        # Step 1: Read transaction file
        logger.info(f"Reading transaction file from {INPUTF1}")
        AAA = read_inputf1()
        
        if len(AAA) == 0:
            logger.warning("No transactions found")
            return
        
        # Step 2: Read extended file
        BBB = read_inputf2()
        
        # Step 3: Read control files
        racctno = read_control1()
        
        # Step 4: Process and merge data
        logger.info("Processing transaction data")
        OUTFF, EXCPO_data = process_transactions(AAA, BBB)
        
        # Step 5: Generate output
        logger.info(f"Writing output to {OUTPUT1}")
        write_output(OUTFF, OUTPUT1)
        
        if len(EXCPO_data) > 0:
            logger.info(f"Writing exceptions to {EXCPO}")
            write_exceptions(EXCPO_data, EXCPO)
        
        logger.info("DPFRAMSU processing completed successfully.")
        
    except Exception as e:
        logger.error(f"Error in DPFRAMSU processing: {str(e)}")
        raise

def read_inputf1():
    """Read transaction file and filter"""
    logger.info(f"Reading INPUTF1 from {INPUTF1}")
    
    if not os.path.exists(INPUTF1):
        logger.warning(f"File not found: {INPUTF1}")
        return pl.DataFrame()
    
    records = []
    try:
        with open(INPUTF1, 'r') as f:
            for line in f:
                if len(line) < 100:
                    continue
                
                try:
                    # Skip based on transaction codes
                    ttrancode = line[107:110].strip() if len(line) > 109 else "000"
                    srcecde = line[53:56].strip() if len(line) > 55 else ""
                    
                    if ttrancode == "874":
                        continue
                    if srcecde != "313":
                        continue
                    
                    record = {
                        "ACCTNO": line[8:18].strip() if len(line) > 17 else "",
                        "PROCDT": line[19:27].strip() if len(line) > 26 else "",
                        "DATATYP": line[27:28].strip() if len(line) > 27 else "",
                        "TRANCDE": line[50:53].strip() if len(line) > 52 else "",
                        "SRCECDE": srcecde,
                        "TRANAMT": int(line[72:85].strip() if len(line) > 84 else 0),
                        "EBKCHQ": line[88:94].strip() if len(line) > 93 else "",
                        "RECNO": line[90:96].strip() if len(line) > 95 else ""
                    }
                    records.append(record)
                except:
                    continue
        
        if records:
            AAA = pl.DataFrame(records)
            logger.info(f"AAA created with {len(AAA)} records")
            return AAA
        return pl.DataFrame()
    except Exception as e:
        logger.error(f"Error reading INPUTF1: {str(e)}")
        return pl.DataFrame()

def read_inputf2():
    """Read extended transaction file"""
    logger.info(f"Reading INPUTF2 from {INPUTF2}")
    
    if not os.path.exists(INPUTF2):
        logger.warning(f"File not found: {INPUTF2}")
        return pl.DataFrame()
    
    records = []
    try:
        with open(INPUTF2, 'r') as f:
            for line in f:
                if len(line) < 100:
                    continue
                
                try:
                    fselerid = line[191:201].strip() if len(line) > 200 else ""
                    # SE00031978 is RAM seller ID
                    if fselerid != "SE00031978":
                        continue
                    
                    record = {
                        "FTRANSID": line[0:16].strip() if len(line) > 15 else "",
                        "FSELERID": fselerid,
                        "FSELORDN": line[151:191].strip() if len(line) > 190 else ""
                    }
                    records.append(record)
                except:
                    continue
        
        if records:
            BBB = pl.DataFrame(records)
            logger.info(f"BBB created with {len(BBB)} records")
            return BBB
        return pl.DataFrame()
    except Exception as e:
        logger.error(f"Error reading INPUTF2: {str(e)}")
        return pl.DataFrame()

def read_control1():
    """Read control account number"""
    racctno = ""
    try:
        if os.path.exists(CONTROL1):
            with open(CONTROL1, 'r') as f:
                line = f.readline()
                if len(line) >= 10:
                    racctno = line[0:10].strip()
    except:
        pass
    return racctno

def process_transactions(AAA, BBB):
    """Process and merge transaction data"""
    
    OUTFF = AAA
    if len(BBB) > 0:
        # Try to merge on transaction ID
        OUTFF = AAA.join(BBB, left_on="TRANID", right_on="FTRANSID", how="inner")
    
    EXCPO_data = AAA.anti_join(BBB, on="TRANID") if len(BBB) > 0 else AAA
    
    return OUTFF, EXCPO_data

def write_output(OUTFF, output_file):
    """Write output file"""
    logger.info(f"Writing output with {len(OUTFF)} records")
    
    if len(OUTFF) == 0:
        return
    
    with open(output_file, 'w') as f:
        for row in OUTFF.iter_rows(named=True):
            wsdd = str(row.get("PROCDT", ""))[-2:]
            wsmm = str(row.get("PROCDT", ""))[4:6]
            wsyy = str(row.get("PROCDT", ""))[2:4]
            tranamt = int(row.get("TRANAMT", 0)) / 100
            
            line = f"{wsdd}{wsmm}{wsyy}{str(row.get('FTRANSID', '')).ljust(16)}{str(row.get('FSELORDN', '')).ljust(40)}{tranamt:13.2f}"
            f.write(line + "\n")

def write_exceptions(EXCPO_data, exc_file):
    """Write exception records"""
    logger.info(f"Writing {len(EXCPO_data)} exception records")
    
    with open(exc_file, 'w') as f:
        f.write("========== DAILY EXCEPTION REPORT (RAM) ==========\n\n")
        
        totamt = 0.0
        totcnt = 0
        
        for idx, row in enumerate(EXCPO_data.iter_rows(named=True)):
            totcnt += 1
            tranamt = int(row.get("TRANAMT", 0)) / 100
            totamt += tranamt
            
            wsdd = str(row.get("PROCDT", ""))[-2:]
            wsmm = str(row.get("PROCDT", ""))[4:6]
            wsyy = str(row.get("PROCDT", ""))[2:4]
            
            f.write(f"{totcnt:7d} {wsdd}/{wsmm}/{wsyy} {str(row.get('RECNO', '')).ljust(6)} {tranamt:13.2f}\n")
        
        f.write("\n")
        f.write(f"TOTAL EXCEPTION AMOUNT  : {totamt:13.2f}\n")
        f.write(f"TOTAL EXCEPTION COUNT   : {totcnt:7d}\n")

if __name__ == "__main__":
    main()
