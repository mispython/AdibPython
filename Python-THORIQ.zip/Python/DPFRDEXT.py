# DPFRDEXT.py
# /* EXTRACT INFO FROM TRANSACTION HISTORY FOR FRAUD DETECTION */
# /* 2-MONTH (60-DAY) ANALYSIS WINDOW */
# /* DP8017 - INCLUDE 5-SERIES SAVINGS ACCOUNTS */

import polars as pl
from datetime import datetime, timedelta
import common.fixed_width_reader as fixed_width_reader
from common.batch_date import get_batch_date
import os
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Obtain date for file paths
date_info = get_batch_date()
file_date = date_info["file_date"]
folder_day = date_info["folder_day"]
folder_month = date_info["folder_month"]
folder_year = date_info["folder_year"]

# Define file paths
SRSCTRL1 = f"/host/dp/input/fraud/SRSCTRL1_{folder_year}{folder_month}{folder_day}.dat"
CTRLAMT = f"/host/dp/input/fraud/CTRLAMT_{folder_year}{folder_month}{folder_day}.dat"
DPTRCV = f"/host/dp/input/fraud/DPTRCV_{folder_year}{folder_month}{folder_day}.dat"
DPTRBALS = f"/host/dp/input/fraud/DPTRBALS_{folder_year}{folder_month}{folder_day}.dat"
PBBFILE = f"/host/dp/input/fraud/PBBFILE_{folder_year}{folder_month}{folder_day}.dat"
PURGDAY_FILE = f"/host/dp/input/fraud/PURGDAY_{folder_year}{folder_month}{folder_day}.dat"
FRAUDDB = f"/host/dp/input/fraud/FRAUDDB_{folder_year}{folder_month}{folder_day}.dat"

FRDDBFD = f"/host/dp/output/DPFRDEXT_FRDDBFD_{folder_year}{folder_month}{folder_day}.txt"
FRDDBSA = f"/host/dp/output/DPFRDEXT_FRDDBSA_{folder_year}{folder_month}{folder_day}.txt"

def main():
    """DPFRDEXT - Extract fraud transaction info from history"""
    
    try:
        logger.info("Starting DPFRDEXT - FRAUD EXTRACTION FROM TRANSACTION HISTORY")
        
        # Step 1: Read control parameters
        date_params = read_date_control()
        amount_params = read_amount_control()
        purge_days = read_purge_days()
        
        logger.info(f"Date params: {date_params}, Amount params: {amount_params}, Purge days: {purge_days}")
        
        # Step 2: Extract transactions from history
        logger.info("Extracting transactions from history")
        AAA = extract_fd_transactions(amount_params)  # Fixed Deposit
        BBB = extract_sa_error_corrections(amount_params)  # Savings error corrections
        
        # Step 3: Read account master
        logger.info("Reading account master")
        DDD = read_account_master()
        
        # Step 4: Merge and filter
        logger.info("Processing and merging data")
        CCC = merge_aa_bb(AAA, BBB)
        EEE, STAFF, FAIL = merge_and_filter_accounts(CCC, DDD)
        
        # Step 5: Read teller branch info
        PBBBRH = read_pbb_branch()
        FFF = merge_teller_info(EEE, PBBBRH)
        
        # Step 6: Read fraud database
        GGG = read_fraud_database()
        
        # Step 7: Combine today's transactions with 60-day history
        HHH, PURGE = combine_and_purge_history(FFF, GGG, purge_days, date_params)
        
        # Step 8: Output by account series
        logger.info("Writing fraud databases by account type")
        write_fraud_output(HHH)
        
        logger.info("DPFRDEXT processing completed successfully.")
        
    except Exception as e:
        logger.error(f"Error in DPFRDEXT processing: {str(e)}")
        raise

def read_date_control():
    """Read control date file"""
    params = {"YYYY": "2020", "CC": "20", "YY": "20", "MM": "01", "DD": "01"}
    try:
        if os.path.exists(SRSCTRL1):
            with open(SRSCTRL1, 'r') as f:
                line = f.readline().strip()
                if len(line) >= 8:
                    params = {
                        "YYYY": line[0:4],
                        "CC": line[0:2],
                        "YY": line[2:4],
                        "MM": line[4:6],
                        "DD": line[6:8]
                    }
    except Exception as e:
        logger.error(f"Error reading date control: {str(e)}")
    return params

def read_amount_control():
    """Read amount thresholds"""
    params = {"FDAMNT": 1000.0, "SAAMNT": 100.0}
    try:
        if os.path.exists(CTRLAMT):
            with open(CTRLAMT, 'r') as f:
                line = f.readline().strip()
                if len(line) >= 13:
                    params = {
                        "FDAMNT": float(line[2:8].strip() if len(line) > 7 else "1000"),
                        "SAAMNT": float(line[10:16].strip() if len(line) > 15 else "100")
                    }
    except Exception as e:
        logger.error(f"Error reading amount control: {str(e)}")
    return params

def read_purge_days():
    """Read purge day threshold (usually 60 days)"""
    try:
        if os.path.exists(PURGDAY_FILE):
            with open(PURGDAY_FILE, 'r') as f:
                line = f.readline().strip()
                if len(line) >= 2:
                    return int(line[0:2])
    except Exception as e:
        logger.error(f"Error reading purge days: {str(e)}")
    return 60

def extract_fd_transactions(amount_params):
    """Extract Fixed Deposit transactions"""
    records = []
    try:
        if not os.path.exists(DPTRCV):
            return pl.DataFrame()
        
        with open(DPTRCV, 'r') as f:
            for line in f:
                if len(line) < 75:
                    continue
                
                try:
                    bankno = int(line[1:3])
                    acctno = int(line[3:9])
                    sourcecd = int(line[19:21])
                    trc = int(line[17:19])
                    amount = float(line[29:36].strip() if len(line) > 35 else "0") / 100
                    
                    # SOURCECD 526 AND TRC IN (970,971,972,773)
                    if sourcecd != 526 or trc not in [970, 971, 972, 773]:
                        continue
                    
                    # Account series: 1000000000-1999999999 (FD) OR 7000000000-7999999999
                    if not ((1000000000 <= acctno <= 1999999999) or (7000000000 <= acctno <= 7999999999)):
                        continue
                    
                    # Amount >= threshold
                    if amount < amount_params["FDAMNT"]:
                        continue
                    
                    userid = line[9:17].strip() if len(line) > 16 else ""
                    trxmmdd = line[21:29].strip() if len(line) > 28 else ""
                    trailer = line[43:75].strip() if len(line) > 74 else ""
                    telbrh = int(line[72:75].strip() if len(line) > 74 else "0")
                    
                    record = {
                        "BANKNO": bankno,
                        "ACCTNO": acctno,
                        "USERID": userid,
                        "TRC": trc,
                        "SOURCECD": sourcecd,
                        "TRXMMDD": trxmmdd,
                        "AMOUNT": amount,
                        "TRAILER": trailer,
                        "TELBRH": telbrh,
                        "ACCT_TYPE": "FD"
                    }
                    records.append(record)
                except:
                    continue
        
        if records:
            df = pl.DataFrame(records)
            logger.info(f"Extracted {len(df)} FD transactions")
            return df
        return pl.DataFrame()
    except Exception as e:
        logger.error(f"Error extracting FD transactions: {str(e)}")
        return pl.DataFrame()

def extract_sa_error_corrections(amount_params):
    """Extract Savings Account error corrections"""
    records = []
    try:
        if not os.path.exists(DPTRCV):
            return pl.DataFrame()
        
        with open(DPTRCV, 'r') as f:
            for line in f:
                if len(line) < 75:
                    continue
                
                try:
                    bankno = int(line[1:3])
                    acctno = int(line[3:9])
                    sourcecd = int(line[19:21])
                    trc = int(line[17:19])
                    amount = float(line[29:36].strip() if len(line) > 35 else "0") / 100
                    
                    # SOURCECD IN (513,503) AND TRC IN (622,956,755)
                    if sourcecd not in [513, 503] or trc not in [622, 956, 755]:
                        continue
                    
                    # Account series: 4000000000-6999999999 (SA only)
                    if not (4000000000 <= acctno <= 6999999999):
                        continue
                    
                    # Amount >= threshold
                    if amount < amount_params["SAAMNT"]:
                        continue
                    
                    userid = line[9:17].strip() if len(line) > 16 else ""
                    trxmmdd = line[21:29].strip() if len(line) > 28 else ""
                    trailer = line[43:75].strip() if len(line) > 74 else ""
                    telbrh = int(line[72:75].strip() if len(line) > 74 else "0")
                    
                    record = {
                        "BANKNO": bankno,
                        "ACCTNO": acctno,
                        "USERID": userid,
                        "TRC": trc,
                        "SOURCECD": sourcecd,
                        "TRXMMDD": trxmmdd,
                        "AMOUNT": amount,
                        "TRAILER": trailer,
                        "TELBRH": telbrh,
                        "ACCT_TYPE": "SA"
                    }
                    records.append(record)
                except:
                    continue
        
        if records:
            df = pl.DataFrame(records)
            logger.info(f"Extracted {len(df)} SA error corrections")
            return df
        return pl.DataFrame()
    except Exception as e:
        logger.error(f"Error extracting SA corrections: {str(e)}")
        return pl.DataFrame()

def read_account_master():
    """Read account master file"""
    records = []
    try:
        if not os.path.exists(DPTRBALS):
            return pl.DataFrame()
        
        with open(DPTRBALS, 'r') as f:
            for line in f:
                if len(line) < 300:
                    continue
                
                try:
                    reptno = int(line[23:26])
                    fmtcode = int(line[26:28])
                    
                    if reptno != 1001 or fmtcode != 1:
                        continue
                    
                    acctno = int(line[109:115])
                    branchno = int(line[105:109])
                    acctname = line[115:130].strip() if len(line) > 129 else ""
                    purpcode = line[285:286].strip() if len(line) > 285 else ""
                    
                    record = {
                        "ACCTNO": acctno,
                        "BRANCHNO": branchno,
                        "ACCTNAME": acctname,
                        "PURPCODE": purpcode
                    }
                    records.append(record)
                except:
                    continue
        
        if records:
            df = pl.DataFrame(records)
            logger.info(f"Read {len(df)} account master records")
            return df
        return pl.DataFrame()
    except Exception as e:
        logger.error(f"Error reading account master: {str(e)}")
        return pl.DataFrame()

def merge_aa_bb(AAA, BBB):
    """Merge AAA with BBB, exclude error corrections"""
    try:
        if len(AAA) == 0:
            return pl.DataFrame()
        
        # Create set of BBB records to exclude
        bbb_set = set(BBB["TRAILER"].to_list()) if len(BBB) > 0 else set()
        
        # Filter AAA to exclude records in BBB
        CCC = AAA.filter(~AAA["TRAILER"].is_in(list(bbb_set)))
        logger.info(f"Merged AAA/BBB: {len(CCC)} records after exclusion")
        return CCC
    except Exception as e:
        logger.error(f"Error merging AAA/BBB: {str(e)}")
        return pl.DataFrame()

def merge_and_filter_accounts(CCC, DDD):
    """Merge with account master and filter out staff accounts"""
    EEE = []
    STAFF = []
    FAIL = []
    
    try:
        if len(CCC) == 0:
            return pl.DataFrame(), pl.DataFrame(), pl.DataFrame()
        
        ddd_dict = {row["ACCTNO"]: row for row in DDD.iter_rows(named=True)} if len(DDD) > 0 else {}
        
        for row in CCC.iter_rows(named=True):
            acctno = row.get("ACCTNO")
            
            if acctno in ddd_dict:
                master = ddd_dict[acctno]
                merged = {**row, **master}
                
                # Exclude staff accounts (PURPCODE == '4')
                if master.get("PURPCODE") != "4":
                    EEE.append(merged)
                else:
                    STAFF.append(merged)
            else:
                FAIL.append(row)
        
        logger.info(f"Account filtering: EEE={len(EEE)}, STAFF={len(STAFF)}, FAIL={len(FAIL)}")
        
        return (pl.DataFrame(EEE) if EEE else pl.DataFrame(),
                pl.DataFrame(STAFF) if STAFF else pl.DataFrame(),
                pl.DataFrame(FAIL) if FAIL else pl.DataFrame())
    except Exception as e:
        logger.error(f"Error filtering accounts: {str(e)}")
        return pl.DataFrame(), pl.DataFrame(), pl.DataFrame()

def read_pbb_branch():
    """Read PBB branch teller info"""
    records = []
    try:
        if not os.path.exists(PBBFILE):
            return pl.DataFrame()
        
        with open(PBBFILE, 'r') as f:
            for line in f:
                if len(line) < 10:
                    continue
                
                try:
                    pbbbrh = int(line[1:4]) if line[1:4].strip() else 0
                    usercode = line[5:8].strip() if len(line) > 7 else ""
                    
                    record = {
                        "PBBBRH": pbbbrh,
                        "USERCODE": usercode
                    }
                    records.append(record)
                except:
                    continue
        
        if records:
            df = pl.DataFrame(records)
            logger.info(f"Read {len(df)} PBB branch records")
            return df
        return pl.DataFrame()
    except Exception as e:
        logger.error(f"Error reading PBB branch: {str(e)}")
        return pl.DataFrame()

def merge_teller_info(EEE, PBBBRH):
    """Merge with teller branch info"""
    try:
        if len(EEE) == 0 or len(PBBBRH) == 0:
            return EEE
        
        # Simple merge on usercode
        merged = []
        pbb_dict = {row["USERCODE"]: row for row in PBBBRH.iter_rows(named=True)}
        
        for row in EEE.iter_rows(named=True):
            usercode = row.get("USERID", "")[:3]
            if usercode in pbb_dict:
                row_merged = {**row, "TELBRH": pbb_dict[usercode].get("PBBBRH")}
                merged.append(row_merged)
            else:
                merged.append(row)
        
        result = pl.DataFrame(merged) if merged else EEE
        logger.info(f"Merged teller info: {len(result)} records")
        return result
    except Exception as e:
        logger.error(f"Error merging teller info: {str(e)}")
        return EEE

def read_fraud_database():
    """Read fraud database"""
    records = []
    try:
        if not os.path.exists(FRAUDDB):
            return pl.DataFrame()
        
        with open(FRAUDDB, 'r') as f:
            for line in f:
                if len(line) < 100:
                    continue
                
                try:
                    bankno = int(line[0:2])
                    acctno = int(line[2:8])
                    userid = line[8:16].strip() if len(line) > 15 else ""
                    trc = int(line[16:18])
                    sourcecd = int(line[18:20])
                    trxdate = line[20:28].strip() if len(line) > 27 else ""
                    amount = float(line[28:35].strip() if len(line) > 34 else "0") / 100
                    trailer = line[35:65].strip() if len(line) > 64 else ""
                    telbrh = int(line[62:65].strip() if len(line) > 64 else "0")
                    branchno = int(line[76:80]) if len(line) > 79 else 0
                    acctname = line[80:95].strip() if len(line) > 94 else ""
                    purpcode = line[95:96].strip() if len(line) > 95 else ""
                    
                    record = {
                        "BANKNO": bankno,
                        "ACCTNO": acctno,
                        "USERID": userid,
                        "TRC": trc,
                        "SOURCECD": sourcecd,
                        "TRXDATE": trxdate,
                        "AMOUNT": amount,
                        "TRAILER": trailer,
                        "TELBRH": telbrh,
                        "BRANCHNO": branchno,
                        "ACCTNAME": acctname,
                        "PURPCODE": purpcode
                    }
                    records.append(record)
                except:
                    continue
        
        if records:
            df = pl.DataFrame(records)
            logger.info(f"Read {len(df)} fraud database records")
            return df
        return pl.DataFrame()
    except Exception as e:
        logger.error(f"Error reading fraud database: {str(e)}")
        return pl.DataFrame()

def combine_and_purge_history(FFF, GGG, purge_days, date_params):
    """Combine today's transactions with previous 60-day history"""
    try:
        # Concatenate FFF (today) with GGG (historical)
        if len(FFF) == 0 and len(GGG) == 0:
            return pl.DataFrame(), pl.DataFrame()
        
        HHH_list = []
        PURGE_list = []
        
        # Add all records
        all_records = []
        if len(FFF) > 0:
            all_records.extend(FFF.iter_rows(named=True))
        if len(GGG) > 0:
            all_records.extend(GGG.iter_rows(named=True))
        
        # Filter by purge days
        today = datetime.now()
        for record in all_records:
            trxdate_str = record.get("TRXDATE", "")
            try:
                if len(trxdate_str) >= 8:
                    year = int(trxdate_str[0:4])
                    month = int(trxdate_str[4:6])
                    day = int(trxdate_str[6:8])
                    trx_date = datetime(year, month, day)
                    days_diff = (today - trx_date).days
                    
                    if days_diff <= purge_days:
                        HHH_list.append(record)
                    else:
                        PURGE_list.append(record)
                else:
                    HHH_list.append(record)
            except:
                HHH_list.append(record)
        
        HHH = pl.DataFrame(HHH_list) if HHH_list else pl.DataFrame()
        PURGE = pl.DataFrame(PURGE_list) if PURGE_list else pl.DataFrame()
        
        logger.info(f"Purge history: HHH={len(HHH)}, PURGE={len(PURGE)}")
        return HHH, PURGE
    except Exception as e:
        logger.error(f"Error combining and purging: {str(e)}")
        return pl.DataFrame(), pl.DataFrame()

def write_fraud_output(HHH):
    """Write fraud output by account series"""
    try:
        fd_records = []
        sa_records = []
        
        for row in HHH.iter_rows(named=True):
            acctno = row.get("ACCTNO", 0)
            
            if (1000000000 <= acctno <= 1999999999) or (7000000000 <= acctno <= 7999999999):
                fd_records.append(row)
            elif 4000000000 <= acctno <= 6999999999:
                sa_records.append(row)
        
        # Write FD records
        if fd_records:
            with open(FRDDBFD, 'w') as f:
                f.write("FRAUD DATABASE - FIXED DEPOSIT ACCOUNTS\n\n")
                for record in fd_records:
                    f.write(f"{record}\n")
            logger.info(f"Written {len(fd_records)} FD fraud records")
        
        # Write SA records
        if sa_records:
            with open(FRDDBSA, 'w') as f:
                f.write("FRAUD DATABASE - SAVINGS ACCOUNTS\n\n")
                for record in sa_records:
                    f.write(f"{record}\n")
            logger.info(f"Written {len(sa_records)} SA fraud records")
        
    except Exception as e:
        logger.error(f"Error writing fraud output: {str(e)}")
        raise

if __name__ == "__main__":
    main()
