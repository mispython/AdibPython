# DPFRDRPT.py
# /* FRAUD DETECTION - CONFIRMED FRAUD TRANSACTIONS */
# /* DETECT AND REPORT CONFIRMED FRAUD FROM DATABASE */

import polars as pl
from datetime import datetime, timedelta
import common.fixed_width_reader as fixed_width_reader
from common.batch_date import get_batch_date
import os
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Obtain date for file paths
date_info = get_batch_date()
file_date = date_info["file_date"]
folder_day = date_info["folder_day"]
folder_month = date_info["folder_month"]
folder_year = date_info["folder_year"]

# Define file paths
SRSCTRL1 = f"/host/dp/input/fraud/SRSCTRL1_{folder_year}{folder_month}{folder_day}.dat"
CTRLAMT = f"/host/dp/input/fraud/CTRLAMT_{folder_year}{folder_month}{folder_day}.dat"
FRAUDDB = f"/host/dp/input/fraud/FRAUDDB_{folder_year}{folder_month}{folder_day}.dat"
PBBBRH = f"/host/dp/input/fraud/PBBBRH_{folder_year}{folder_month}{folder_day}.dat"

FRDRPT = f"/host/dp/output/DPFRDRPT_REPORT_{folder_year}{folder_month}{folder_day}.txt"

def main():
    """DPFRDRPT - Confirmed fraud detection report"""
    
    try:
        logger.info("Starting DPFRDRPT - CONFIRMED FRAUD DETECTION")
        
        # Step 1: Read control parameters
        compdate = read_control_date()
        thresholds = read_amount_thresholds()
        
        logger.info(f"Control date: {compdate}, Thresholds: {thresholds}")
        
        # Step 2: Read fraud database and filter
        logger.info("Reading fraud database")
        ACCT_LIM, ACCTXLIM = read_and_filter_fraud_db(compdate, thresholds)
        
        logger.info(f"ACCT_LIM: {len(ACCT_LIM)} records, ACCTXLIM: {len(ACCTXLIM)} records")
        
        # Step 3: Identify accounts with multiple transactions from same teller
        logger.info("Identifying repeated teller activity")
        CNT_ACCT = count_transactions_by_sortkey(ACCT_LIM)
        
        # Step 4: Match with all transactions
        logger.info("Matching transactions")
        CNT_ACC2 = match_transactions(CNT_ACCT, ACCTXLIM)
        
        # Step 5: Read branch info
        logger.info("Reading branch information")
        PBB_BRCH = read_branch_info()
        
        # Step 6: Merge and generate report
        logger.info("Merging branch info and generating report")
        REPORT_1 = merge_branch_info(PBB_BRCH, CNT_ACC2)
        
        # Step 7: Write output
        logger.info(f"Writing report to {FRDRPT}")
        write_report(REPORT_1, compdate)
        
        logger.info("DPFRDRPT processing completed successfully.")
        
    except Exception as e:
        logger.error(f"Error in DPFRDRPT processing: {str(e)}")
        raise

def read_control_date():
    """Read control date"""
    try:
        if os.path.exists(SRSCTRL1):
            with open(SRSCTRL1, 'r') as f:
                line = f.readline().strip()
                if len(line) >= 8:
                    return line[0:8]
    except Exception as e:
        logger.error(f"Error reading control date: {str(e)}")
    return datetime.now().strftime("%Y%m%d")

def read_amount_thresholds():
    """Read amount thresholds"""
    thresholds = {"FDAMNT": 1000.0, "SAAMNT": 100.0}
    try:
        if os.path.exists(CTRLAMT):
            with open(CTRLAMT, 'r') as f:
                line = f.readline().strip()
                if len(line) >= 13:
                    thresholds = {
                        "FDAMNT": float(line[2:8].strip() if len(line) > 7 else "1000"),
                        "SAAMNT": float(line[10:16].strip() if len(line) > 15 else "100")
                    }
    except Exception as e:
        logger.error(f"Error reading thresholds: {str(e)}")
    return thresholds

def read_and_filter_fraud_db(compdate, thresholds):
    """Read fraud database and filter by thresholds and date"""
    
    ACCT_LIM = []
    ACCTXLIM = []
    
    try:
        if not os.path.exists(FRAUDDB):
            return pl.DataFrame(), pl.DataFrame()
        
        with open(FRAUDDB, 'r') as f:
            for line in f:
                if len(line) < 100:
                    continue
                
                try:
                    bankno = int(line[0:2])
                    acctno = int(line[2:8])
                    userid = line[8:16].strip() if len(line) > 15 else ""
                    trc = int(line[16:18])
                    sourcecd = int(line[18:20])
                    trxdate = line[20:28].strip() if len(line) > 27 else ""
                    amount = float(line[28:35].strip() if len(line) > 34 else "0") / 100
                    trailer = line[35:75].strip() if len(line) > 74 else ""
                    telbrh = int(line[62:65].strip() if len(line) > 64 else "0")
                    branchno = int(line[76:80]) if len(line) > 79 else 0
                    acctname = line[80:95].strip() if len(line) > 94 else ""
                    purpcode = line[95:96].strip() if len(line) > 95 else ""
                    
                    # Create SORTKEY = ACCTNO || USERID
                    sortkey = str(acctno).ljust(11) + str(userid).ljust(8)
                    
                    record = {
                        "BANKNO": bankno,
                        "ACCTNO": acctno,
                        "USERID": userid,
                        "TRC": trc,
                        "SOURCECD": sourcecd,
                        "TRXDATE": trxdate,
                        "AMOUNT": amount,
                        "TRAILER": trailer,
                        "TELBRH": telbrh,
                        "BRANCHNO": branchno,
                        "ACCTNAME": acctname,
                        "PURPCODE": purpcode,
                        "SORTKEY": sortkey
                    }
                    
                    # Output to ACCTXLIM (all records)
                    ACCTXLIM.append(record)
                    
                    # Output to ACCT_LIM if matches criteria (same as DPFRDRPS)
                    # SA: Account 4000000000-6999999999, amount >= SAAMNT, date = today
                    if (4000000000 <= acctno <= 6999999999 and 
                        amount >= thresholds["SAAMNT"] and 
                        trxdate == compdate):
                        ACCT_LIM.append(record)
                    
                    # FD: Account 1000000000-1999999999 or 7000000000-7999999999, amount >= FDAMNT, date = today
                    elif ((1000000000 <= acctno <= 1999999999 or 7000000000 <= acctno <= 7999999999) and
                          amount >= thresholds["FDAMNT"] and 
                          trxdate == compdate):
                        ACCT_LIM.append(record)
                    
                except Exception as e:
                    logger.debug(f"Error parsing record: {str(e)}")
                    continue
        
        logger.info(f"Filtered: ACCT_LIM={len(ACCT_LIM)}, ACCTXLIM={len(ACCTXLIM)}")
        
        return (pl.DataFrame(ACCT_LIM) if ACCT_LIM else pl.DataFrame(),
                pl.DataFrame(ACCTXLIM) if ACCTXLIM else pl.DataFrame())
    
    except Exception as e:
        logger.error(f"Error reading fraud database: {str(e)}")
        return pl.DataFrame(), pl.DataFrame()

def count_transactions_by_sortkey(ACCT_LIM):
    """Count transactions by SORTKEY, output only those with count > 1"""
    
    try:
        if len(ACCT_LIM) == 0:
            return pl.DataFrame()
        
        # Group by SORTKEY and count
        counts = {}
        for row in ACCT_LIM.iter_rows(named=True):
            sortkey = row["SORTKEY"]
            counts[sortkey] = counts.get(sortkey, 0) + 1
        
        # Output only those with count > 1
        result = []
        for row in ACCT_LIM.iter_rows(named=True):
            sortkey = row["SORTKEY"]
            if counts[sortkey] > 1:
                result.append({"SORTKEY": sortkey, "CNT": counts[sortkey]})
        
        # Remove duplicates
        seen = set()
        unique_result = []
        for r in result:
            if r["SORTKEY"] not in seen:
                unique_result.append(r)
                seen.add(r["SORTKEY"])
        
        df = pl.DataFrame(unique_result) if unique_result else pl.DataFrame()
        logger.info(f"Found {len(df)} SOTRKEYs with multiple transactions")
        return df
    
    except Exception as e:
        logger.error(f"Error counting transactions: {str(e)}")
        return pl.DataFrame()

def match_transactions(CNT_ACCT, ACCTXLIM):
    """Merge CNT_ACCT with ACCTXLIM to get all matched transactions"""
    
    try:
        if len(CNT_ACCT) == 0 or len(ACCTXLIM) == 0:
            return pl.DataFrame()
        
        # Create set of matching SOTRKEYs
        matching_keys = set(CNT_ACCT["SORTKEY"].to_list())
        
        # Filter ACCTXLIM to only include matching keys
        result = []
        for row in ACCTXLIM.iter_rows(named=True):
            if row["SORTKEY"] in matching_keys:
                result.append(row)
        
        df = pl.DataFrame(result) if result else pl.DataFrame()
        logger.info(f"Matched {len(df)} confirmed fraud transactions")
        return df
    
    except Exception as e:
        logger.error(f"Error matching transactions: {str(e)}")
        return pl.DataFrame()

def read_branch_info():
    """Read PBB branch information"""
    
    records = []
    try:
        if not os.path.exists(PBBBRH):
            return pl.DataFrame()
        
        with open(PBBBRH, 'r') as f:
            for line in f:
                if len(line) < 15:
                    continue
                
                try:
                    branchno = int(line[1:4]) if line[1:4].strip() else 0
                    brhname = line[11:36].strip() if len(line) > 35 else ""
                    
                    record = {
                        "BRANCHNO": branchno,
                        "BRHNAME": brhname
                    }
                    records.append(record)
                except:
                    continue
        
        if records:
            df = pl.DataFrame(records)
            logger.info(f"Read {len(df)} branch records")
            return df
        return pl.DataFrame()
    
    except Exception as e:
        logger.error(f"Error reading branch info: {str(e)}")
        return pl.DataFrame()

def merge_branch_info(PBB_BRCH, CNT_ACC2):
    """Merge branch info with matched transactions"""
    
    try:
        if len(PBB_BRCH) == 0 or len(CNT_ACC2) == 0:
            return CNT_ACC2
        
        # Create branch lookup
        branch_map = {}
        for row in PBB_BRCH.iter_rows(named=True):
            branch_map[row["BRANCHNO"]] = row["BRHNAME"]
        
        # Add branch name to transactions
        result = []
        for row in CNT_ACC2.iter_rows(named=True):
            branchno = row.get("BRANCHNO", 0)
            row["BRHNAME"] = branch_map.get(branchno, "")
            result.append(row)
        
        df = pl.DataFrame(result) if result else CNT_ACC2
        logger.info(f"Merged {len(df)} records with branch info")
        return df
    
    except Exception as e:
        logger.error(f"Error merging branch info: {str(e)}")
        return CNT_ACC2

def write_report(REPORT_1, compdate):
    """Write confirmed fraud report"""
    
    try:
        # Sort by BRANCHNO, USERID, ACCTNO, TRXDATE
        if len(REPORT_1) == 0:
            with open(FRDRPT, 'w') as f:
                f.write("CONFIRMED FRAUD DETECTION REPORT\n")
                f.write("No confirmed fraud transactions detected.\n")
            return
        
        # Create output records
        records = []
        for row in REPORT_1.iter_rows(named=True):
            records.append(row)
        
        # Sort by branch, userid, account, date
        records.sort(key=lambda x: (x.get("BRANCHNO", 0), x.get("USERID", ""), 
                                    x.get("ACCTNO", 0), x.get("TRXDATE", "")))
        
        # Group by branch for pagination
        current_branch = None
        page_no = 1
        
        with open(FRDRPT, 'w') as f:
            for record in records:
                branchno = record.get("BRANCHNO", 0)
                
                # New branch - write header
                if branchno != current_branch:
                    current_branch = branchno
                    page_no = 1
                    
                    # Write page header (DPFRDRPT style - different from DPFRDRPS)
                    brhname = record.get("BRHNAME", "")
                    f.write("\f")  # Page break
                    f.write("PUBLIC BANK BERHAD\n")
                    f.write(f"REPORT NO  : BPP/001/FRDRPT\n")
                    f.write(f"CASH/MONEY TRANSFER TRANSACTION ON SAVINGS & FIXED DEPOSIT ACCOUNT\n")
                    f.write(f"PAGE NO     : {page_no:03d}\n")
                    f.write(f"PROGRAM ID : DPFRDRPT\n")
                    f.write(f"PERFORMED BY CUSTOMER OVER-THE-COUNTER FOR BRANCH\n")
                    f.write(f"{branchno:03d} - {brhname}\n")
                    f.write(f"REPORT DATE : {datetime.now().strftime('%d-%m-%Y')}\n\n")
                    
                    # Write column headers
                    f.write("TELLER        CUSTOMER'S NAME           ACCOUNT NO    BRANCH  TRANSACTION           TRX DATE       AMOUNT (RM)\n")
                    f.write("-" * 120 + "\n\n")
                
                # Write data record
                userid = str(record.get("USERID", "")).ljust(8)
                acctname = str(record.get("ACCTNAME", "")).ljust(15)
                acctno = str(record.get("ACCTNO", "")).rjust(10)
                telbrh = str(record.get("TELBRH", "")).rjust(3).zfill(3)
                
                # Determine transaction type
                trc = record.get("TRC", 0)
                if trc == 950:
                    trxtype = "CASH WITHDRAWAL"
                elif trc == 951:
                    trxtype = "MONEY TRANSFER"
                elif trc in [970, 971, 972, 773]:
                    trxtype = "FD WITHDRAWAL"
                else:
                    trxtype = f"TRC {trc}"
                
                # Parse date
                trxdate = record.get("TRXDATE", "")
                if len(trxdate) >= 8:
                    trxdd = trxdate[6:8]
                    trxmm = trxdate[4:6]
                    trxyy = trxdate[0:4]
                else:
                    trxdd = "00"
                    trxmm = "00"
                    trxyy = "0000"
                
                amount = float(record.get("AMOUNT", 0))
                
                line = (f"{userid}{acctname}{acctno}  {telbrh}  {trxtype:<15}  "
                       f"{trxdd}/{trxmm}/{trxyy}  {amount:>13.2f}\n")
                f.write(line)
        
        logger.info("Report written successfully")
    
    except Exception as e:
        logger.error(f"Error writing report: {str(e)}")
        raise

if __name__ == "__main__":
    main()
