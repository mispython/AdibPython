# DPFRWHPP.py
# /* FPX DAILY PAYMENT FILE (OPM) FOR REGAL WORLDWIDE S/B (3997565933) */

import polars as pl
from datetime import datetime, timedelta
import common.fixed_width_reader as fixed_width_reader
from common.batch_date import get_batch_date
import os
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Obtain date for file paths
date_info = get_batch_date()
file_date = date_info["file_date"]
folder_day = date_info["folder_day"]
folder_month = date_info["folder_month"]
folder_year = date_info["folder_year"]

# Define file paths
INPUTF1 = f"/host/dp/input/rwh/INPUTF1_{folder_year}{folder_month}{folder_day}.dat"
CONTROL1 = f"/host/dp/input/rwh/CONTROL1_{folder_year}{folder_month}{folder_day}.dat"
CONTROL2 = f"/host/dp/input/rwh/CONTROL2_{folder_year}{folder_month}{folder_day}.dat"
OUTPUT1 = f"/host/dp/output/DPFRWHPP_OUTPUT_{folder_year}{folder_month}{folder_day}.dat"

select_clause_rwh = [
    ("PROCDT", 6, 0),
    ("FTRANSID", 16, 6),
    ("FSELORDN", 40, 22),
    ("TRANAMT", 13, 62),
    ("TRXNFEE", 13, 75),
    ("NETTAMT", 13, 88),
    ("RECNO", 6, 101),
    ("TRANCDE", 3, 107),
    ("FSELERID", 10, 110),
    ("FSELACNO", 20, 120),
    ("FBUYBKID", 15, 140),
    ("FSELERDE", 30, 155),
    ("FBUYACNO", 20, 185)
]

PROD_SELLER_ID = "SE00016904"

def main():
    """SAS DPFRWHPP program - Regal Worldwide Payment File Generation"""
    
    try:
        logger.info("Starting DPFRWHPP - REGAL WORLDWIDE DAILY PAYMENT FILE")
        
        # Step 1: Read transaction file
        logger.info(f"Reading transaction file from {INPUTF1}")
        AAA = read_inputf1()
        
        # Step 2: Read control files
        ractno = read_control1()
        
        # Step 3: Process records
        logger.info("Processing payment records")
        output_records = process_records(AAA, ractno)
        
        # Step 4: Write output file
        logger.info(f"Writing payment file to {OUTPUT1}")
        write_output(output_records, OUTPUT1)
        
        logger.info("DPFRWHPP processing completed successfully.")
        
    except Exception as e:
        logger.error(f"Error in DPFRWHPP processing: {str(e)}")
        raise

def read_inputf1():
    """Read and filter transaction file"""
    
    if not os.path.exists(INPUTF1):
        logger.warning(f"File not found: {INPUTF1}")
        return pl.DataFrame()
    
    records = []
    try:
        with open(INPUTF1, 'r') as f:
            for line in f:
                if len(line) < 205:
                    continue
                
                try:
                    fselerid = line[110:120].strip() if len(line) > 119 else ""
                    
                    if fselerid != PROD_SELLER_ID:
                        continue
                    
                    record = {
                        "PROCDT": line[0:6].strip() if len(line) > 5 else "",
                        "FTRANSID": line[6:22].strip() if len(line) > 21 else "",
                        "FSELORDN": line[22:62].strip() if len(line) > 61 else "",
                        "TRANAMT": int(line[62:75].strip() if len(line) > 74 else "0"),
                        "TRXNFEE": int(line[75:88].strip() if len(line) > 87 else "0"),
                        "NETTAMT": int(line[88:101].strip() if len(line) > 100 else "0"),
                        "RECNO": line[101:107].strip() if len(line) > 106 else "",
                        "TRANCDE": line[107:110].strip() if len(line) > 109 else "",
                        "FSELERID": fselerid,
                        "FSELACNO": line[120:140].strip() if len(line) > 139 else "",
                        "FBUYBKID": line[140:155].strip() if len(line) > 154 else "",
                        "FSELERDE": line[155:185].strip() if len(line) > 184 else "",
                        "FBUYACNO": line[185:205].strip() if len(line) > 204 else ""
                    }
                    records.append(record)
                except:
                    continue
        
        if records:
            df = pl.DataFrame(records)
            logger.info(f"Read {len(df)} records from {PROD_SELLER_ID}")
            return df
        return pl.DataFrame()
    except Exception as e:
        logger.error(f"Error reading INPUTF1: {str(e)}")
        return pl.DataFrame()

def read_control1():
    """Read control file for account number"""
    
    ractno = ""
    try:
        if os.path.exists(CONTROL1):
            with open(CONTROL1, 'r') as f:
                line = f.readline().strip()
                if len(line) >= 10:
                    ractno = line[:10]
                    logger.info(f"Read control account: {ractno}")
    except Exception as e:
        logger.error(f"Error reading CONTROL1: {str(e)}")
    
    return ractno

def process_records(df, account_no):
    """Process transaction records"""
    
    output_records = []
    
    # Header record
    header = {
        "RECTYPE": "0",
        "ACCTNO": account_no.ljust(10),
        "RPTDAYDD": "00",
        "RPTDAYMM": "00",
        "RPTDCCYY": "0000",
        "RECCOUNT": str(len(df)).zfill(6),
        "TOTAMOUNT": "0"
    }
    output_records.append(header)
    
    # Detail records
    total_amount = 0
    
    if len(df) > 0:
        for row in df.iter_rows(named=True):
            try:
                tranamt = int(row.get("TRANAMT", 0)) if row.get("TRANAMT") else 0
                total_amount += tranamt
                
                detail = {
                    "RECTYPE": "1",
                    "FTRANSID": str(row.get("FTRANSID", "")).ljust(16),
                    "FSELORDN": str(row.get("FSELORDN", "")).ljust(40),
                    "FBUYBKID": str(row.get("FBUYBKID", "")).ljust(4),
                    "TRANAMT": str(tranamt).zfill(13),
                    "TRXNFEE": str(int(row.get("TRXNFEE", 0)) if row.get("TRXNFEE") else 0).zfill(13),
                    "NETTAMT": str(int(row.get("NETTAMT", 0)) if row.get("NETTAMT") else tranamt).zfill(13),
                    "RECNO": str(row.get("RECNO", "")).ljust(6),
                    "TRANCDE": str(row.get("TRANCDE", "")).ljust(3),
                    "FSELERID": str(row.get("FSELERID", "")).ljust(10),
                    "FSELACNO": str(row.get("FSELACNO", "")).ljust(10),
                    "FSELERDE": str(row.get("FSELERDE", "")).ljust(10),
                    "FBUYACNO": str(row.get("FBUYACNO", "")).ljust(12)
                }
                output_records.append(detail)
            except Exception as e:
                logger.warning(f"Error processing record: {str(e)}")
                continue
    
    # Trailer record
    trailer = {
        "RECTYPE": "9",
        "RECCOUNT": str(len(df)).zfill(6),
        "TOTAMOUNT": str(total_amount).zfill(15),
        "FILLER": ""
    }
    output_records.append(trailer)
    
    return output_records

def write_output(records, output_file):
    """Write output file"""
    
    logger.info(f"Writing {len(records)} records")
    
    try:
        with open(output_file, 'w') as f:
            for record in records:
                rectype = record.get("RECTYPE", "")
                
                if rectype == "0":
                    line = f"{rectype}{record['ACCTNO']}{record['RPTDAYDD']}{record['RPTDAYMM']}{record['RPTDCCYY']}{record['RECCOUNT']}{record.get('TOTAMOUNT', '').rjust(15)}"
                
                elif rectype == "1":
                    line = f"{rectype}{record['FTRANSID']}{record['FSELORDN']}{record['FBUYBKID']}{record['TRANAMT']}{record['TRXNFEE']}{record['NETTAMT']}{record['RECNO']}{record['TRANCDE']}{record['FSELERID']}{record['FSELACNO']}{record['FSELERDE']}{record['FBUYACNO']}"
                
                elif rectype == "9":
                    line = f"{rectype}{record['RECCOUNT']}{record['TOTAMOUNT']}"
                
                else:
                    continue
                
                f.write(line + "\n")
        
        logger.info(f"Payment file written successfully")
    
    except Exception as e:
        logger.error(f"Error writing output file: {str(e)}")
        raise

if __name__ == "__main__":
    main()
