# DPFRWHR1.py
# /* FPX DAILY TRANSACTION FILE (ODR) FOR REGAL WORLDWIDE S/B (3997565933) */

import polars as pl
from datetime import datetime, timedelta
import common.fixed_width_reader as fixed_width_reader
from common.batch_date import get_batch_date
import os
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Obtain date for file paths
date_info = get_batch_date()
file_date = date_info["file_date"]
folder_day = date_info["folder_day"]
folder_month = date_info["folder_month"]
folder_year = date_info["folder_year"]

# Define file paths
INPUTF1 = f"/host/dp/input/rwh/INPUTF1_{folder_year}{folder_month}{folder_day}.dat"
CONTROL1 = f"/host/dp/input/rwh/CONTROL1_{folder_year}{folder_month}{folder_day}.dat"
CONTROL2 = f"/host/dp/input/rwh/CONTROL2_{folder_year}{folder_month}{folder_day}.dat"
CONTRP = f"/host/dp/input/rwh/CONTRP_{folder_year}{folder_month}{folder_day}.dat"
BANKBRCH = f"/host/dp/input/rwh/BANKBRCH_{folder_year}{folder_month}{folder_day}.dat"
OUTPUT1 = f"/host/dp/output/DPFRWHR1_REPORT_{folder_year}{folder_month}{folder_day}.txt"

PROD_SELLER_ID = "SE00016904"

def main():
    """SAS DPFRWHR1 program - Regal Worldwide Daily Transaction Report"""
    
    try:
        logger.info("Starting DPFRWHR1 - REGAL WORLDWIDE DAILY TRANSACTION REPORT")
        
        # Step 1: Read transaction file
        logger.info(f"Reading transaction file from {INPUTF1}")
        AAA = read_inputf1()
        
        # Step 2: Read control files
        ractno = read_control1()
        rptdate = read_control2()
        corp_info = read_report_control()
        bank_branch = read_bank_branch(corp_info.get("BRHCDE", ""))
        
        # Step 3: Process and merge data
        logger.info("Processing daily transactions")
        output_records = process_transactions(AAA)
        
        # Step 4: Write output file
        logger.info(f"Writing report to {OUTPUT1}")
        write_report(output_records, ractno, rptdate, corp_info, bank_branch)
        
        logger.info("DPFRWHR1 processing completed successfully.")
        
    except Exception as e:
        logger.error(f"Error in DPFRWHR1 processing: {str(e)}")
        raise

def read_inputf1():
    """Read and filter transaction file"""
    
    if not os.path.exists(INPUTF1):
        logger.warning(f"File not found: {INPUTF1}")
        return pl.DataFrame()
    
    records = []
    try:
        with open(INPUTF1, 'r') as f:
            for line in f:
                if len(line) < 200:
                    continue
                
                try:
                    fselerid = line[110:120].strip() if len(line) > 119 else ""
                    if fselerid != PROD_SELLER_ID:
                        continue
                    
                    record = {
                        "PROCDT": line[0:6].strip() if len(line) > 5 else "",
                        "FTRANSID": line[6:22].strip() if len(line) > 21 else "",
                        "FSELORDN": line[22:62].strip() if len(line) > 61 else "",
                        "TRANAMT": float(line[62:75].strip() if len(line) > 74 else "0"),
                        "TRXNFEE": float(line[75:88].strip() if len(line) > 87 else "0"),
                        "NETTAMT": float(line[88:101].strip() if len(line) > 100 else "0"),
                        "RECNO": line[101:107].strip() if len(line) > 106 else "",
                        "TRANCDE": line[107:110].strip() if len(line) > 109 else "",
                        "FSELERID": fselerid,
                        "FSELACNO": line[120:140].strip() if len(line) > 139 else "",
                        "FBUYBKID": line[140:155].strip() if len(line) > 154 else "",
                        "FSELERDE": line[155:185].strip() if len(line) > 184 else "",
                        "FBUYACNO": line[185:205].strip() if len(line) > 204 else ""
                    }
                    records.append(record)
                except:
                    continue
        
        if records:
            df = pl.DataFrame(records)
            logger.info(f"Read {len(df)} records")
            return df
        return pl.DataFrame()
    except Exception as e:
        logger.error(f"Error reading INPUTF1: {str(e)}")
        return pl.DataFrame()

def read_control1():
    """Read control account"""
    try:
        if os.path.exists(CONTROL1):
            with open(CONTROL1, 'r') as f:
                line = f.readline().strip()
                if len(line) >= 10:
                    return line[:10]
    except:
        pass
    return ""

def read_control2():
    """Read control date"""
    rptdate = {"RPTDAYDD": "01", "RPTDAYMM": "01", "RPTDCCYY": "2020"}
    try:
        if os.path.exists(CONTROL2):
            with open(CONTROL2, 'r') as f:
                line = f.readline().strip()
                if len(line) >= 8:
                    rptdate = {
                        "RPTDAYDD": line[6:8],
                        "RPTDAYMM": line[4:6],
                        "RPTDCCYY": "20" + line[0:2]
                    }
    except:
        pass
    return rptdate

def read_report_control():
    """Read report control parameters"""
    corp_info = {"CRPCDE": "", "BRHCDE": "", "RPTNM": "", "REF01": "", "REF02": ""}
    try:
        if os.path.exists(CONTRP):
            with open(CONTRP, 'r') as f:
                for line in f:
                    if len(line) >= 120:
                        corp_info = {
                            "CRPCDE": line[11:15].strip() if len(line) > 14 else "",
                            "BRHCDE": line[16:20].strip() if len(line) > 19 else "",
                            "RPTNM": line[25:65].strip() if len(line) > 64 else "",
                            "REF01": line[79:99].strip() if len(line) > 98 else "",
                            "REF02": line[99:119].strip() if len(line) > 118 else ""
                        }
                        break
    except:
        pass
    return corp_info

def read_bank_branch(branch_code):
    """Read bank branch name"""
    try:
        if os.path.exists(BANKBRCH):
            with open(BANKBRCH, 'r') as f:
                for line in f:
                    if len(line) >= 40 and line[1:5].strip() == branch_code:
                        return line[11:41].strip()
    except:
        pass
    return ""

def process_transactions(AAA):
    """Process transactions"""
    output_records = []
    if len(AAA) > 0:
        for row in AAA.iter_rows(named=True):
            output_records.append(row)
    return output_records

def write_report(records, ractno, rptdate, corp_info, bank_branch):
    """Write transaction report"""
    logger.info(f"Generating report with {len(records)} transactions")
    
    try:
        with open(OUTPUT1, 'w') as f:
            f.write(f"REGAL WORLDWIDE S/B\n")
            f.write(f"DAILY TRANSACTION REPORT\n")
            f.write(f"Date: {rptdate['RPTDCCYY']}-{rptdate['RPTDAYMM']}-{rptdate['RPTDAYDD']}\n")
            f.write(f"Account: {ractno}\n")
            f.write(f"Report: {corp_info.get('RPTNM', '')}\n")
            f.write(f"Branch: {bank_branch}\n\n")
            
            f.write("Transaction ID        Seller Order                        Amount        Fee       Net Amount\n")
            f.write("-" * 100 + "\n\n")
            
            total_amt = 0
            total_fee = 0
            total_net = 0
            
            for record in records:
                ftransid = str(record.get("FTRANSID", "")).ljust(16)
                fselordn = str(record.get("FSELORDN", "")).ljust(40)
                tranamt = float(record.get("TRANAMT", 0))
                trxnfee = float(record.get("TRXNFEE", 0))
                nettamt = float(record.get("NETTAMT", 0))
                
                total_amt += tranamt
                total_fee += trxnfee
                total_net += nettamt
                
                line = f"{ftransid}{fselordn}{tranamt:13.2f}{trxnfee:13.2f}{nettamt:13.2f}\n"
                f.write(line)
            
            f.write("-" * 100 + "\n")
            f.write(f"TOTALS:{' '*57}{total_amt:13.2f}{total_fee:13.2f}{total_net:13.2f}\n")
        
        logger.info(f"Report generated successfully")
    except Exception as e:
        logger.error(f"Error writing report: {str(e)}")
        raise

if __name__ == "__main__":
    main()
