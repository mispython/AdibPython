# DPFRWHSP.py
# /* FPX CUMULATIVE SUMMARY FILE (SP) FOR REGAL WORLDWIDE S/B (3997565933) */

import polars as pl
from datetime import datetime, timedelta
import common.fixed_width_reader as fixed_width_reader
from common.batch_date import get_batch_date
import os
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Obtain date for file paths
date_info = get_batch_date()
file_date = date_info["file_date"]
folder_day = date_info["folder_day"]
folder_month = date_info["folder_month"]
folder_year = date_info["folder_year"]

# Define file paths
INPUTF1 = f"/host/dp/input/rwh/INPUTF1_{folder_year}{folder_month}{folder_day}.dat"
INPUTF2 = f"/host/dp/input/rwh/INPUTF2_{folder_year}{folder_month}{folder_day}.dat"
CONTROL2 = f"/host/dp/input/rwh/CONTROL2_{folder_year}{folder_month}{folder_day}.dat"
CUMULATIVE = f"/host/dp/output/DPFRWHSP_CUMSUM_{folder_year}{folder_month}{folder_day}.txt"

def main():
    """SAS DPFRWHSP program - Regal Worldwide Cumulative Summary"""
    
    try:
        logger.info("Starting DPFRWHSP - REGAL WORLDWIDE CUMULATIVE SUMMARY")
        
        # Step 1: Read input files
        logger.info(f"Reading current file from {INPUTF1}")
        AAA = read_input_file(INPUTF1)
        
        logger.info(f"Reading previous cumulative from {INPUTF2}")
        BBB = read_input_file(INPUTF2) if os.path.exists(INPUTF2) else pl.DataFrame()
        
        # Step 2: Read control date
        rpt_date = read_control_date()
        
        # Step 3: Determine processing logic based on date
        logger.info(f"Processing date: {rpt_date['RPTDCCYY']}-{rpt_date['RPTDAYMM']}-{rpt_date['RPTDAYDD']}")
        
        # Step 4: Process cumulative
        output_df = process_cumulative(AAA, BBB, rpt_date)
        
        # Step 5: Write output file
        logger.info(f"Writing cumulative to {CUMULATIVE}")
        write_cumulative_file(output_df)
        
        logger.info("DPFRWHSP processing completed successfully.")
        
    except Exception as e:
        logger.error(f"Error in DPFRWHSP processing: {str(e)}")
        raise

def read_input_file(filepath):
    """Read fixed-width input file"""
    
    records = []
    try:
        with open(filepath, 'r') as f:
            for line in f:
                if len(line) < 300:
                    continue
                
                try:
                    record = {
                        "PROCDT": line[0:6].strip() if len(line) > 5 else "",
                        "FTRANSID": line[6:22].strip() if len(line) > 21 else "",
                        "FSELORDN": line[22:62].strip() if len(line) > 61 else "",
                        "TRANAMT": float(line[62:75].strip() if len(line) > 74 else "0"),
                        "TRXNFEE": float(line[75:88].strip() if len(line) > 87 else "0"),
                        "NETTAMT": float(line[88:101].strip() if len(line) > 100 else "0"),
                        "RECNO": line[101:107].strip() if len(line) > 106 else "",
                        "TRANCDE": line[107:110].strip() if len(line) > 109 else "",
                        "FSELERID": line[110:120].strip() if len(line) > 119 else "",
                        "FSELACNO": line[120:140].strip() if len(line) > 139 else "",
                        "FBUYBKID": line[140:155].strip() if len(line) > 154 else "",
                        "FSELERDE": line[155:185].strip() if len(line) > 184 else "",
                        "FBUYACNO": line[185:205].strip() if len(line) > 204 else ""
                    }
                    records.append(record)
                except:
                    continue
        
        if records:
            df = pl.DataFrame(records)
            logger.info(f"Read {len(df)} records from {filepath}")
            return df
        return pl.DataFrame()
    except Exception as e:
        logger.error(f"Error reading file {filepath}: {str(e)}")
        return pl.DataFrame()

def read_control_date():
    """Read control date"""
    rpt_date = {"RPTDAYDD": "01", "RPTDAYMM": "01", "RPTDCCYY": "2020"}
    try:
        if os.path.exists(CONTROL2):
            with open(CONTROL2, 'r') as f:
                line = f.readline().strip()
                if len(line) >= 8:
                    rpt_date = {
                        "RPTDAYDD": line[6:8],
                        "RPTDAYMM": line[4:6],
                        "RPTDCCYY": "20" + line[0:2]
                    }
        logger.info(f"Read control date: {rpt_date}")
    except Exception as e:
        logger.error(f"Error reading CONTROL2: {str(e)}")
    
    return rpt_date

def process_cumulative(AAA, BBB, rpt_date):
    """Process cumulative logic: reset on 01st, merge other days"""
    
    # IF rptdaydd == "01" THEN output AAA only (reset cycle)
    if rpt_date["RPTDAYDD"] == "01":
        logger.info("Reset date (01st of month) - outputting current transactions only")
        return AAA
    
    # ELSE merge PREVFILE + AAA sorted by PROCDT/FTRANSID
    else:
        logger.info("Cumulative merge - combining previous cumulative with current transactions")
        
        if len(BBB) == 0:
            logger.info("No previous cumulative file, using current transactions only")
            return AAA
        
        # Concatenate previous cumulative with current transactions
        merged_df = pl.concat([BBB, AAA], how="diagonal")
        
        # Sort by PROCDT (processing date) then FTRANSID (transaction ID)
        merged_df = merged_df.sort(["PROCDT", "FTRANSID"])
        
        logger.info(f"Merged cumulative contains {len(merged_df)} records")
        return merged_df

def write_cumulative_file(output_df):
    """Write cumulative file in fixed format"""
    
    try:
        with open(CUMULATIVE, 'w') as f:
            for row in output_df.iter_rows(named=True):
                # Build fixed-width 300-char record
                procdt = str(row.get("PROCDT", "")).ljust(6)[:6]
                ftransid = str(row.get("FTRANSID", "")).ljust(16)[:16]
                fselordn = str(row.get("FSELORDN", "")).ljust(40)[:40]
                tranamt = str(int(float(row.get("TRANAMT", 0)) * 100)).rjust(13)[-13:]
                trxnfee = str(int(float(row.get("TRXNFEE", 0)) * 100)).rjust(13)[-13:]
                nettamt = str(int(float(row.get("NETTAMT", 0)) * 100)).rjust(13)[-13:]
                recno = str(row.get("RECNO", "")).ljust(6)[:6]
                trancde = str(row.get("TRANCDE", "")).ljust(3)[:3]
                fselerid = str(row.get("FSELERID", "")).ljust(10)[:10]
                fselacno = str(row.get("FSELACNO", "")).ljust(20)[:20]
                fbuybkid = str(row.get("FBUYBKID", "")).ljust(15)[:15]
                fselerde = str(row.get("FSELERDE", "")).ljust(30)[:30]
                fbuyacno = str(row.get("FBUYACNO", "")).ljust(20)[:20]
                
                record = (procdt + ftransid + fselordn + tranamt + trxnfee + nettamt + 
                         recno + trancde + fselerid + fselacno + fbuybkid + fselerde + fbuyacno)
                
                # Pad to exactly 300 chars
                record = record.ljust(300)[:300]
                f.write(record + "\n")
        
        logger.info(f"Cumulative file written successfully with {len(output_df)} records")
    except Exception as e:
        logger.error(f"Error writing cumulative file: {str(e)}")
        raise

if __name__ == "__main__":
    main()
