# DPFRWHSU.py
# /* FPX SUMMARY FILE (SU) FOR REGAL WORLDWIDE S/B (3997565933) WITH EXCEPTION REPORTING */

import polars as pl
from datetime import datetime, timedelta
import common.fixed_width_reader as fixed_width_reader
from common.batch_date import get_batch_date
import os
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Obtain date for file paths
date_info = get_batch_date()
file_date = date_info["file_date"]
folder_day = date_info["folder_day"]
folder_month = date_info["folder_month"]
folder_year = date_info["folder_year"]

# Define file paths
INPUTF1 = f"/host/dp/input/rwh/INPUTF1_{folder_year}{folder_month}{folder_day}.dat"
INPUTF2 = f"/host/dp/input/rwh/INPUTF2_{folder_year}{folder_month}{folder_day}.dat"
CONTROL1 = f"/host/dp/input/rwh/CONTROL1_{folder_year}{folder_month}{folder_day}.dat"
CONTROL2 = f"/host/dp/input/rwh/CONTROL2_{folder_year}{folder_month}{folder_day}.dat"
OUTPUT1 = f"/host/dp/output/DPFRWHSU_SUMMARY_{folder_year}{folder_month}{folder_day}.txt"
EXCPO = f"/host/dp/output/DPFRWHSU_EXCEPTION_{folder_year}{folder_month}{folder_day}.txt"

PROD_SELLER_ID = "SE00016904"

def main():
    """SAS DPFRWHSU program - Regal Worldwide Summary File with Exception Reporting"""
    
    try:
        logger.info("Starting DPFRWHSU - REGAL WORLDWIDE SUMMARY FILE")
        
        # Step 1: Read input files
        logger.info(f"Reading INPUTF1 from {INPUTF1}")
        AAA = read_inputf1()
        
        logger.info(f"Reading INPUTF2 from {INPUTF2}")
        BBB = read_inputf2()
        
        # Step 2: Process transactions
        logger.info("Processing summary transactions and exception detection")
        summary_records, exception_records = process_transactions(AAA, BBB)
        
        # Step 3: Write output files
        logger.info(f"Writing summary to {OUTPUT1}")
        write_summary_file(summary_records)
        
        logger.info(f"Writing exceptions to {EXCPO}")
        write_exception_file(exception_records)
        
        logger.info("DPFRWHSU processing completed successfully.")
        
    except Exception as e:
        logger.error(f"Error in DPFRWHSU processing: {str(e)}")
        raise

def read_inputf1():
    """Read and filter INPUTF1 - current transactions"""
    
    records = []
    try:
        with open(INPUTF1, 'r') as f:
            for line in f:
                if len(line) < 300:
                    continue
                
                try:
                    # Filter: TTRANCODE != "874" AND SRCECDE == "313" (valid FPX transactions)
                    trancde = line[107:110].strip() if len(line) > 109 else ""
                    srcecd = line[260:263].strip() if len(line) > 262 else ""
                    
                    if trancde == "874" or srcecd != "313":
                        continue
                    
                    ftransid = line[6:22].strip() if len(line) > 21 else ""
                    
                    record = {
                        "PROCDT": line[0:6].strip() if len(line) > 5 else "",
                        "FTRANSID": ftransid,
                        "FSELORDN": line[22:62].strip() if len(line) > 61 else "",
                        "TRANAMT": float(line[62:75].strip() if len(line) > 74 else "0"),
                        "TRXNFEE": float(line[75:88].strip() if len(line) > 87 else "0"),
                        "NETTAMT": float(line[88:101].strip() if len(line) > 100 else "0"),
                        "RECNO": line[101:107].strip() if len(line) > 106 else "",
                        "TRANCDE": trancde,
                        "FSELERID": line[110:120].strip() if len(line) > 119 else "",
                        "FSELACNO": line[120:140].strip() if len(line) > 139 else "",
                        "FBUYBKID": line[140:155].strip() if len(line) > 154 else "",
                        "FSELERDE": line[155:185].strip() if len(line) > 184 else "",
                        "FBUYACNO": line[185:205].strip() if len(line) > 204 else "",
                        "SRCECDE": srcecd
                    }
                    records.append(record)
                except Exception as e:
                    logger.debug(f"Error parsing INPUTF1 record: {str(e)}")
                    continue
        
        if records:
            df = pl.DataFrame(records)
            logger.info(f"Read {len(df)} valid records from INPUTF1")
            return df
        return pl.DataFrame()
    except Exception as e:
        logger.error(f"Error reading INPUTF1: {str(e)}")
        return pl.DataFrame()

def read_inputf2():
    """Read and filter INPUTF2 - extended transaction data"""
    
    records = []
    try:
        with open(INPUTF2, 'r') as f:
            for line in f:
                if len(line) < 300:
                    continue
                
                try:
                    # Filter: FSELERID == "SE00016904" (Regal Worldwide)
                    fselerid = line[110:120].strip() if len(line) > 119 else ""
                    
                    if fselerid != PROD_SELLER_ID:
                        continue
                    
                    ftransid = line[6:22].strip() if len(line) > 21 else ""
                    
                    record = {
                        "FTRANSID": ftransid,
                        "FSELORDN": line[22:62].strip() if len(line) > 61 else "",
                        "TRANAMT": float(line[62:75].strip() if len(line) > 74 else "0"),
                        "TRXNFEE": float(line[75:88].strip() if len(line) > 87 else "0"),
                        "NETTAMT": float(line[88:101].strip() if len(line) > 100 else "0"),
                        "FSELERID": fselerid,
                        "FSELACNO": line[120:140].strip() if len(line) > 139 else "",
                        "EXTENDED_DATA": line[205:567].strip() if len(line) > 206 else ""
                    }
                    records.append(record)
                except Exception as e:
                    logger.debug(f"Error parsing INPUTF2 record: {str(e)}")
                    continue
        
        if records:
            df = pl.DataFrame(records)
            logger.info(f"Read {len(df)} records from INPUTF2 for seller {PROD_SELLER_ID}")
            return df
        return pl.DataFrame()
    except Exception as e:
        logger.error(f"Error reading INPUTF2: {str(e)}")
        return pl.DataFrame()

def process_transactions(AAA, BBB):
    """Merge transactions and detect exceptions"""
    
    summary_records = []
    exception_records = []
    
    try:
        # Create transaction ID sets for comparison
        aaa_ids = set(AAA["FTRANSID"].to_list()) if len(AAA) > 0 else set()
        bbb_ids = set(BBB["FTRANSID"].to_list()) if len(BBB) > 0 else set()
        
        logger.info(f"AAA records: {len(aaa_ids)} transactions, BBB records: {len(bbb_ids)} transactions")
        
        # Process AAA (current transactions)
        if len(AAA) > 0:
            for row in AAA.iter_rows(named=True):
                ftransid = row.get("FTRANSID", "")
                summary_records.append(row)
                
                # If transaction in AAA but not in BBB, mark as exception
                if ftransid not in bbb_ids:
                    exception_records.append({
                        "FTRANSID": ftransid,
                        "FSELORDN": row.get("FSELORDN", ""),
                        "TRANAMT": row.get("TRANAMT", 0),
                        "STATUS": "NOT_IN_EXTENDED"
                    })
        
        logger.info(f"Summary: {len(summary_records)} records, Exceptions: {len(exception_records)} records")
        
    except Exception as e:
        logger.error(f"Error processing transactions: {str(e)}")
    
    return summary_records, exception_records

def write_summary_file(records):
    """Write summary file"""
    
    try:
        total_amt = 0
        total_fee = 0
        total_net = 0
        
        with open(OUTPUT1, 'w') as f:
            f.write("REGAL WORLDWIDE S/B - DAILY SUMMARY\n\n")
            f.write("Transaction ID        Seller Order                        Amount        Fee       Net Amount\n")
            f.write("-" * 100 + "\n\n")
            
            for record in records:
                ftransid = str(record.get("FTRANSID", "")).ljust(16)
                fselordn = str(record.get("FSELORDN", "")).ljust(40)
                tranamt = float(record.get("TRANAMT", 0))
                trxnfee = float(record.get("TRXNFEE", 0))
                nettamt = float(record.get("NETTAMT", 0))
                
                total_amt += tranamt
                total_fee += trxnfee
                total_net += nettamt
                
                line = f"{ftransid}{fselordn}{tranamt:13.2f}{trxnfee:13.2f}{nettamt:13.2f}\n"
                f.write(line)
            
            f.write("-" * 100 + "\n")
            f.write(f"TOTALS:{' '*57}{total_amt:13.2f}{total_fee:13.2f}{total_net:13.2f}\n")
            f.write(f"\nTotal Transactions: {len(records)}\n")
        
        logger.info(f"Summary file written successfully")
    except Exception as e:
        logger.error(f"Error writing summary file: {str(e)}")
        raise

def write_exception_file(records):
    """Write exception report"""
    
    try:
        with open(EXCPO, 'w') as f:
            if len(records) > 0:
                f.write("REGAL WORLDWIDE S/B - EXCEPTION REPORT\n")
                f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
                f.write("Transaction ID        Seller Order                        Amount        Status\n")
                f.write("-" * 100 + "\n\n")
                
                for record in records:
                    ftransid = str(record.get("FTRANSID", "")).ljust(16)
                    fselordn = str(record.get("FSELORDN", "")).ljust(40)
                    tranamt = str(record.get("TRANAMT", 0)).rjust(13)
                    status = str(record.get("STATUS", "")).ljust(20)
                    
                    line = f"{ftransid}{fselordn}{tranamt}{status}\n"
                    f.write(line)
                
                f.write("-" * 100 + "\n")
                f.write(f"Total Exceptions: {len(records)}\n")
            else:
                f.write("REGAL WORLDWIDE S/B - EXCEPTION REPORT\n")
                f.write("No exceptions found.\n")
        
        logger.info(f"Exception file written successfully with {len(records)} records")
    except Exception as e:
        logger.error(f"Error writing exception file: {str(e)}")
        raise

if __name__ == "__main__":
    main()
