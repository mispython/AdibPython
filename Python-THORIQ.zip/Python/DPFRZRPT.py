# DPFRZRPT.py
# /* AML REPORT FOR ACCOUNTS UNDER INVESTIGATIONS */
# /* REPORTS FOR SECTIONS 44, 50, 26 OF AMLATFA/DDA */

import polars as pl
from datetime import datetime, timedelta
import common.fixed_width_reader as fixed_width_reader
from common.batch_date import get_batch_date
import os
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Obtain date for file paths
date_info = get_batch_date()
file_date = date_info["file_date"]
folder_day = date_info["folder_day"]
folder_month = date_info["folder_month"]
folder_year = date_info["folder_year"]

# Define file paths
INPUTF1 = f"/host/dp/input/aml/INPUTF1_{folder_year}{folder_month}{folder_day}.dat"
REPORT1 = f"/host/dp/output/DPFRZRPT_REPORT_A_S44_{folder_year}{folder_month}{folder_day}.txt"
REPORT2 = f"/host/dp/output/DPFRZRPT_REPORT_B_S50_PBB_{folder_year}{folder_month}{folder_day}.txt"
REPORT3 = f"/host/dp/output/DPFRZRPT_REPORT_B_S50_PIBB_{folder_year}{folder_month}{folder_day}.txt"
REPORT4 = f"/host/dp/output/DPFRZRPT_REPORT_C_S26_PBB_{folder_year}{folder_month}{folder_day}.txt"
REPORT5 = f"/host/dp/output/DPFRZRPT_REPORT_C_S26_PIBB_{folder_year}{folder_month}{folder_day}.txt"

def main():
    """DPFRZRPT - AML Investigation Reports"""
    
    try:
        logger.info("Starting DPFRZRPT - AML INVESTIGATION REPORTS")
        
        # Step 1: Read and categorize input data
        logger.info(f"Reading AML data from {INPUTF1}")
        DATARPA, DATARPB1, DATARPB2, DATARPC1, DATARPC2 = categorize_records()
        
        # Step 2: Generate Report A (Section 44)
        logger.info("Generating Report A - Section 44 (PBB & PIBB)")
        generate_report_a(DATARPA)
        
        # Step 3: Generate Report B1 (Section 50 - PBB)
        logger.info("Generating Report B1 - Section 50 (PBB)")
        generate_report_b1(DATARPB1)
        
        # Step 4: Generate Report B2 (Section 50 - PIBB)
        logger.info("Generating Report B2 - Section 50 (PIBB)")
        generate_report_b2(DATARPB2)
        
        # Step 5: Generate Report C1 (Section 26 - PBB)
        logger.info("Generating Report C1 - Section 26 (PBB)")
        generate_report_c1(DATARPC1)
        
        # Step 6: Generate Report C2 (Section 26 - PIBB)
        logger.info("Generating Report C2 - Section 26 (PIBB)")
        generate_report_c2(DATARPC2)
        
        logger.info("DPFRZRPT processing completed successfully.")
        
    except Exception as e:
        logger.error(f"Error in DPFRZRPT processing: {str(e)}")
        raise

def categorize_records():
    """Read and categorize records by section and cost center"""
    
    DATARPA = []
    DATARPB1 = []
    DATARPB2 = []
    DATARPC1 = []
    DATARPC2 = []
    
    try:
        if not os.path.exists(INPUTF1):
            logger.warning(f"File not found: {INPUTF1}")
            return (pl.DataFrame(), pl.DataFrame(), pl.DataFrame(), 
                   pl.DataFrame(), pl.DataFrame())
        
        with open(INPUTF1, 'r') as f:
            for line in f:
                if len(line) < 140:
                    continue
                
                try:
                    acctno = int(line[0:11]) if line[0:11].strip() else 0
                    accname = line[11:35].strip() if len(line) > 34 else ""
                    costctr = int(line[35:42]) if line[35:42].strip() else 0
                    section = line[63:66].strip() if len(line) > 65 else ""
                    frzdate = line[113:121].strip() if len(line) > 120 else ""
                    expdate = line[124:132].strip() if len(line) > 131 else ""
                    expind = line[135:136].strip() if len(line) > 135 else ""
                    expdays = int(line[136:139]) if line[136:139].strip() else 0
                    
                    record = {
                        "ACCTNO": acctno,
                        "ACCNAME": accname,
                        "COSTCTR": costctr,
                        "SECTION": section,
                        "FRZDATE": frzdate,
                        "EXPDATE": expdate,
                        "EXPIND": expind,
                        "EXPDAYS": expdays
                    }
                    
                    if section == "S44":
                        DATARPA.append(record)
                    elif section == "S50":
                        if costctr < 3000:
                            DATARPB1.append(record)
                        else:
                            DATARPB2.append(record)
                    elif section == "S26":
                        if costctr < 3000:
                            DATARPC1.append(record)
                        else:
                            DATARPC2.append(record)
                except:
                    continue
        
        return (pl.DataFrame(DATARPA) if DATARPA else pl.DataFrame(),
                pl.DataFrame(DATARPB1) if DATARPB1 else pl.DataFrame(),
                pl.DataFrame(DATARPB2) if DATARPB2 else pl.DataFrame(),
                pl.DataFrame(DATARPC1) if DATARPC1 else pl.DataFrame(),
                pl.DataFrame(DATARPC2) if DATARPC2 else pl.DataFrame())
    
    except Exception as e:
        logger.error(f"Error categorizing records: {str(e)}")
        return (pl.DataFrame(), pl.DataFrame(), pl.DataFrame(), 
               pl.DataFrame(), pl.DataFrame())

def generate_report_a(DATARPA):
    """Generate Report A - Section 44 (PBB & PIBB)"""
    
    try:
        with open(REPORT1, 'w') as f:
            if len(DATARPA) == 0:
                f.write("REPORT NO   : AML/S44/PBB\n")
                f.write("PROGRAM ID  : DPFRZRPT\n")
                f.write("------- NIL TRANSACTION ---------\n")
                return
            
            # Sort by EXPIND, FRZDATE, EXPDAYS, ACCTNO
            records = DATARPA.to_dicts()
            records.sort(key=lambda x: (x.get("EXPIND", ""), x.get("FRZDATE", ""), 
                                       x.get("EXPDAYS", 0), x.get("ACCTNO", 0)))
            
            date = (datetime.now() - timedelta(days=1)).strftime("%d-%m-%Y")
            page_no = 1
            cnt = 0
            
            # Header
            f.write(f"{'REPORT NO   : AML/S44/PBB':<50}PUBLIC BANK BERHAD{'':<33}PAGE NO     : {page_no:03d}\n")
            f.write(f"{'PROGRAM ID  : DPFRZRPT':<93}REPORT DATE : {date}\n")
            f.write("WEEKLY REPORT ON ORDERS UNDER SECTION 44 OF THE AMLATFA\n")
            f.write("=" * 75 + "\n")
            f.write("ITEM:     CUSTOMER NAME:              ACCOUNT NO:  DATE FROZEN:  EXPIRING DATE/DAYS:  REMARKS:\n")
            f.write("-" * 90 + "\n\n")
            
            for record in records:
                cnt += 1
                acctno = str(record.get("ACCTNO", "")).rjust(10)
                accname = str(record.get("ACCNAME", "")).ljust(24)
                frzdate = record.get("FRZDATE", "")
                expind = record.get("EXPIND", "")
                expdate = record.get("EXPDATE", "")
                expdays = str(record.get("EXPDAYS", "")).rjust(3)
                
                remark = ""
                if expind == "A":
                    remark = "LAPSED"
                elif expind == "E":
                    remark = expdate
                elif expind == "N":
                    remark = f"{expdays} DAYS"
                
                f.write(f"{cnt:>5}  {accname}{acctno}  {frzdate}  {remark}\n")
        
        logger.info(f"Report A generated with {len(DATARPA)} records")
    except Exception as e:
        logger.error(f"Error generating Report A: {str(e)}")

def generate_report_b1(DATARPB1):
    """Generate Report B1 - Section 50 (PBB)"""
    
    try:
        with open(REPORT2, 'w') as f:
            if len(DATARPB1) == 0:
                f.write("REPORT NO   : AML/S50/PBB\n")
                f.write("PROGRAM ID  : DPFRZRPT\n")
                f.write("------- NIL TRANSACTION ---------\n")
                return
            
            records = DATARPB1.to_dicts()
            records.sort(key=lambda x: (x.get("FRZDATE", ""), x.get("ACCTNO", 0)))
            
            date = (datetime.now() - timedelta(days=1)).strftime("%d-%m-%Y")
            page_no = 1
            cnt = 0
            
            f.write(f"{'REPORT NO   : AML/S50/PBB':<50}PUBLIC BANK BERHAD{'':<33}PAGE NO     : {page_no:03d}\n")
            f.write(f"{'PROGRAM ID  : DPFRZRPT':<93}REPORT DATE : {date}\n")
            f.write("WEEKLY REPORT ON ORDERS UNDER SECTION 50 OF THE AMLATFA\n")
            f.write("=" * 75 + "\n")
            f.write("ITEM:     CUSTOMER NAME:              ACCOUNT NO:  DATE FROZEN:  REMARKS:\n")
            f.write("-" * 80 + "\n\n")
            
            for record in records:
                cnt += 1
                acctno = str(record.get("ACCTNO", "")).rjust(10)
                accname = str(record.get("ACCNAME", "")).ljust(24)
                frzdate = record.get("FRZDATE", "")
                
                f.write(f"{cnt:>5}  {accname}{acctno}  {frzdate}\n")
        
        logger.info(f"Report B1 generated with {len(DATARPB1)} records")
    except Exception as e:
        logger.error(f"Error generating Report B1: {str(e)}")

def generate_report_b2(DATARPB2):
    """Generate Report B2 - Section 50 (PIBB)"""
    
    try:
        with open(REPORT3, 'w') as f:
            if len(DATARPB2) == 0:
                f.write("REPORT NO   : AML/S50/PIBB\n")
                f.write("PROGRAM ID  : DPFRZRPT\n")
                f.write("------- NIL TRANSACTION ---------\n")
                return
            
            records = DATARPB2.to_dicts()
            records.sort(key=lambda x: (x.get("FRZDATE", ""), x.get("ACCTNO", 0)))
            
            date = (datetime.now() - timedelta(days=1)).strftime("%d-%m-%Y")
            page_no = 1
            cnt = 0
            
            f.write(f"{'REPORT NO   : AML/S50/PIBB':<48}PUBLIC ISLAMIC BANK BERHAD{'':<25}PAGE NO     : {page_no:03d}\n")
            f.write(f"{'PROGRAM ID  : DPFRZRPT':<93}REPORT DATE : {date}\n")
            f.write("WEEKLY REPORT ON ORDERS UNDER SECTION 50 OF THE AMLATFA\n")
            f.write("=" * 75 + "\n")
            f.write("ITEM:     CUSTOMER NAME:              ACCOUNT NO:  DATE FROZEN:  REMARKS:\n")
            f.write("-" * 80 + "\n\n")
            
            for record in records:
                cnt += 1
                acctno = str(record.get("ACCTNO", "")).rjust(10)
                accname = str(record.get("ACCNAME", "")).ljust(24)
                frzdate = record.get("FRZDATE", "")
                
                f.write(f"{cnt:>5}  {accname}{acctno}  {frzdate}\n")
        
        logger.info(f"Report B2 generated with {len(DATARPB2)} records")
    except Exception as e:
        logger.error(f"Error generating Report B2: {str(e)}")

def generate_report_c1(DATARPC1):
    """Generate Report C1 - Section 26 (PBB)"""
    
    try:
        with open(REPORT4, 'w') as f:
            if len(DATARPC1) == 0:
                f.write("REPORT NO   : DDA/S26(4)/PBB\n")
                f.write("PROGRAM ID  : DPFRZRPT\n")
                f.write("------- NIL TRANSACTION ---------\n")
                return
            
            records = DATARPC1.to_dicts()
            records.sort(key=lambda x: (x.get("FRZDATE", ""), x.get("ACCTNO", 0)))
            
            date = (datetime.now() - timedelta(days=1)).strftime("%d-%m-%Y")
            page_no = 1
            cnt = 0
            
            f.write(f"{'REPORT NO   : DDA/S26(4)/PBB':<50}PUBLIC BANK BERHAD{'':<33}PAGE NO     : {page_no:03d}\n")
            f.write(f"{'PROGRAM ID  : DPFRZRPT':<93}REPORT DATE : {date}\n")
            f.write("WEEKLY REPORT ON ORDERS UNDER SECTION 26(4) OF THE DDA\n")
            f.write("=" * 75 + "\n")
            f.write("ITEM:     CUSTOMER NAME:              ACCOUNT NO:  DATE FROZEN:  REMARKS:\n")
            f.write("-" * 80 + "\n\n")
            
            for record in records:
                cnt += 1
                acctno = str(record.get("ACCTNO", "")).rjust(10)
                accname = str(record.get("ACCNAME", "")).ljust(24)
                frzdate = record.get("FRZDATE", "")
                
                f.write(f"{cnt:>5}  {accname}{acctno}  {frzdate}\n")
        
        logger.info(f"Report C1 generated with {len(DATARPC1)} records")
    except Exception as e:
        logger.error(f"Error generating Report C1: {str(e)}")

def generate_report_c2(DATARPC2):
    """Generate Report C2 - Section 26 (PIBB)"""
    
    try:
        with open(REPORT5, 'w') as f:
            if len(DATARPC2) == 0:
                f.write("REPORT NO   : DDA/S26(4)/PIBB\n")
                f.write("PROGRAM ID  : DPFRZRPT\n")
                f.write("------- NIL TRANSACTION ---------\n")
                return
            
            records = DATARPC2.to_dicts()
            records.sort(key=lambda x: (x.get("FRZDATE", ""), x.get("ACCTNO", 0)))
            
            date = (datetime.now() - timedelta(days=1)).strftime("%d-%m-%Y")
            page_no = 1
            cnt = 0
            
            f.write(f"{'REPORT NO   : DDA/S26(4)/PIBB':<48}PUBLIC ISLAMIC BANK BERHAD{'':<25}PAGE NO     : {page_no:03d}\n")
            f.write(f"{'PROGRAM ID  : DPFRZRPT':<93}REPORT DATE : {date}\n")
            f.write("WEEKLY REPORT ON ORDERS UNDER SECTION 26(4) OF THE DDA\n")
            f.write("=" * 75 + "\n")
            f.write("ITEM:     CUSTOMER NAME:              ACCOUNT NO:  DATE FROZEN:  REMARKS:\n")
            f.write("-" * 80 + "\n\n")
            
            for record in records:
                cnt += 1
                acctno = str(record.get("ACCTNO", "")).rjust(10)
                accname = str(record.get("ACCNAME", "")).ljust(24)
                frzdate = record.get("FRZDATE", "")
                
                f.write(f"{cnt:>5}  {accname}{acctno}  {frzdate}\n")
        
        logger.info(f"Report C2 generated with {len(DATARPC2)} records")
    except Exception as e:
        logger.error(f"Error generating Report C2: {str(e)}")

if __name__ == "__main__":
    main()
