# DPFSBTPP.py
# /* FPX DAILY PAYMENT FILE (OPM) FOR SECOND SECRET BEAUTY SDN BHD (3999524515) */

import polars as pl
from datetime import datetime, timedelta
import common.fixed_width_reader as fixed_width_reader
from common.batch_date import get_batch_date
import os
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Obtain date for file paths
date_info = get_batch_date()
file_date = date_info["file_date"]
folder_day = date_info["folder_day"]
folder_month = date_info["folder_month"]
folder_year = date_info["folder_year"]

# Define file paths
INPUTF1 = f"/host/dp/input/sbt/INPUTF1_{folder_year}{folder_month}{folder_day}.dat"
CONTROL1 = f"/host/dp/input/sbt/CONTROL1_{folder_year}{folder_month}{folder_day}.dat"
CONTROL2 = f"/host/dp/input/sbt/CONTROL2_{folder_year}{folder_month}{folder_day}.dat"
OUTPUT1 = f"/host/dp/output/DPFSBTPP_PAYMENT_{folder_year}{folder_month}{folder_day}.txt"

PROD_SELLER_ID = "SE00031525"

def main():
    """SAS DPFSBTPP program - Second Secret Beauty Payment File"""
    
    try:
        logger.info("Starting DPFSBTPP - SECOND SECRET BEAUTY PAYMENT FILE")
        
        # Step 1: Read transaction file
        logger.info(f"Reading transaction file from {INPUTF1}")
        AAA = read_inputf1()
        
        # Step 2: Read control files
        ractno = read_control1()
        rpt_date = read_control2()
        
        # Step 3: Process records
        logger.info("Processing payment transactions")
        output_records = process_records(AAA)
        
        # Step 4: Write output file
        logger.info(f"Writing payment file to {OUTPUT1}")
        write_payment_file(output_records, ractno, rpt_date)
        
        logger.info("DPFSBTPP processing completed successfully.")
        
    except Exception as e:
        logger.error(f"Error in DPFSBTPP processing: {str(e)}")
        raise

def read_inputf1():
    """Read and filter transaction file"""
    
    records = []
    try:
        if not os.path.exists(INPUTF1):
            logger.warning(f"File not found: {INPUTF1}")
            return pl.DataFrame()
        
        with open(INPUTF1, 'r') as f:
            for line in f:
                if len(line) < 200:
                    continue
                
                try:
                    fselerid = line[110:120].strip() if len(line) > 119 else ""
                    if fselerid != PROD_SELLER_ID:
                        continue
                    
                    record = {
                        "PROCDT": line[0:6].strip() if len(line) > 5 else "",
                        "FTRANSID": line[6:22].strip() if len(line) > 21 else "",
                        "FSELORDN": line[22:62].strip() if len(line) > 61 else "",
                        "TRANAMT": float(line[62:75].strip() if len(line) > 74 else "0"),
                        "TRXNFEE": float(line[75:88].strip() if len(line) > 87 else "0"),
                        "NETTAMT": float(line[88:101].strip() if len(line) > 100 else "0"),
                        "RECNO": line[101:107].strip() if len(line) > 106 else "",
                        "TRANCDE": line[107:110].strip() if len(line) > 109 else "",
                        "FSELERID": fselerid,
                        "FSELACNO": line[120:140].strip() if len(line) > 139 else "",
                        "FBUYBKID": line[140:155].strip() if len(line) > 154 else "",
                        "FSELERDE": line[155:185].strip() if len(line) > 184 else "",
                        "FBUYACNO": line[185:205].strip() if len(line) > 204 else ""
                    }
                    records.append(record)
                except:
                    continue
        
        if records:
            df = pl.DataFrame(records)
            logger.info(f"Read {len(df)} records")
            return df
        return pl.DataFrame()
    except Exception as e:
        logger.error(f"Error reading INPUTF1: {str(e)}")
        return pl.DataFrame()

def read_control1():
    """Read control account"""
    try:
        if os.path.exists(CONTROL1):
            with open(CONTROL1, 'r') as f:
                line = f.readline().strip()
                if len(line) >= 10:
                    return line[:10]
    except:
        pass
    return ""

def read_control2():
    """Read control date"""
    rpt_date = {"RPTDAYDD": "01", "RPTDAYMM": "01", "RPTDCCYY": "2020"}
    try:
        if os.path.exists(CONTROL2):
            with open(CONTROL2, 'r') as f:
                line = f.readline().strip()
                if len(line) >= 8:
                    rpt_date = {
                        "RPTDAYDD": line[6:8],
                        "RPTDAYMM": line[4:6],
                        "RPTDCCYY": line[0:4]
                    }
    except:
        pass
    return rpt_date

def process_records(AAA):
    """Process transaction records for payment file"""
    
    output_records = []
    if len(AAA) > 0:
        for row in AAA.iter_rows(named=True):
            output_records.append(row)
    return output_records

def write_payment_file(records, ractno, rpt_date):
    """Write payment file with header, detail, and trailer records"""
    
    logger.info(f"Generating payment file with {len(records)} transactions")
    
    try:
        with open(OUTPUT1, 'w') as f:
            # Header record (type 0)
            header = "0PBBFPX"
            header += rpt_date['RPTDCCYY'].ljust(4)
            header += rpt_date['RPTDAYMM'].ljust(2)
            header += rpt_date['RPTDAYDD'].ljust(2)
            header += " " * 104
            f.write(header[:120] + "\n")
            
            total_count = len(records)
            total_amount = sum(float(r.get("TRANAMT", 0)) for r in records)
            total_fee = sum(float(r.get("TRXNFEE", 0)) for r in records)
            total_net = sum(float(r.get("NETTAMT", 0)) for r in records)
            
            # Detail records (type 1)
            for record in records:
                ftransid = str(record.get("FTRANSID", "")).ljust(16)[:16]
                fselordn = str(record.get("FSELORDN", "")).ljust(40)[:40]
                fbuybkid = str(record.get("FBUYBKID", "")).ljust(15)[:15]
                tranamt = str(int(float(record.get("TRANAMT", 0)) * 100)).rjust(13)[-13:]
                trxnfee = str(int(float(record.get("TRXNFEE", 0)) * 100)).rjust(13)[-13:]
                nettamt = str(int(float(record.get("NETTAMT", 0)) * 100)).rjust(13)[-13:]
                recno = str(record.get("RECNO", "")).ljust(6)[:6]
                trancde = str(record.get("TRANCDE", "")).ljust(3)[:3]
                fselacno = str(record.get("FSELACNO", "")).ljust(10)[:10]
                
                detail = "1" + ftransid + fselordn + fbuybkid + tranamt + trxnfee + nettamt + recno + trancde + fselacno
                detail = detail[:120].ljust(120)
                f.write(detail + "\n")
            
            # Trailer record (type 9)
            trailer = "9PBBFPX"
            trailer += rpt_date['RPTDCCYY'].ljust(4)
            trailer += rpt_date['RPTDAYMM'].ljust(2)
            trailer += rpt_date['RPTDAYDD'].ljust(2)
            trailer += str(total_count).rjust(8).zfill(8)
            trailer += str(int(total_amount * 100)).rjust(16).zfill(16)
            trailer += str(int(total_fee * 100)).rjust(16).zfill(16)
            trailer += str(int(total_net * 100)).rjust(16).zfill(16)
            trailer += " " * 24
            f.write(trailer[:120] + "\n")
        
        logger.info(f"Payment file generated successfully")
    except Exception as e:
        logger.error(f"Error writing payment file: {str(e)}")
        raise

if __name__ == "__main__":
    main()
