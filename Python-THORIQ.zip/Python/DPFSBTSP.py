# DPFSBTSP.py
# /* CUMULATIVE SUMMARY FILE FOR SECOND SECRET BEAUTY (3999524515) */
# /* DP7302 - RESET ON 1ST OF MONTH */

import polars as pl
from datetime import datetime, timedelta
import common.fixed_width_reader as fixed_width_reader
from common.batch_date import get_batch_date
import os
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Obtain date for file paths
date_info = get_batch_date()
file_date = date_info["file_date"]
folder_day = date_info["folder_day"]
folder_month = date_info["folder_month"]
folder_year = date_info["folder_year"]

# Define file paths
INPUTF1 = f"/host/dp/input/sbt/INPUTF1_{folder_year}{folder_month}{folder_day}.dat"
INPUTF2 = f"/host/dp/input/sbt/INPUTF2_{folder_year}{folder_month}{folder_day}.dat"
CONTROL2 = f"/host/dp/input/sbt/CONTROL2_{folder_year}{folder_month}{folder_day}.dat"
OUTPUT1 = f"/host/dp/output/DPFSBTSP_CUMUL_{folder_year}{folder_month}{folder_day}.dat"

PROD_SELLER_ID = "SE00031525"

def main():
    """SAS DPFSBTSP program - Second Secret Beauty Cumulative Summary"""
    
    try:
        logger.info("Starting DPFSBTSP - SECOND SECRET BEAUTY CUMULATIVE SUMMARY")
        
        # Read report date
        rpt_date = read_control2()
        rpt_day = rpt_date.get("RPTDAYDD", "01")
        
        # Read current day transactions
        AAA = read_inputf1()
        
        # If first day of month, output current only. Otherwise merge with previous
        if rpt_day == "01":
            logger.info("First day of month - outputting current transactions only")
            output_records = AAA
        else:
            # Read previous cumulative
            PREVFILE = read_inputf2()
            
            # Merge: previous + current, sorted by PROCDT, FTRANSID
            logger.info("Merging previous cumulative with current transactions")
            output_records = merge_cumulative(PREVFILE, AAA)
        
        # Write output
        logger.info(f"Writing cumulative file to {OUTPUT1}")
        write_cumulative_file(output_records)
        
        logger.info("DPFSBTSP processing completed successfully.")
        
    except Exception as e:
        logger.error(f"Error in DPFSBTSP processing: {str(e)}")
        raise

def read_control2():
    """Read control date"""
    rpt_date = {"RPTDAYDD": "01", "RPTDAYMM": "01", "RPTDCCYY": "2020"}
    try:
        if os.path.exists(CONTROL2):
            with open(CONTROL2, 'r') as f:
                line = f.readline().strip()
                if len(line) >= 8:
                    rpt_date = {
                        "RPTDAYDD": line[6:8],
                        "RPTDAYMM": line[4:6],
                        "RPTDCCYY": line[0:4]
                    }
    except:
        pass
    return rpt_date

def read_inputf1():
    """Read current day transactions filtered by seller ID"""
    
    records = []
    try:
        if not os.path.exists(INPUTF1):
            logger.warning(f"File not found: {INPUTF1}")
            return pl.DataFrame()
        
        with open(INPUTF1, 'r') as f:
            for line in f:
                if len(line) < 200:
                    continue
                
                try:
                    fselerid = line[110:120].strip() if len(line) > 119 else ""
                    if fselerid != PROD_SELLER_ID:
                        continue
                    
                    record = {
                        "PROCDT": line[0:6].strip() if len(line) > 5 else "",
                        "FTRANSID": line[6:22].strip() if len(line) > 21 else "",
                        "FSELORDN": line[22:62].strip() if len(line) > 61 else "",
                        "TRANAMT": float(line[62:75].strip() if len(line) > 74 else "0"),
                        "TRXNFEE": float(line[75:88].strip() if len(line) > 87 else "0"),
                        "NETTAMT": float(line[88:101].strip() if len(line) > 100 else "0"),
                        "RECNO": line[101:107].strip() if len(line) > 106 else "",
                        "TRANCDE": line[107:110].strip() if len(line) > 109 else "",
                        "FSELERID": fselerid,
                        "FSELACNO": line[120:140].strip() if len(line) > 139 else "",
                        "FBUYBKID": line[140:155].strip() if len(line) > 154 else "",
                        "FSELERDE": line[155:185].strip() if len(line) > 184 else "",
                        "FBUYACNO": line[185:205].strip() if len(line) > 204 else ""
                    }
                    records.append(record)
                except:
                    continue
        
        if records:
            df = pl.DataFrame(records)
            logger.info(f"Read {len(df)} current day records")
            return df
        return pl.DataFrame()
    except Exception as e:
        logger.error(f"Error reading INPUTF1: {str(e)}")
        return pl.DataFrame()

def read_inputf2():
    """Read previous cumulative file"""
    
    records = []
    try:
        if not os.path.exists(INPUTF2):
            logger.warning(f"Previous cumulative file not found: {INPUTF2}")
            return pl.DataFrame()
        
        with open(INPUTF2, 'r') as f:
            for line in f:
                if len(line) < 200:
                    continue
                
                try:
                    record = {
                        "PROCDT": line[0:6].strip() if len(line) > 5 else "",
                        "FTRANSID": line[6:22].strip() if len(line) > 21 else "",
                        "FSELORDN": line[22:62].strip() if len(line) > 61 else "",
                        "TRANAMT": float(line[62:75].strip() if len(line) > 74 else "0"),
                        "TRXNFEE": float(line[75:88].strip() if len(line) > 87 else "0"),
                        "NETTAMT": float(line[88:101].strip() if len(line) > 100 else "0"),
                        "RECNO": line[101:107].strip() if len(line) > 106 else "",
                        "TRANCDE": line[107:110].strip() if len(line) > 109 else "",
                        "FSELERID": line[110:120].strip() if len(line) > 119 else "",
                        "FSELACNO": line[120:140].strip() if len(line) > 139 else "",
                        "FBUYBKID": line[140:155].strip() if len(line) > 154 else "",
                        "FSELERDE": line[155:185].strip() if len(line) > 184 else "",
                        "FBUYACNO": line[185:205].strip() if len(line) > 204 else ""
                    }
                    records.append(record)
                except:
                    continue
        
        if records:
            df = pl.DataFrame(records)
            logger.info(f"Read {len(df)} previous cumulative records")
            return df
        return pl.DataFrame()
    except Exception as e:
        logger.error(f"Error reading INPUTF2: {str(e)}")
        return pl.DataFrame()

def merge_cumulative(prev_data, current_data):
    """Merge previous cumulative with current transactions"""
    
    try:
        # Combine datasets
        if len(prev_data) > 0 and len(current_data) > 0:
            combined = pl.concat([prev_data, current_data])
        elif len(prev_data) > 0:
            combined = prev_data
        else:
            combined = current_data
        
        # Sort by PROCDT, FTRANSID
        if len(combined) > 0:
            sorted_data = combined.sort(["PROCDT", "FTRANSID"])
            logger.info(f"Merged into {len(sorted_data)} cumulative records")
            return sorted_data
        
        return pl.DataFrame()
    except Exception as e:
        logger.error(f"Error merging cumulative data: {str(e)}")
        return current_data

def write_cumulative_file(records):
    """Write cumulative file with fixed-width format"""
    
    try:
        with open(OUTPUT1, 'w') as f:
            for record in records:
                line = (
                    f"{str(record.get('PROCDT', '')).ljust(6)}"
                    f"{str(record.get('FTRANSID', '')).ljust(16)}"
                    f"{str(record.get('FSELORDN', '')).ljust(40)}"
                    f"{float(record.get('TRANAMT', 0)):>13.2f}"
                    f"{float(record.get('TRXNFEE', 0)):>13.2f}"
                    f"{float(record.get('NETTAMT', 0)):>13.2f}"
                    f"{str(record.get('RECNO', '')).ljust(6)}"
                    f"{str(record.get('TRANCDE', '')).ljust(3)}"
                    f"{str(record.get('FSELERID', '')).ljust(10)}"
                    f"{str(record.get('FSELACNO', '')).ljust(20)}"
                    f"{str(record.get('FBUYBKID', '')).ljust(15)}"
                    f"{str(record.get('FSELERDE', '')).ljust(30)}"
                    f"{str(record.get('FBUYACNO', '')).ljust(20)}\n"
                )
                f.write(line)
        
        logger.info(f"Cumulative file written with {len(records)} records")
    except Exception as e:
        logger.error(f"Error writing cumulative file: {str(e)}")
        raise

if __name__ == "__main__":
    main()
