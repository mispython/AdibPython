# DPFSFSPP.py
# /* FPX DAILY PAYMENT FILE (OPM) FOR SHARE FITNESS SDN BHD (3999545921) */

import polars as pl
from datetime import datetime, timedelta
import common.fixed_width_reader as fixed_width_reader
from common.batch_date import get_batch_date
import os
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Obtain date for file paths
date_info = get_batch_date()
file_date = date_info["file_date"]
folder_day = date_info["folder_day"]
folder_month = date_info["folder_month"]
folder_year = date_info["folder_year"]

# Define file paths
INPUTF1 = f"/host/dp/input/sfs/INPUTF1_{folder_year}{folder_month}{folder_day}.dat"
CONTROL1 = f"/host/dp/input/sfs/CONTROL1_{folder_year}{folder_month}{folder_day}.dat"
CONTROL2 = f"/host/dp/input/sfs/CONTROL2_{folder_year}{folder_month}{folder_day}.dat"
OUTPUT1 = f"/host/dp/output/DPFSFSPP_PAYMNT_{folder_year}{folder_month}{folder_day}.dat"

PROD_SELLER_ID = "SE00030703"

def main():
    """SAS DPFSFSPP program - Share Fitness Payment File"""
    
    try:
        logger.info("Starting DPFSFSPP - SHARE FITNESS PAYMENT FILE")
        
        # Step 1: Read transaction file and filter by seller ID
        logger.info(f"Reading transaction file from {INPUTF1}")
        AAA = read_inputf1()
        
        # Step 2: Read control files
        account_no = read_control1()
        rpt_date = read_control2()
        
        # Step 3: Process records
        logger.info("Processing payment records")
        output_records = process_records(AAA)
        
        # Step 4: Write payment file
        logger.info(f"Writing payment file to {OUTPUT1}")
        write_payment_file(output_records, account_no, rpt_date)
        
        logger.info("DPFSFSPP processing completed successfully.")
        
    except Exception as e:
        logger.error(f"Error in DPFSFSPP processing: {str(e)}")
        raise

def read_inputf1():
    """Read and filter transaction file by seller ID"""
    
    records = []
    try:
        if not os.path.exists(INPUTF1):
            logger.warning(f"File not found: {INPUTF1}")
            return []
        
        with open(INPUTF1, 'r') as f:
            for line in f:
                if len(line) < 200:
                    continue
                
                try:
                    fselerid = line[110:120].strip() if len(line) > 119 else ""
                    if fselerid != PROD_SELLER_ID:
                        continue
                    
                    record = {
                        "PROCDT": line[0:6].strip() if len(line) > 5 else "",
                        "FTRANSID": line[6:22].strip() if len(line) > 21 else "",
                        "FSELORDN": line[22:62].strip() if len(line) > 61 else "",
                        "TRANAMT": float(line[62:75].strip() if len(line) > 74 else "0"),
                        "TRXNFEE": float(line[75:88].strip() if len(line) > 87 else "0"),
                        "NETTAMT": float(line[88:101].strip() if len(line) > 100 else "0"),
                        "RECNO": line[101:107].strip() if len(line) > 106 else "",
                        "TRANCDE": line[107:110].strip() if len(line) > 109 else "",
                        "FSELERID": fselerid,
                        "FSELACNO": line[120:140].strip() if len(line) > 139 else "",
                        "FBUYBKID": line[140:155].strip() if len(line) > 154 else "",
                        "FSELERDE": line[155:185].strip() if len(line) > 184 else "",
                        "FBUYACNO": line[185:205].strip() if len(line) > 204 else ""
                    }
                    records.append(record)
                except:
                    continue
        
        logger.info(f"Read {len(records)} transaction records for {PROD_SELLER_ID}")
        return records
    except Exception as e:
        logger.error(f"Error reading INPUTF1: {str(e)}")
        return []

def read_control1():
    """Read control account number"""
    try:
        if os.path.exists(CONTROL1):
            with open(CONTROL1, 'r') as f:
                line = f.readline().strip()
                if len(line) >= 10:
                    return line[:10]
    except:
        pass
    return "3999545921"

def read_control2():
    """Read control date"""
    rpt_date = {"RPTDAYDD": "01", "RPTDAYMM": "01", "RPTDCCYY": "2020"}
    try:
        if os.path.exists(CONTROL2):
            with open(CONTROL2, 'r') as f:
                line = f.readline().strip()
                if len(line) >= 8:
                    rpt_date = {
                        "RPTDAYDD": line[6:8],
                        "RPTDAYMM": line[4:6],
                        "RPTDCCYY": line[0:4]
                    }
    except:
        pass
    return rpt_date

def process_records(records):
    """Prepare records for output"""
    return records

def write_payment_file(records, account_no, rpt_date):
    """Write fixed-format payment file with header, detail, and trailer records"""
    
    try:
        with open(OUTPUT1, 'w') as f:
            # Header record (Type 0)
            header_date = f"{rpt_date['RPTDCCYY']}{rpt_date['RPTDAYMM']}{rpt_date['RPTDAYDD']}"
            total_count = len(records)
            total_amount = sum(float(r.get('TRANAMT', 0)) for r in records)
            total_fee = sum(float(r.get('TRXNFEE', 0)) for r in records)
            total_net = sum(float(r.get('NETTAMT', 0)) for r in records)
            
            # Format as fixed-width payment file
            header_line = (
                f"0"  # Record type
                f"PBBFPX"  # FPX code
                f"{header_date:<8}"  # Date YYYYMMDD
                f"{int(total_count):>8}"  # Transaction count (Z8 format)
                f"{int(total_amount * 100):>16}"  # Amount in pennies (Z16 format)
                f"{int(total_fee * 100):>16}"  # Fee in pennies
                f"{int(total_net * 100):>16}"  # Net in pennies
                f"{int(0):>8}"  # Zeros
                f"{int(0):>16}"  # Zeros
                f"{''.ljust(24)}"  # Filler
            )
            f.write(header_line + "\n")
            
            # Detail records (Type 1)
            for record in records:
                detail_line = (
                    f"1"  # Record type
                    f"{str(record.get('FTRANSID', '')).ljust(16)}"  # Transaction ID
                    f"{str(record.get('FSELORDN', '')).ljust(40)}"  # Seller order
                    f"{str(record.get('FBUYBKID', '')).ljust(15)}"  # Buyer bank
                    f"{int(float(record.get('TRANAMT', 0))):>13}"  # Amount (Z13 format)
                    f"{int(float(record.get('TRXNFEE', 0))):>13}"  # Fee
                    f"{int(float(record.get('NETTAMT', 0))):>13}"  # Net
                    f"{str(record.get('RECNO', '')).ljust(6)}"  # Host no
                )
                f.write(detail_line + "\n")
            
            # Trailer record (Type 9)
            trailer_line = (
                f"9"  # Record type
                f"PBBFPX"  # FPX code
                f"{header_date:<8}"  # Date YYYYMMDD
                f"{int(total_count):>8}"  # Total count (Z8 format)
                f"{int(total_amount * 100):>16}"  # Total amount
                f"{int(total_fee * 100):>16}"  # Total fee
                f"{int(total_net * 100):>16}"  # Total net
                f"{int(0):>8}"  # Zeros
                f"{int(0):>16}"  # Zeros
                f"{''.ljust(24)}"  # Filler
            )
            f.write(trailer_line + "\n")
        
        logger.info(f"Payment file generated with {total_count} transactions")
        logger.info(f"Total Amount: {total_amount:.2f}, Total Fee: {total_fee:.2f}, Total Net: {total_net:.2f}")
    except Exception as e:
        logger.error(f"Error writing payment file: {str(e)}")
        raise

if __name__ == "__main__":
    main()
