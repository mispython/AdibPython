# DPFSFSR1.py
# /* FPX DAILY TRANSACTION FILE (ODR) FOR SHARE FITNESS SDN BHD (3999545921) */
# /* TRANSACTION FEE: SEGREGATE B2B & B2C */
# /* DP7304 AAB2 - CHANGE HARDCODE GST TO READ FROM PARAMETER FILE */

import polars as pl
from datetime import datetime, timedelta
import common.fixed_width_reader as fixed_width_reader
from common.batch_date import get_batch_date
import os
import logging
import math

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Obtain date for file paths
date_info = get_batch_date()
file_date = date_info["file_date"]
folder_day = date_info["folder_day"]
folder_month = date_info["folder_month"]
folder_year = date_info["folder_year"]

# Define file paths
INPUTF1 = f"/host/dp/input/sfs/INPUTF1_{folder_year}{folder_month}{folder_day}.dat"
GSTRATE_FILE = f"/host/dp/input/sfs/GSTRATE_{folder_year}{folder_month}{folder_day}.dat"
CONTROL1 = f"/host/dp/input/sfs/CONTROL1_{folder_year}{folder_month}{folder_day}.dat"
CONTROL2 = f"/host/dp/input/sfs/CONTROL2_{folder_year}{folder_month}{folder_day}.dat"
CONTRP = f"/host/dp/input/sfs/CONTRP_{folder_year}{folder_month}{folder_day}.dat"
BANKBRCH = f"/host/dp/input/sfs/BANKBRCH_{folder_year}{folder_month}{folder_day}.dat"
OUTPUT1 = f"/host/dp/output/DPFSFSR1_REPORT_{folder_year}{folder_month}{folder_day}.txt"

PROD_SELLER_ID = "SE00030703"

def main():
    """SAS DPFSFSR1 program - Share Fitness Daily Transaction Report with B2B/B2C grouping"""
    
    try:
        logger.info("Starting DPFSFSR1 - SHARE FITNESS DAILY TRANSACTION REPORT")
        
        # Step 1: Read GST rate
        gst_rate = read_gst_rate()
        logger.info(f"GST rate: {gst_rate}")
        
        # Step 2: Read transaction file and classify by fee type
        logger.info(f"Reading transaction file from {INPUTF1}")
        AAA, BBB = read_and_classify_inputf1()
        
        # Step 3: Read control files
        ractno = read_control1()
        rpt_date = read_control2()
        corp_info = read_report_control()
        bank_branch = read_bank_branch(corp_info.get("BRHCDE", ""))
        
        # Step 4: Process transactions with grouping
        logger.info("Processing daily transactions with GST calculations and grouping")
        output_records = process_transactions_grouped(AAA, BBB, gst_rate)
        
        # Step 5: Write output file
        logger.info(f"Writing report to {OUTPUT1}")
        write_report(output_records, ractno, rpt_date, corp_info, bank_branch)
        
        logger.info("DPFSFSR1 processing completed successfully.")
        
    except Exception as e:
        logger.error(f"Error in DPFSFSR1 processing: {str(e)}")
        raise

def read_gst_rate():
    """Read GST rate from parameter file"""
    try:
        if os.path.exists(GSTRATE_FILE):
            with open(GSTRATE_FILE, 'r') as f:
                line = f.readline().strip()
                if len(line) >= 4:
                    gst_value = float(line[0:4])
                    return gst_value / 100
    except:
        pass
    return 0.06  # Default 6%

def read_and_classify_inputf1():
    """Read and classify transaction file by fee type"""
    
    AAA = []  # TRXNFEE = '250' (B2B)
    BBB = []  # TRXNFEE = '150' (B2C)
    
    try:
        if not os.path.exists(INPUTF1):
            logger.warning(f"File not found: {INPUTF1}")
            return [], []
        
        with open(INPUTF1, 'r') as f:
            for line in f:
                if len(line) < 200:
                    continue
                
                try:
                    fselerid = line[110:120].strip() if len(line) > 119 else ""
                    if fselerid != PROD_SELLER_ID:
                        continue
                    
                    record = {
                        "PROCDT": line[0:6].strip() if len(line) > 5 else "",
                        "FTRANSID": line[6:22].strip() if len(line) > 21 else "",
                        "FSELORDN": line[22:62].strip() if len(line) > 61 else "",
                        "TRANAMT": float(line[62:75].strip() if len(line) > 74 else "0"),
                        "TRXNFEE": float(line[75:88].strip() if len(line) > 87 else "0"),
                        "NETTAMT": float(line[88:101].strip() if len(line) > 100 else "0"),
                        "RECNO": line[101:107].strip() if len(line) > 106 else "",
                        "TRANCDE": line[107:110].strip() if len(line) > 109 else "",
                        "FSELERID": fselerid,
                        "FSELACNO": line[120:140].strip() if len(line) > 139 else "",
                        "FBUYBKID": line[140:155].strip() if len(line) > 154 else "",
                        "FSELERDE": line[155:185].strip() if len(line) > 184 else "",
                        "FBUYACNO": line[185:205].strip() if len(line) > 204 else ""
                    }
                    
                    # Classify by fee
                    fee_value = float(record.get("TRXNFEE", 0))
                    if fee_value == 150 or fee_value == 1.50:
                        BBB.append(record)
                    else:
                        AAA.append(record)
                except:
                    continue
        
        logger.info(f"Read {len(AAA)} B2B transactions and {len(BBB)} B2C transactions")
        return AAA, BBB
    except Exception as e:
        logger.error(f"Error reading INPUTF1: {str(e)}")
        return [], []

def read_control1():
    """Read control account"""
    try:
        if os.path.exists(CONTROL1):
            with open(CONTROL1, 'r') as f:
                line = f.readline().strip()
                if len(line) >= 10:
                    return line[:10]
    except:
        pass
    return ""

def read_control2():
    """Read control date"""
    rpt_date = {"RPTDAYDD": "01", "RPTDAYMM": "01", "RPTDCCYY": "2020"}
    try:
        if os.path.exists(CONTROL2):
            with open(CONTROL2, 'r') as f:
                line = f.readline().strip()
                if len(line) >= 8:
                    rpt_date = {
                        "RPTDAYDD": line[6:8],
                        "RPTDAYMM": line[4:6],
                        "RPTDCCYY": line[0:4]
                    }
    except:
        pass
    return rpt_date

def read_report_control():
    """Read report control parameters"""
    corp_info = {"CRPCDE": "", "BRHCDE": "", "RPTNM": "", "REF01": "", "REF02": ""}
    try:
        if os.path.exists(CONTRP):
            with open(CONTRP, 'r') as f:
                for line in f:
                    if len(line) >= 120:
                        corp_info = {
                            "CRPCDE": line[11:15].strip() if len(line) > 14 else "",
                            "BRHCDE": line[16:20].strip() if len(line) > 19 else "",
                            "RPTNM": line[25:65].strip() if len(line) > 64 else "",
                            "REF01": line[79:99].strip() if len(line) > 98 else "",
                            "REF02": line[99:119].strip() if len(line) > 118 else ""
                        }
                        break
    except:
        pass
    return corp_info

def read_bank_branch(branch_code):
    """Read bank branch name"""
    try:
        if os.path.exists(BANKBRCH):
            with open(BANKBRCH, 'r') as f:
                for line in f:
                    if len(line) >= 40 and line[1:5].strip() == branch_code:
                        return line[11:41].strip()
    except:
        pass
    return ""

def process_transactions_grouped(AAA, BBB, gst_rate):
    """Process transactions grouped by type with GST calculation"""
    output_records = []
    
    # Process AAA (B2B) transactions
    group_a = []
    for row in AAA:
        tranamt = float(row.get("TRANAMT", 0))
        trxnfee = float(row.get("TRXNFEE", 0))
        gst_fee_raw = trxnfee * gst_rate * 100
        gst_fee = math.ceil(gst_fee_raw) / 100
        
        row["TRXNFEE"] = trxnfee
        row["GSTFEE"] = gst_fee
        row["NETAMT"] = tranamt - trxnfee - gst_fee
        row["GROUP"] = "A"
        row["TRNTYPE"] = "B2B TRANSACTIONS"
        group_a.append(row)
    
    # Process BBB (B2C) transactions
    group_b = []
    for row in BBB:
        tranamt = float(row.get("TRANAMT", 0))
        trxnfee = float(row.get("TRXNFEE", 0))
        gst_fee_raw = trxnfee * gst_rate * 100
        gst_fee = math.ceil(gst_fee_raw) / 100
        
        row["TRXNFEE"] = trxnfee
        row["GSTFEE"] = gst_fee
        row["NETAMT"] = tranamt - trxnfee - gst_fee
        row["GROUP"] = "B"
        row["TRNTYPE"] = "B2C TRANSACTIONS"
        group_b.append(row)
    
    output_records.extend(group_a)
    output_records.extend(group_b)
    
    return output_records

def write_report(records, ractno, rpt_date, corp_info, bank_branch):
    """Write transaction report with transaction grouping"""
    logger.info(f"Generating report with {len(records)} transactions")
    
    try:
        with open(OUTPUT1, 'w') as f:
            if len(records) == 0:
                f.write("NO TRANSACTIONS FOR THE DAY\n")
                return
            
            # Group records by transaction type
            report_name = corp_info.get('RPTNM', 'SHARE FITNESS')
            
            f.write(f"REPORT NO : {corp_info.get('CRPCDE', '')} -D-002\n")
            f.write(f"DAILY TRANSACTION REPORT\n")
            f.write(f"{corp_info.get('BRHCDE', '')} {bank_branch}\n")
            f.write(f"PROGRAM ID : DPFSFSR1\n")
            f.write(f"{report_name} COLLECTION ACCOUNT ({ractno})\n")
            f.write(f"DATE : {rpt_date['RPTDCCYY']}/{rpt_date['RPTDAYMM']}/{rpt_date['RPTDAYDD']}\n\n")
            
            total_count = 0
            total_amount = 0
            total_fee = 0
            total_gst = 0
            total_net = 0
            
            current_group = None
            group_count = 0
            group_amount = 0
            group_fee = 0
            group_net = 0
            
            for idx, record in enumerate(records):
                # Check for group change
                if record.get("GROUP") != current_group:
                    if current_group is not None:
                        # Write group totals
                        f.write(f"\nTOTAL COUNT : {group_count:>6}\n")
                        f.write(f"TOTAL AMOUNT : {group_amount:>18.2f}\n")
                        f.write(f"TOTAL FEE           : {group_fee:>13.2f}\n")
                        f.write(f"TOTAL NET AMOUNT    : {group_net:>13.2f}\n\n")
                    
                    # New group header
                    current_group = record.get("GROUP")
                    f.write(f"\n{record.get('TRNTYPE', '')}\n")
                    f.write(f"{'---'*11}\n\n")
                    f.write(f"{'NO.':<5}  {corp_info.get('REF01', ''):<20}  {'SELLER ORDER NO':<40}  {'BUYER BANK':<15}  "
                           f"{'AMOUNT':>13}  {'FEE':>11}  {'AMOUNT':>11}  {'HOST NO':<6}\n")
                    f.write("-" * 130 + "\n")
                    
                    group_count = 0
                    group_amount = 0
                    group_fee = 0
                    group_net = 0
                
                ftransid = str(record.get("FTRANSID", "")).ljust(16)
                fselordn = str(record.get("FSELORDN", "")).ljust(40)
                fbuybkid = str(record.get("FBUYBKID", "")).ljust(15)
                tranamt = float(record.get("TRANAMT", 0))
                trxnfee = float(record.get("TRXNFEE", 0))
                netamt = float(record.get("NETAMT", 0))
                recno = str(record.get("RECNO", "")).strip()
                
                group_count += 1
                group_amount += tranamt
                group_fee += trxnfee
                group_net += netamt
                total_count += 1
                total_amount += tranamt
                total_fee += trxnfee
                total_net += netamt
                
                line = (f"{group_count:<5}  {ftransid:<20}  {fselordn:<40}  {fbuybkid:<15}  "
                       f"{tranamt:>13.2f}  {trxnfee:>11.2f}  {netamt:>11.2f}  {recno:<6}\n")
                f.write(line)
            
            # Final group totals
            if current_group is not None:
                f.write(f"\nTOTAL COUNT : {group_count:>6}\n")
                f.write(f"TOTAL AMOUNT : {group_amount:>18.2f}\n")
                f.write(f"TOTAL FEE           : {group_fee:>13.2f}\n")
                f.write(f"TOTAL NET AMOUNT    : {group_net:>13.2f}\n\n")
            
            # Grand totals
            f.write("-" * 130 + "\n")
            f.write(f"GRAND TOTAL COUNT   : {total_count:>4}\n")
            f.write(f"GRAND TOTAL AMOUNT  : {total_amount:>18.2f}\n")
            f.write(f"GRAND TOTAL FEE     : {total_fee:>13.2f}\n")
            f.write(f"GRAND TOTAL NET AMT : {total_net:>13.2f}\n")
            f.write("-" * 130 + "\n")
        
        logger.info(f"Report generated successfully")
    except Exception as e:
        logger.error(f"Error writing report: {str(e)}")
        raise

if __name__ == "__main__":
    main()
