# DPFSFSSU.py
# /* SHARE FITNESS SUMMARY FILE FROM GIRO/E-BANKING SOURCE */
# /* CLONED FROM DPISVDSU - GENERATES SUMMARY FILE FOR REPORTING */

import polars as pl
from datetime import datetime, timedelta
import common.fixed_width_reader as fixed_width_reader
from common.batch_date import get_batch_date
import os
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Obtain date for file paths
date_info = get_batch_date()
file_date = date_info["file_date"]
folder_day = date_info["folder_day"]
folder_month = date_info["folder_month"]
folder_year = date_info["folder_year"]

# Define file paths
INPUTF1 = f"/host/dp/input/sfs/INPUTF1_{folder_year}{folder_month}{folder_day}.dat"
INPUTF2 = f"/host/dp/input/sfs/INPUTF2_{folder_year}{folder_month}{folder_day}.dat"
CONTROL1 = f"/host/dp/input/sfs/CONTROL1_{folder_year}{folder_month}{folder_day}.dat"
CONTROL2 = f"/host/dp/input/sfs/CONTROL2_{folder_year}{folder_month}{folder_day}.dat"
OUTPUT1 = f"/host/dp/output/DPFSFSSU_SUMM_{folder_year}{folder_month}{folder_day}.dat"

PROD_SELLER_ID = "SE00030703"
SOURCE_CODE = "313"  # E-BANKING/GIRO SOURCE CODE

def main():
    """SAS DPFSFSSU program - Share Fitness Summary File"""
    
    try:
        logger.info("Starting DPFSFSSU - SHARE FITNESS SUMMARY FILE")
        
        # Step 1: Read account info
        rpt_date = read_control2()
        account_no = read_control1()
        
        # Step 2: Read GIRO/E-Banking transactions
        logger.info(f"Reading GIRO/E-Banking transactions from {INPUTF1}")
        giro_records = read_giro_transactions()
        
        # Step 3: Read FPX transactions
        logger.info(f"Reading FPX transactions from {INPUTF2}")
        fpx_records = read_fpx_transactions()
        
        # Step 4: Merge and process
        logger.info("Merging GIRO and FPX transaction records")
        output_records = merge_transactions(giro_records, fpx_records)
        
        # Step 5: Write output
        logger.info(f"Writing summary file to {OUTPUT1}")
        write_summary_file(output_records)
        
        logger.info("DPFSFSSU processing completed successfully.")
        
    except Exception as e:
        logger.error(f"Error in DPFSFSSU processing: {str(e)}")
        raise

def read_control1():
    """Read control account information"""
    try:
        if os.path.exists(CONTROL1):
            with open(CONTROL1, 'r') as f:
                line = f.readline().strip()
                if len(line) >= 10:
                    return {
                        "ACCTNO": line[0:10],
                        "SHORTNAME": line[11:14] if len(line) > 13 else "",
                        "LONGNAME": line[15:35] if len(line) > 34 else ""
                    }
    except:
        pass
    return {"ACCTNO": "3999545921", "SHORTNAME": "", "LONGNAME": ""}

def read_control2():
    """Read control date"""
    rpt_date = {"RPTDAYDD": "01", "RPTDAYMM": "01", "RPTDCCYY": "2020"}
    try:
        if os.path.exists(CONTROL2):
            with open(CONTROL2, 'r') as f:
                line = f.readline().strip()
                if len(line) >= 8:
                    rpt_date = {
                        "RPTDAYDD": line[6:8],
                        "RPTDAYMM": line[4:6],
                        "RPTDCCYY": line[0:4]
                    }
    except:
        pass
    return rpt_date

def read_giro_transactions():
    """Read GIRO/E-Banking transactions with special processing"""
    
    records = []
    try:
        if not os.path.exists(INPUTF1):
            logger.warning(f"File not found: {INPUTF1}")
            return []
        
        with open(INPUTF1, 'r') as f:
            for line in f:
                if len(line) < 730:
                    continue
                
                try:
                    # Extract fields from GIRO file (LRECL=725)
                    bankno = line[4:7].strip() if len(line) > 6 else ""
                    acctno = line[8:18].strip() if len(line) > 17 else ""
                    procdt = line[19:27].strip() if len(line) > 26 else ""
                    datatyp = line[27:28].strip() if len(line) > 27 else ""
                    userind = line[29:30].strip() if len(line) > 29 else ""
                    srccode = line[53:56].strip() if len(line) > 55 else ""
                    trancode = line[50:53].strip() if len(line) > 52 else ""
                    tranamt = float(line[72:85].strip() if len(line) > 84 else "0")
                    
                    # Filter by transaction code (not 874) and source code (313)
                    if trancode == "874":
                        continue
                    if srccode != SOURCE_CODE:
                        continue
                    
                    record = {
                        "BANKNO": bankno,
                        "ACCTNO": acctno,
                        "PROCDT": procdt,
                        "DATATYP": datatyp,
                        "USERIND": userind,
                        "SRCCODE": srccode,
                        "TRANAMT": tranamt,
                        "TRANTYPE": "GIRO"
                    }
                    records.append(record)
                except:
                    continue
        
        if records:
            logger.info(f"Read {len(records)} GIRO/E-Banking transactions")
        return records
    except Exception as e:
        logger.error(f"Error reading GIRO transactions: {str(e)}")
        return []

def read_fpx_transactions():
    """Read FPX transactions with seller ID filter"""
    
    records = []
    try:
        if not os.path.exists(INPUTF2):
            logger.warning(f"File not found: {INPUTF2}")
            return []
        
        with open(INPUTF2, 'r') as f:
            for line in f:
                if len(line) < 542:
                    continue
                
                try:
                    ftransid = line[0:16].strip() if len(line) > 15 else ""
                    fprocdt = line[75:83].strip() if len(line) > 82 else ""
                    fselerid = line[191:201].strip() if len(line) > 200 else ""
                    ftrxamnt = float(line[498:506].strip() if len(line) > 505 else "0")
                    
                    # Filter by seller ID
                    if fselerid != PROD_SELLER_ID:
                        continue
                    
                    record = {
                        "FTRANSID": ftransid,
                        "FPROCDT": fprocdt,
                        "FSELERID": fselerid,
                        "FTRXAMNT": ftrxamnt,
                        "TRANTYPE": "FPX"
                    }
                    records.append(record)
                except:
                    continue
        
        if records:
            logger.info(f"Read {len(records)} FPX transactions")
        return records
    except Exception as e:
        logger.error(f"Error reading FPX transactions: {str(e)}")
        return []

def merge_transactions(giro_records, fpx_records):
    """Merge GIRO and FPX transactions"""
    
    try:
        combined_records = []
        
        if len(giro_records) > 0:
            combined_records.extend(giro_records)
        if len(fpx_records) > 0:
            combined_records.extend(fpx_records)
        
        # Sort by transaction date if available
        if combined_records:
            logger.info(f"Merged {len(combined_records)} total transaction records")
        
        return combined_records
    except Exception as e:
        logger.error(f"Error merging transactions: {str(e)}")
        return []

def write_summary_file(records):
    """Write summary file combining GIRO and FPX data"""
    
    try:
        with open(OUTPUT1, 'w') as f:
            # Summary header
            f.write("SHARE FITNESS SDN BHD - COLLECTION SUMMARY\n")
            f.write(f"Total Records: {len(records)}\n\n")
            
            # Write transaction details
            for record in records:
                if record.get("TRANTYPE") == "GIRO":
                    line = (
                        f"GIRO|{record.get('BANKNO', '')}|{record.get('ACCTNO', '')}"
                        f"|{record.get('PROCDT', '')}|{record.get('SRCCODE', '')}"
                        f"|{record.get('TRANAMT', 0):.2f}\n"
                    )
                else:  # FPX
                    line = (
                        f"FPX|{record.get('FTRANSID', '')}|{record.get('FSELERID', '')}"
                        f"|{record.get('FPROCDT', '')}|{record.get('FTRXAMNT', 0):.2f}\n"
                    )
                f.write(line)
        
        logger.info(f"Summary file written with {len(records)} records")
    except Exception as e:
        logger.error(f"Error writing summary file: {str(e)}")
        raise

if __name__ == "__main__":
    main()
