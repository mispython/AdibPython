# DPFSMMR1.py
# /* FPX DAILY TRANSACTION FILE (ODR) FOR I-SERVE ONLINE MALL SDN BHD (3999577830) */
# /* DP5770-AMENDED PROGRAM TO INCLUDE TRAN FEE / GST FEE AND NET AMOUNT DETAIL */

import polars as pl
from datetime import datetime, timedelta
import common.fixed_width_reader as fixed_width_reader
from common.batch_date import get_batch_date
import os
import logging
import math

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Obtain date for file paths
date_info = get_batch_date()
file_date = date_info["file_date"]
folder_day = date_info["folder_day"]
folder_month = date_info["folder_month"]
folder_year = date_info["folder_year"]

# Define file paths
INPUTF1 = f"/host/dp/input/smm/INPUTF1_{folder_year}{folder_month}{folder_day}.dat"
CONTROL1 = f"/host/dp/input/smm/CONTROL1_{folder_year}{folder_month}{folder_day}.dat"
CONTROL2 = f"/host/dp/input/smm/CONTROL2_{folder_year}{folder_month}{folder_day}.dat"
CONTRP = f"/host/dp/input/smm/CONTRP_{folder_year}{folder_month}{folder_day}.dat"
BANKBRCH = f"/host/dp/input/smm/BANKBRCH_{folder_year}{folder_month}{folder_day}.dat"
OUTPUT1 = f"/host/dp/output/DPFSMMR1_REPORT_{folder_year}{folder_month}{folder_day}.txt"

PROD_SELLER_ID = "SE00033702"

def main():
    """SAS DPFSMMR1 program - I-Serve Online Mall Daily Transaction Report"""
    
    try:
        logger.info("Starting DPFSMMR1 - I-SERVE ONLINE MALL DAILY TRANSACTION REPORT")
        
        # Step 1: Read transaction file
        logger.info(f"Reading transaction file from {INPUTF1}")
        AAA = read_inputf1()
        
        # Step 2: Read control files
        ractno = read_control1()
        rpt_date = read_control2()
        corp_info = read_report_control()
        bank_branch = read_bank_branch(corp_info.get("BRHCDE", ""))
        
        # Step 3: Process transactions
        logger.info("Processing daily transactions")
        output_records = process_transactions(AAA)
        
        # Step 4: Write output file
        logger.info(f"Writing report to {OUTPUT1}")
        write_report(output_records, ractno, rpt_date, corp_info, bank_branch)
        
        logger.info("DPFSMMR1 processing completed successfully.")
        
    except Exception as e:
        logger.error(f"Error in DPFSMMR1 processing: {str(e)}")
        raise

def read_inputf1():
    """Read and filter transaction file by seller ID"""
    
    records = []
    try:
        if not os.path.exists(INPUTF1):
            logger.warning(f"File not found: {INPUTF1}")
            return []
        
        with open(INPUTF1, 'r') as f:
            for line in f:
                if len(line) < 200:
                    continue
                
                try:
                    fselerid = line[110:120].strip() if len(line) > 119 else ""
                    if fselerid != PROD_SELLER_ID:
                        continue
                    
                    record = {
                        "PROCDT": line[0:6].strip() if len(line) > 5 else "",
                        "FTRANSID": line[6:22].strip() if len(line) > 21 else "",
                        "FSELORDN": line[22:62].strip() if len(line) > 61 else "",
                        "TRANAMT": float(line[62:75].strip() if len(line) > 74 else "0") / 100,
                        "TRXNFEE": float(line[75:88].strip() if len(line) > 87 else "0") / 100,
                        "NETTAMT": float(line[88:101].strip() if len(line) > 100 else "0") / 100,
                        "RECNO": line[101:107].strip() if len(line) > 106 else "",
                        "TRANCDE": line[107:110].strip() if len(line) > 109 else "",
                        "FSELERID": fselerid,
                        "FSELACNO": line[120:140].strip() if len(line) > 139 else "",
                        "FBUYBKID": line[140:155].strip() if len(line) > 154 else "",
                        "FSELERDE": line[155:185].strip() if len(line) > 184 else "",
                        "FBUYACNO": line[185:205].strip() if len(line) > 204 else ""
                    }
                    records.append(record)
                except:
                    continue
        
        logger.info(f"Read {len(records)} transaction records for {PROD_SELLER_ID}")
        return records
    except Exception as e:
        logger.error(f"Error reading INPUTF1: {str(e)}")
        return []

def read_control1():
    """Read control account"""
    try:
        if os.path.exists(CONTROL1):
            with open(CONTROL1, 'r') as f:
                line = f.readline().strip()
                if len(line) >= 10:
                    return line[:10]
    except:
        pass
    return ""

def read_control2():
    """Read control date"""
    rpt_date = {"RPTDAYDD": "01", "RPTDAYMM": "01", "RPTDCCYY": "2020"}
    try:
        if os.path.exists(CONTROL2):
            with open(CONTROL2, 'r') as f:
                line = f.readline().strip()
                if len(line) >= 8:
                    rpt_date = {
                        "RPTDAYDD": line[6:8],
                        "RPTDAYMM": line[4:6],
                        "RPTDCCYY": line[0:4]
                    }
    except:
        pass
    return rpt_date

def read_report_control():
    """Read report control parameters"""
    corp_info = {"CRPCDE": "", "BRHCDE": "", "RPTNM": "", "REF01": "", "REF02": ""}
    try:
        if os.path.exists(CONTRP):
            with open(CONTRP, 'r') as f:
                for line in f:
                    if len(line) >= 120:
                        corp_info = {
                            "CRPCDE": line[11:15].strip() if len(line) > 14 else "",
                            "BRHCDE": line[16:20].strip() if len(line) > 19 else "",
                            "RPTNM": line[25:65].strip() if len(line) > 64 else "",
                            "REF01": line[79:99].strip() if len(line) > 98 else "",
                            "REF02": line[99:119].strip() if len(line) > 118 else ""
                        }
                        break
    except:
        pass
    return corp_info

def read_bank_branch(branch_code):
    """Read bank branch name"""
    try:
        if os.path.exists(BANKBRCH):
            with open(BANKBRCH, 'r') as f:
                for line in f:
                    if len(line) >= 40 and line[1:5].strip() == branch_code:
                        return line[11:41].strip()
    except:
        pass
    return ""

def process_transactions(records):
    """Process transactions with no GST (GST rate = 0.00)"""
    output_records = []
    
    for row in records:
        tranamt = float(row.get("TRANAMT", 0))
        trxnfee = float(row.get("TRXNFEE", 0))
        gst_fee = 0.00  # NO GST FOR THIS ACCOUNT
        
        row["TRXNFEE"] = trxnfee
        row["GSTFEE"] = gst_fee
        row["NETAMT"] = tranamt - trxnfee - gst_fee
        output_records.append(row)
    
    return output_records

def write_report(records, ractno, rpt_date, corp_info, bank_branch):
    """Write transaction report"""
    logger.info(f"Generating report with {len(records)} transactions")
    
    try:
        with open(OUTPUT1, 'w') as f:
            if len(records) == 0:
                f.write("NO TRANSACTIONS FOR THE DAY\n")
                return
            
            report_name = corp_info.get('RPTNM', 'I-SERVE ONLINE MALL')
            
            f.write(f"REPORT NO : {corp_info.get('CRPCDE', '')} -D-002\n")
            f.write(f"DAILY TRANSACTION REPORT\n")
            f.write(f"PAGE : 1\n")
            f.write(f"{corp_info.get('BRHCDE', '')} {bank_branch}\n")
            f.write(f"PROGRAM ID : DPFSMMR1\n")
            f.write(f"{report_name} COLLECTION ACCOUNT ({ractno})\n")
            f.write(f"DATE : {rpt_date['RPTDCCYY']}/{rpt_date['RPTDAYMM']}/{rpt_date['RPTDAYDD']}\n\n")
            
            f.write(f"{'NO.':<5}  {corp_info.get('REF01', ''):<20}  {'SELLER ORDER NO':<40}  {'BUYER BANK':<15}  "
                   f"{'AMOUNT':>13}  {'FEE':>11}  {'AMOUNT':>11}  {'HOST NO':<6}\n")
            f.write("-" * 130 + "\n")
            
            total_count = 0
            total_amount = 0
            total_fee = 0
            total_gst = 0
            total_net = 0
            
            for idx, record in enumerate(records, 1):
                ftransid = str(record.get("FTRANSID", "")).ljust(16)
                fselordn = str(record.get("FSELORDN", "")).ljust(40)
                fbuybkid = str(record.get("FBUYBKID", "")).ljust(15)
                tranamt = float(record.get("TRANAMT", 0))
                trxnfee = float(record.get("TRXNFEE", 0))
                netamt = float(record.get("NETAMT", 0))
                recno = str(record.get("RECNO", "")).strip()
                
                total_count += 1
                total_amount += tranamt
                total_fee += trxnfee
                total_net += netamt
                
                line = (f"{idx:<5}  {ftransid:<20}  {fselordn:<40}  {fbuybkid:<15}  "
                       f"{tranamt:>13.2f}  {trxnfee:>11.2f}  {netamt:>11.2f}  {recno:<6}\n")
                f.write(line)
            
            f.write("-" * 130 + "\n")
            f.write(f"TOTAL COUNT  : {total_count:>6}\n")
            f.write(f"TOTAL AMOUNT : {total_amount:>18.2f}\n")
            f.write(f"TOTAL FEE           : {total_fee:>13.2f}\n")
            f.write(f"TOTAL NET AMOUNT    : {total_net:>13.2f}\n\n")
            f.write(f"GRAND TOTAL COUNT   : {total_count:>4}\n")
            f.write(f"GRAND TOTAL AMOUNT  : {total_amount:>18.2f}\n")
            f.write(f"GRAND TOTAL FEE     : {total_fee:>13.2f}\n")
            f.write(f"GRAND TOTAL NET AMT : {total_net:>13.2f}\n")
            f.write("-" * 130 + "\n")
        
        logger.info(f"Report generated successfully")
    except Exception as e:
        logger.error(f"Error writing report: {str(e)}")
        raise

if __name__ == "__main__":
    main()
